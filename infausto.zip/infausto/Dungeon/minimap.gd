extends Control

signal room_clicked(position: Vector2i)

const CELL := 28
const MARGIN := 8
const DRAG_THRESHOLD := 5.0

var rooms: Dictionary = {}
var discovered: Dictionary = {}
var current := Vector2i.ZERO
var expanded := false
var interactive := true
var pan := Vector2.ZERO
var pointer_start := Vector2.ZERO
var pan_start := Vector2.ZERO
var holding := false
var dragging := false
var hovered := Vector2i(-100, -100)


func _ready() -> void:
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	clip_contents = true
	_resize_map()
	mouse_exited.connect(_clear_hover)


func update_rooms(floor_rooms: Dictionary, seen: Dictionary, location: Vector2i) -> void:
	rooms = floor_rooms
	discovered = seen
	current = location
	queue_redraw()


func set_expanded(value: bool) -> void:
	expanded = value
	pan = Vector2.ZERO
	holding = false
	dragging = false
	hovered = Vector2i(-100, -100)
	_resize_map()
	queue_redraw()


func _resize_map() -> void:
	var width := float((15 if expanded else 5) * CELL + 2 * MARGIN)
	if expanded:
		set_anchors_and_offsets_preset(Control.PRESET_CENTER)
		offset_left = -width / 2.0
		offset_top = -width / 2.0
		offset_right = width / 2.0
		offset_bottom = width / 2.0
	else:
		set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
		offset_left = -width - 14.0
		offset_top = 14.0
		offset_right = -14.0
		offset_bottom = width + 14.0


func _clear_hover() -> void:
	hovered = Vector2i(-100, -100)
	queue_redraw()


func _map_origin() -> Vector2:
	return size / 2.0 + pan - Vector2.ONE * (CELL / 2.0)


func _tile_at(local_point: Vector2) -> Vector2i:
	var cell := (local_point - _map_origin()) / float(CELL)
	return current + Vector2i(floori(cell.x), floori(cell.y))


func _can_select(tile: Vector2i) -> bool:
	var delta := tile - current
	return interactive and absi(delta.x) + absi(delta.y) == 1 and discovered.has(tile)


func _gui_input(event: InputEvent) -> void:
	if not interactive:
		return
	if event is InputEventMouseMotion:
		if holding and expanded:
			var difference: Vector2 = event.position - pointer_start
			if dragging or difference.length() > DRAG_THRESHOLD:
				dragging = true
				pan = (pan_start + difference).clamp(Vector2(-252, -252), Vector2(252, 252))
		hovered = _tile_at(event.position)
		queue_redraw()
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			holding = true
			dragging = false
			pointer_start = event.position
			pan_start = pan
		else:
			var tile := _tile_at(event.position)
			if holding and not dragging and _can_select(tile):
				room_clicked.emit(tile)
			holding = false
			dragging = false
		accept_event()


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("#181b22e7"))
	draw_rect(Rect2(Vector2.ZERO, size), Color("#697484"), false, 1.0)
	var origin := _map_origin()
	var font := ThemeDB.fallback_font
	var icon_size := 15
	for tile: Vector2i in discovered:
		var room: Dictionary = rooms[tile]
		var tile_pos := origin + Vector2(tile - current) * CELL
		var box := Rect2(tile_pos + Vector2(2, 2), Vector2(CELL - 4, CELL - 4))
		var fill := Color("#3d4653")
		if room["visited"]:
			fill = Color("#667487")
		if tile == current:
			fill = Color("#568a76")
		elif tile == hovered and _can_select(tile) and not dragging:
			fill = Color("#8296ac")
		draw_rect(box, fill)
		draw_rect(box, Color("#98a5b7") if tile == current else Color("#303b4b"), false, 1.0)

		var icon := ""
		if tile != current:
			if room["kind"] == "shop":
				icon = "S"
			elif room["kind"] == "treasure" and not room["mystery"] and not room["resolved"]:
				icon = "T"
			elif room["kind"] == "campfire" and room["visited"] and not room["resolved"]:
				icon = "C"
			elif room["kind"] == "boss" and room["resolved"]:
				icon = "B"
		if not icon.is_empty():
			var text_size := font.get_string_size(icon, HORIZONTAL_ALIGNMENT_LEFT, -1, icon_size)
			var baseline := box.get_center() + Vector2(-text_size.x / 2.0, icon_size * 0.34)
			draw_string(font, baseline, icon, HORIZONTAL_ALIGNMENT_LEFT, -1, icon_size, Color.WHITE)
