extends RefCounted
# Base HP and attack damage gain one scaling tier every 5 waves.
const WAVES_PER_SCALING_TIER = 5
const ENEMY_SCALING_PER_TIER = 1.15
const SLIME_POTENTATE_WAVE = 10

const ENEMIES = {
	"slime": {
		"sprite": "res://Assets/floor1enemy/slime.png",
		"name": "Slime",
		"max_health": 30,
		"speed": 0,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 20,
		"gold_min": 15,
		"gold_max": 30,
		"attacks": [
			{
				"name": "Slime Punch",
				"damage": 3,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Slime Splash",
				"damage": 7,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Slime Crush",
				"aoe": true,
				"damage": 10,
				"weight": 20,
				"reaction_time": 3.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			}
		],
		"loot_table": [
			{"item_id": "basic_sword", "chance": 0.35},
			{"item_id": "slightly_basic_sword", "chance": 0.15},
			{"item_id": "lesser_health_potion", "chance": 0.25},
			{"item_id": "slime_in_a_bottle", "chance": 0.05, "on_kill_only": true}
		]
	},
	"skeleton": {
		"sprites": [
			"res://Assets/floor1enemy/Base Angry Skeleton.png",
			"res://Assets/floor1enemy/Base Confused Skeleton.png",
			"res://Assets/floor1enemy/Base Sad Skeleton.png",
			"res://Assets/floor1enemy/Base Skeleton.png"
		],
		"sprite_weights": [25, 25, 25, 25],
		"name": "Skeleton",
		"max_health": 35,
		"speed": 10,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 25,
		"gold_min": 5,
		"gold_max": 25,
		"attacks": [
			{
				"name": "Bone Slash",
				"damage": 7,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Rib Thrust",
				"damage": 5,
				"weight": 30,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Skull Bash",
				"damage": 15,
				"weight": 15,
				"reaction_time": 3.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			},
			{
				"name": "Lunge > Bite",
				"weight": 35,
				"stages": [
					{
						"name": "Lunge",
						"damage": 6,
						"reaction_time": 2.5,
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false
					},
					{
						"name": "Bite",
						"damage": 12,
						"reaction_time": 1.4,
						"can_dodge": true,
						"can_parry": false,
						"can_block": false,
						"guardbreak": false
					}
				],
				"interruptible": false
			}
		],
		"loot_table": []
	},
	"lesser_slime": {
		"sprite": "res://Assets/floor1enemy/lesserslime.png",
		"name": "Lesser Slime",
		"max_health": 10,
		"speed": 0,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 7,
		"gold_min": 2,
		"gold_max": 5,
		"attacks": [
			{
				"name": "Leg Grab",
				"damage": 3,
				"weight": 50,
				"reaction_time": 2.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Pounce",
				"damage": 3,
				"weight": 50,
				"reaction_time": 2.0,
				"can_dodge": false,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false
			}
		],
		"loot_table": [
			{"item_id": "lesser_health_potion", "chance": 0.01}
		]
	},
	"sword skeleton": {
		"sprites": [
			"res://Assets/floor1enemy/Sword Skeleton.png",
		],
		"sprite_weights": [100],
		"name": "Sword Skeleton",
		"max_health": 45,
		"speed": 5,
		"resistances": {
			"Physical": 0.05,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 35,
		"gold_min": 10,
		"gold_max": 35,
		"attacks": [
			{
				"name": "Sword Slash",
				"damage": 7,
				"weight": 35,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Sword Thrust",
				"damage": 9,
				"weight": 30,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Sword Bunt",
				"damage": 3,
				"weight": 25,
				"reaction_time": 1.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Slash > Bunt > Thrust > Bite",
				"weight": 20,
				"stages": [
					{
						"name": "Slash",
						"damage": 7,
						"weight": 35,
						"reaction_time": 2.0,
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false
					},
					{
						"name": "Bunt",
						"damage": 3,
						"weight": 25,
						"reaction_time": 1.2,
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false
					},
					{
						"name": "Sword Thrust",
						"damage": 9,
						"weight": 30,
						"reaction_time": 1.5,
						"can_dodge": true,
						"can_parry": true,
						"can_block": false,
						"guardbreak": false
					},
					{
						"name": "Bite",
						"damage": 12,
						"reaction_time": 1.2,
						"can_dodge": true,
						"can_parry": false,
						"can_block": false,
						"guardbreak": false
					}
				],
				"interruptible": false
			}
		],
		"loot_table": [
			
			{"item_id": "steel_sword", "chance": 0.30}
		]
	},
	"bat": {
		"sprites": [
			"res://Assets/floor1enemy/Bat.png",
			"res://Assets/floor1enemy/Vampire Bat.png"
		],
		"sprite_weights": [75, 25],
		"name": "Bat",
		"max_health": 20,
		"speed": 20,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 20,
		"gold_min": 5,
		"gold_max": 15,
		"attacks": [
			{
				"name": "Wing Attack",
				"damage": 4,
				"weight": 50,
				"reaction_time": 2.0,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Dive",
				"damage": 5,
				"weight": 50,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Nibble",
				"damage": 3,
				"weight": 35,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": false,
				"can_block": false,
				"guardbreak": false,
				"on_hit_effects": [
					{"id": "poison", "stacks": 1, "turns": 2}
				]
			},
		],
		"loot_table": [
			{"item_id": "bat_wing", "chance": 0.25},
			{"item_id": "batsickle", "chance": 0.20}
		]
	},

	"rogue_skeleton": {
		"sprite": "res://Assets/floor1enemy/Rogue Skeleton.png",
		"name": "Rogue Skeleton",
		"max_health": 26,
		"speed": 30,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
		},
		"xp_reward": 30,
		"gold_min": 8,
		"gold_max": 22,
		"attacks": [
			{
				"name": "Dagger Slash",
				"damage": 5,
				"weight": 45,
				"reaction_time": 1.8,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Quick Stab",
				"damage": 7,
				"weight": 35,
				"reaction_time": 1.5,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Double Cut",
				"weight": 20,
				"stages": [
					{
						"name": "First Cut",
						"damage": 4,
						"reaction_time": 2.0,
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false
					},
					{
						"name": "Second Cut",
						"damage": 7,
						"reaction_time": 1.2,
						"can_dodge": true,
						"can_parry": true,
						"can_block": false,
						"guardbreak": false
					}
				],
				"interruptible": false
			}
		],
	"loot_table": [
		{"item_id": "skeleton_dagger", "chance": 0.25},
		{"item_id": "rogue_hood", "chance": 0.20}
		]
	},

	"caestus_skeleton": {
		"sprite": "res://Assets/floor1enemy/Caestus Skeleton.png",
		"name": "Caestus Skeleton",
		"max_health": 40,
		"speed": 8,
		"resistances": {
			"Physical": 0.10,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0
		},
		"xp_reward": 32,
		"gold_min": 8,
		"gold_max": 25,
		"attacks": [
			{
				"name": "Jab",
				"damage": 5,
				"weight": 45,
				"reaction_time": 1.8,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Heavy Hook",
				"damage": 11,
				"weight": 35,
				"reaction_time": 2.7,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			},
			{
				"name": "Uppercut",
				"damage": 9,
				"weight": 20,
				"reaction_time": 2.2,
				"can_dodge": true,
				"can_parry": false,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Barrage",
				"weight": 20,
				"repeated_attack": {
					"min_hits": 2,
					"max_hits": 6,
					"first_reaction_time": 2.0,
					"hit": {
						"name": "Punch",
						"damage": 3,
						"weight": 0,
						"reaction_time": 1.3,
						"damage_type": "Blunt",
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false,
					},
					"finisher": {
						"name": "Bite",
						"damage": 6,
						"weight": 0,
						"reaction_time": 1.5,
						"damage_type": "Pierce",
						"can_dodge": true,
						"can_parry": false,
						"can_block": false,
						"guardbreak": false,
					},
				},
			}
		],
		"loot_table": [
			{"item_id": "skeleton_caestus", "chance": 0.25},
			{"item_id": "skeleton_pauldron", "chance": 0.20}
		]
	},

	"spear_skeleton": {
		"sprite": "res://Assets/floor1enemy/Spear Skele no helm.png",
		"name": "Spear Skeleton",
		"max_health": 34,
		"speed": 14,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
		},
		"xp_reward": 30,
		"gold_min": 10,
		"gold_max": 25,
		"attacks": [
			{
				"name": "Spear Thrust",
				"damage": 8,
				"weight": 45,
				"reaction_time": 1.9,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Spear Sweep",
				"damage": 7,
				"weight": 35,
				"reaction_time": 2.4,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Lunging Thrust",
				"damage": 12,
				"weight": 20,
				"reaction_time": 2.7,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			}
		],
		"loot_table": [
			{"item_id": "skeleton_spear", "chance": 0.25}
		]
	},

	"helmet_spear_skeleton": {
		"sprite": "res://Assets/floor1enemy/Spear Skeleton.png",
		"name": "Helmet Spear Skeleton",
		"max_health": 52,
		"speed": 10,
		"resistances": {
			"Physical": 0.15,
			"Elemental": 0.0,
			"Slash": 0.05,
			"Blunt": 0.0,
		},
		"xp_reward": 42,
		"gold_min": 15,
		"gold_max": 35,
		"attacks": [
			{
				"name": "Armored Thrust",
				"damage": 10,
				"weight": 45,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Spear Crush",
				"damage": 14,
				"weight": 30,
				"reaction_time": 3.0,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			},
			{
				"name": "Thrust Combo",
				"weight": 25,
				"stages": [
					{
						"name": "First Thrust",
						"damage": 7,
						"reaction_time": 2.2,
						"can_dodge": true,
						"can_parry": true,
						"can_block": false,
						"guardbreak": false
					},
					{
						"name": "Final Thrust",
						"damage": 12,
						"reaction_time": 1.4,
						"can_dodge": true,
						"can_parry": true,
						"can_block": false,
						"guardbreak": false
					}
				],
				"interruptible": false
			}
		],
			"loot_table": [
				{"item_id": "reinforced_spear", "chance": 0.25},
				{"item_id": "skeleton_helm", "chance": 0.20}
		]
	},

	# Damage and HP below are base values, before wave scaling.
	"slime_potentate": {
		"name": "Slime Potentate",
		"sprite": "res://Assets/Bosses/SlimePotentate.png",
		"max_health": 240,
		"speed": 12,
		"resistances": {
			"Physical": 0.10,
		},
		"xp_reward": 120,
		"gold_min": 100,
		"gold_max": 150,
		"phases": {
			"summon_health_fraction": 0.50,
			"attacks_before_absorb": 2,
			"absorb_damage_per_slime": 0.20,
			"absorb_turns": 4,
			"explosion_health_fraction": 0.05,
			"explosion_attack": {
				"name": "Slime Explosion",
				"damage": 55,
				"weight": 0,
				"reaction_time": 2.0,
				"damage_type": "Magic",
				"can_dodge": false,
				"can_parry": false,
				"can_block": false,
				"guardbreak": false,
				"aoe": true,
				"unavoidable": true,
			},
		},
		"attacks": [
			{
				"name": "Slime Crush",
				"damage": 16,
				"weight": 28,
				"reaction_time": 2.4,
				"damage_type": "Blunt",
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false,
				"aoe": true,
			},
			{
				"name": "Slime Whirlwind",
				"damage": 13,
				"weight": 24,
				"reaction_time": 2.0,
				"damage_type": "Wind",
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false,
			},
			{
				"name": "Slime Ball",
				"damage": 11,
				"weight": 26,
				"reaction_time": 2.0,
				"damage_type": "Magic",
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false,
			},
			{
				"name": "Slime Chain",
				"weight": 22,
				"stages": [
					{
						"name": "Slime Bolt",
						"damage": 8,
						"weight": 0,
						"reaction_time": 2.2,
						"damage_type": "Lightning",
						"can_dodge": true,
						"can_parry": false,
						"can_block": true,
						"guardbreak": false,
					},
					{
						"name": "Slime Slash",
						"damage": 7,
						"weight": 0,
						"reaction_time": 1.6,
						"damage_type": "Slash",
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false,
					},
					{
						"name": "Slime Crush",
						"damage": 16,
						"weight": 0,
						"reaction_time": 2.4,
						"damage_type": "Blunt",
						"can_dodge": true,
						"can_parry": false,
						"can_block": true,
						"guardbreak": false,
						"aoe": true,
					},
					{
						"name": "Slime Lick",
						"damage": 6,
						"weight": 0,
						"reaction_time": 1.8,
						"damage_type": "Blunt",
						"can_dodge": true,
						"can_parry": true,
						"can_block": false,
						"guardbreak": false,
						"on_hit_effects": [
							{
								"id": "sluggish",
								"turns": 2,
							},
						],
					},
				],
			},
		],
		"loot_table": [
			{
				"item_id": "slime_goop",
				"chance": 1.0,
			},
		],
	},
}
