extends RefCounted
const EFFECTS = {
	"thwart": {"name": "Thwart", "duration": 2, "max_stacks": 1},
	"bleed": {
		"name": "Bleed",
		"damage_per_turn": 3.0,
		"duration": 3,
		"damage_type": "Physical",
		"max_stacks": 100,
		"damage_scales_with_stacks": false
	},
	"burn": {
		"name": "Burn",
		"damage_per_turn": 3.0,
		"duration": 2,
		"damage_type": "Fire",
		"max_stacks": 1
	},
	"frostbite": {
		"name": "Frostbite",
		"damage_per_turn": 1.0,
		"duration": 4,
		"damage_type": "Frost",
		"speed_modifier": -10,
		"max_stacks": 1
	},
	"poison": {
		"name": "Poison",
		"damage_per_turn": 1.0,
		"duration": 5,
		"damage_type": "Nature",
		"max_stacks": 100,
		"damage_scales_with_stacks": true,
		"milestone_bonus": false
	},
	"decay": {
		"name": "Decay",
		"damage_per_turn": 2.0,
		"duration": 3,
		"damage_type": "Curse",
		"physical_resistance_modifier": -0.10,
		"max_stacks": 1
	},
	"cursed_flame": {
		"name": "Cursed Flame",
		"damage_per_turn": 1.0,
		"duration": -1,
		"damage_type": "Cursed Fire",
		"permanent": true,
		"max_stacks": 1
	},
	"freeze": {
		"name": "Freeze",
		"duration": 1,
		"skip_action": true,
		"max_stacks": 1
	},
	"shock": {
		"name": "Shock",
		"duration": 2,
		"reaction_time_modifier": -0.15,
		"max_stacks": 1
	},
	"corrosion": {
		"name": "Corrosion",
		"duration": 3,
		"physical_resistance_modifier": -0.05,
		"max_stacks": 3
	},
	"weakness": {
		"name": "Weakness",
		"duration": 2,
		"outgoing_damage_modifier": -0.25,
		"max_stacks": 100
	},
	"vulnerable": {
		"name": "Vulnerable",
		"duration": 2,
		"incoming_damage_modifier": 0.25,
		"max_stacks": 100
	},
	"regeneration": {
		"name": "Regeneration",
		"duration": 3,
		"healing_per_turn": 3.0,
		"max_stacks": 1
	},
	"protected": {
		"name": "Protected",
		"duration": -1,
		"permanent": true,
		"max_stacks": 1
	}
}
