extends RefCounted

const SIZE := 9
const BOSS := Vector2i(4, 4)
const DIRECTIONS := [Vector2i.UP, Vector2i.LEFT, Vector2i.DOWN, Vector2i.RIGHT]
enum EnemyTier { EASY, MEDIUM, HARD, EXPERT, MASTER, DEMON }

const ENEMY_TIERS := {
	EnemyTier.EASY: ["slime", "bat", "skeleton"],
	EnemyTier.MEDIUM: ["spear_skeleton", "rogue_skeleton"],
	EnemyTier.HARD: ["caestus_skeleton", "sword skeleton", "helmet_spear_skeleton"],
	EnemyTier.EXPERT: [],
	EnemyTier.MASTER: [],
	EnemyTier.DEMON: [],
}
const MYSTERY_TYPES := ["combat", "campfire", "treasure"]
const ROOM_LIMITS := {
	"combat": Vector2i(12, 20),
	"treasure": Vector2i(2, 4),
	"campfire": Vector2i(2, 5),
	"shop": Vector2i(0, 1),
	"mystery": Vector2i(4, 10),
	"empty": Vector2i(5, 10),
}

var rooms: Dictionary = {}
var spawn := Vector2i.ZERO
var rng := RandomNumberGenerator.new()


func generate(floor_seed: int) -> void:
	rng.seed = floor_seed
	rooms.clear()
	var counts := {}
	var room_total := 0
	while room_total < 30 or room_total > 45:
		room_total = 1
		for kind in ROOM_LIMITS:
			var limits: Vector2i = ROOM_LIMITS[kind]
			counts[kind] = rng.randi_range(limits.x, limits.y)
			room_total += counts[kind]

	# Carve from an approach to the outer two rings, then grow from the
	# connected rooms. The boss is added afterwards, so it cannot cut off rooms.
	var outward: Vector2i = _pick(DIRECTIONS)
	var sideways := Vector2i(-outward.y, outward.x)
	var cell := BOSS + outward
	var layout := {cell: true}
	var spawn_distance := rng.randi_range(3, 4)
	for distance in range(2, spawn_distance + 1):
		if rng.randf() < 0.45:
			cell += sideways * (1 if rng.randf() < 0.5 else -1)
			layout[cell] = true
		cell += outward
		layout[cell] = true
	spawn = cell

	var frontier: Array[Vector2i] = []
	for occupied in layout:
		_add_frontier(occupied, layout, frontier)
	while layout.size() < room_total - 1:
		var candidate: Vector2i = _take(frontier)
		layout[candidate] = true
		_add_frontier(candidate, layout, frontier)

	var unplaced: Array[Dictionary] = []
	counts["empty"] -= 1
	for kind in counts:
		for index in range(counts[kind]):
			var mystery: bool = kind == "mystery"
			var actual_kind: String = _pick(MYSTERY_TYPES) if mystery else kind
			unplaced.append(_make_room(actual_kind, mystery))

	rooms[spawn] = _make_room("empty")
	rooms[BOSS] = _make_room("boss")
	for direction in DIRECTIONS:
		var neighbor: Vector2i = BOSS + direction
		if not layout.has(neighbor):
			continue
		var eligible: Array[int] = []
		for index in range(unplaced.size()):
			if unplaced[index]["kind"] == "combat":
				eligible.append(index)
		rooms[neighbor] = unplaced.pop_at(_pick(eligible))

	for position in layout:
		if not rooms.has(position):
			rooms[position] = _take(unplaced)

	var distances := _distances_from_boss()
	for position in rooms:
		var room: Dictionary = rooms[position]
		var kind: String = room["kind"]
		if kind == "combat" or (kind == "treasure" and rng.randf() < 0.5):
			room["enemies"] = _roll_enemies(distances[position])
		room["distance"] = distances[position]


func _make_room(kind: String, mystery := false) -> Dictionary:
	return {
		"kind": kind,
		"mystery": mystery,
		"visited": false,
		"resolved": kind == "empty",
		"enemies": [],
		"chest": "closed" if kind == "treasure" else "none",
	}


func _add_frontier(position: Vector2i, layout: Dictionary, frontier: Array[Vector2i]) -> void:
	for direction in DIRECTIONS:
		var neighbor: Vector2i = position + direction
		if neighbor == BOSS or not Rect2i(0, 0, SIZE, SIZE).has_point(neighbor):
			continue
		if not layout.has(neighbor) and neighbor not in frontier:
			frontier.append(neighbor)


func _distances_from_boss() -> Dictionary:
	var distances := {BOSS: 0}
	var queue: Array[Vector2i] = [BOSS]
	while not queue.is_empty():
		var center: Vector2i = queue.pop_front()
		for direction in DIRECTIONS:
			var neighbor: Vector2i = center + direction
			if rooms.has(neighbor) and not distances.has(neighbor):
				distances[neighbor] = distances[center] + 1
				queue.append(neighbor)
	return distances


func _roll_enemies(distance: int) -> Array[String]:
	var weights := Vector3(0.65, 0.28, 0.07)
	var large_chance := 0.15
	if distance == 1:
		weights = Vector3(0.0, 0.0, 1.0)
		large_chance = 0.75
	elif distance == 2:
		weights = Vector3(0.25, 0.35, 0.40)
		large_chance = 0.55
	elif distance <= 5:
		weights = Vector3(0.45, 0.35, 0.20)
		large_chance = 0.35

	var count := rng.randi_range(3, 4) if rng.randf() < large_chance else rng.randi_range(1, 2)
	var enemies: Array[String] = []
	for index in range(count):
		var roll := rng.randf()
		var tier := EnemyTier.HARD
		if roll < weights.x:
			tier = EnemyTier.EASY
		elif roll < weights.x + weights.y:
			tier = EnemyTier.MEDIUM
		enemies.append(_pick(ENEMY_TIERS[tier]))
	return enemies


func _pick(values: Array) -> Variant:
	return values[rng.randi_range(0, values.size() - 1)]


func _take(values: Array) -> Variant:
	return values.pop_at(rng.randi_range(0, values.size() - 1))
