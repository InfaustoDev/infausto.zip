extends Node2D
var stat_row_scene = preload("res://stat_row.tscn")
var enemy_slot_scene = preload("res://enemy_slot.tscn")
var enemy_health = 50
var enemy_name = "Slime"
var enemy_xp_reward = 0


var weapon_database = {
	"basic_sword": {
		"name": "Basic Sword",
		"weapon": "Medium",
		"weapon_type": "Sword",
		"base_damage_min": 10.0,
		"base_damage_max": 15.0,
		"scalings": {
			"Medium Weapons": 2.0
		},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"icon": "res://Assets/playerweapons/basicsword.png",
		"attack_speed": 0.0,
		"penetration_min": 0.0,
		"penetration_max": 0.0,
		"enchantments": []
	}
}

var weapon_type_database = {
	"Sword": {
		"attack_speed_bonus": 0.0
	},
	"Rapier": {
		"attack_speed_bonus": 0.0
	},
	"Spear": {
		"attack_speed_bonus": 0.0
	}
}


var equipped_weapon: Dictionary = {}
var next_item_instance_id = 1
var inventory: Array[Dictionary] = []
var base_inventory_capacity = 10
var inventory_capacity = 10
var bag_open = false
var saved_combat_visibility: Dictionary = {}
var selected_bag_item_id = -1
var encounter_number = 1
var completed_waves = 0
var xp_bonus_per_wave = 0.15
var pending_loot: Array[Dictionary] = []
var ground_loot_layer: Node2D
var loot_continue_button: Button
const MAX_ENEMY_SLOTS = 4
const ENEMY_SPAWN_ORDER = [1, 2, 0, 3]
var active_enemies = [null, null, null, null]
var selected_enemy_slot = 0
var enemy_turn_queue = []
var current_attacker_slot = -1
var pending_reinforcements = []
var base_player_health = 100
var player_max_health = 100
var pending_regen_message = 0
var player_health = 100
var combat_state = "planning_phase"
var incoming_damage = 0
var pending_vulnerability = 1.0
var player_stats = {
	"Strength": 0,
	"Fortitude": 0,
	"Agility": 0,
	"Intelligence": 0,
	"Willpower": 0,
	"Charisma": 0,
	"Heavy Weapons": 0,
	"Medium Weapons": 0,
	"Light Weapons": 0
}
var racial_stats = {
	"Strength": 0,
	"Fortitude": 0,
	"Agility": 0,
	"Intelligence": 0,
	"Willpower": 0,
	"Charisma": 0,
	"Heavy Weapons": 0,
	"Medium Weapons": 0,
	"Light Weapons": 0
}
var player_level = 1
var player_xp = 0
var player_gold = 0
var stat_points = 10
var max_level = 60
var max_stat_value = 100
var enemy_speed = 0
var chosen_defense = ""
var defense_timer_accelerated = false
var defense_original_duration = 0.0
var successful_blocks = 0
var guard_exhausted = false
var guard_recovery_pending = false
var chosen_attack = ""
var attack_original_duration = 0.0
var attack_elapsed_time = 0.0
var selected_planning_option = 0
var current_enemy_attack = {}
var active_attack_stages = []
var current_attack_stage = 0
var enemy_attacks = []
var enemy_database = {
	"slime": {
		"sprite": "res://Assets/floor1enemy/slime.png",
		"name": "Slime",
		"max_health": 30,
		"speed": 0,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 20,
		"gold_min": 15,
		"gold_max": 30,
		"attacks": [
			{
				"name": "Slime Punch",
				"damage": 3,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Slime Splash",
				"damage": 5,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Slime Crush",
				"damage": 10,
				"weight": 20,
				"reaction_time": 3.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			}
		],
		"loot_table": [
			{"item_id": "basic_sword", "chance": 0.35}
		]
	},
	"skeleton": {
		"sprites": [
			"res://Assets/floor1enemy/Base Angry Skeleton.png",
			"res://Assets/floor1enemy/Base Confused Skeleton.png",
			"res://Assets/floor1enemy/Base Sad Skeleton.png",
			"res://Assets/floor1enemy/Base Skeleton.png"
		],
		"sprite_weights": [25, 25, 25, 25],
		"name": "Skeleton",
		"max_health": 35,
		"speed": 10,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 25,
		"gold_min": 5,
		"gold_max": 25,
		"attacks": [
			{
				"name": "Bone Slash",
				"damage": 7,
				"weight": 40,
				"reaction_time": 2.5,
				"can_dodge": false,
				"can_parry": true,
				"can_block": true,
				"guardbreak": false
			},
			{
				"name": "Rib Thrust",
				"damage": 5,
				"weight": 30,
				"reaction_time": 2.0,
				"can_dodge": true,
				"can_parry": true,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Skull Bash",
				"damage": 15,
				"weight": 15,
				"reaction_time": 3.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": true,
				"guardbreak": true
			},
			{
				"name": "Lunge > Bite",
				"weight": 35,
				"stages": [
					{
						"name": "Lunge",
						"damage": 6,
						"reaction_time": 2.5,
						"can_dodge": false,
						"can_parry": true,
						"can_block": true,
						"guardbreak": false
					},
					{
						"name": "Bite",
						"damage": 12,
						"reaction_time": 1.4,
						"can_dodge": true,
						"can_parry": false,
						"can_block": false,
						"guardbreak": false
					}
				],
				"interruptible": false
			}
		],
		"loot_table": []
	},
	"lesser_slime": {
		"sprite": "res://Assets/floor1enemy/lesserslime.png",
		"name": "Lesser Slime",
		"max_health": 10,
		"speed": 0,
		"resistances": {
			"Physical": 0.0,
			"Elemental": 0.0,
			"Slash": 0.0,
			"Blunt": 0.0,
			"Fire": 0.0,
			"Frost": 0.0,
			"Lightning": 0.0
		},
		"xp_reward": 7,
		"gold_min": 2,
		"gold_max": 5,
		"attacks": [
			{
				"name": "Leg Grab",
				"damage": 3,
				"weight": 50,
				"reaction_time": 2.5,
				"can_dodge": true,
				"can_parry": false,
				"can_block": false,
				"guardbreak": false
			},
			{
				"name": "Pounce",
				"damage": 3,
				"weight": 50,
				"reaction_time": 2.0,
				"can_dodge": false,
				"can_parry": false,
				"can_block": true,
				"guardbreak": false
			}
		],
		"loot_table": []
	}
}


func _ready():
	equipped_weapon = _create_weapon_instance("basic_sword")

	# NEW: Starting sword always has the minimum damage.
	equipped_weapon["base_damage"] = 10.0

	# NEW: Starting sword has no bonus penetration.
	equipped_weapon["penetration"] = 0.0
	
	print("Starting weapon: ", equipped_weapon["name"])
	print("Starting base damage: ", equipped_weapon["base_damage"])
	print("Starting penetration: ", equipped_weapon["penetration"] * 100.0, "%")
	print("Weapon instance ID: ", equipped_weapon["instance_id"])
	
	player_max_health = _calculate_max_health()
	player_health = player_max_health
	get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]
	_update_guard_display()
	get_node("AttackButton").show()
	selected_planning_option = 0
	_update_planning_selection()
	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	get_node("BetweenFightsPanel").hide()
	get_node("BagPanel").hide()
	
	var bag_grid = get_node("BagPanel/BagGrid")
	bag_grid.columns = 5
	bag_grid.add_theme_constant_override("h_separation", 8)
	bag_grid.add_theme_constant_override("v_separation", 8)
	var close_button = get_node("BagPanel/BagCloseButton")
	
	close_button.text = "Bag | Close"
	close_button.add_theme_font_size_override("font_size", 22)
	close_button.add_theme_color_override("font_color", Color("#F0F0F0"))
	close_button.add_theme_color_override("font_hover_color", Color("#FFFFFF"))
	close_button.add_theme_color_override("font_pressed_color", Color("#D0D0D0"))
	
	close_button.pressed.connect(_on_bag_close_button_pressed)
	_setup_bag_item_details()
	_setup_equipped_item_details()

	_setup_ground_loot()
	_setup_loot_continue_button()

	_generate_encounter()
	_layout_ui()


func _setup_ground_loot() -> void:
	ground_loot_layer = Node2D.new()
	ground_loot_layer.name = "GroundLootLayer"
	ground_loot_layer.z_index = 15
	add_child(ground_loot_layer)


func _setup_loot_continue_button() -> void:
	loot_continue_button = Button.new()
	loot_continue_button.name = "LootContinueButton"
	loot_continue_button.text = "Continue"
	loot_continue_button.position = Vector2(960, 545)
	loot_continue_button.size = Vector2(160, 58)
	loot_continue_button.z_index = 20
	loot_continue_button.focus_mode = Control.FOCUS_NONE
	loot_continue_button.add_theme_font_size_override("font_size", 22)
	loot_continue_button.pressed.connect(_on_loot_continue_pressed)

	add_child(loot_continue_button)
	loot_continue_button.hide()


func _generate_enemy_loot(enemy_id: String, slot_index: int) -> void:
	if not enemy_database.has(enemy_id):
		return

	var enemy_data = enemy_database[enemy_id]
	var loot_table = enemy_data.get("loot_table", [])

	for drop in loot_table:
		if randf() >= drop["chance"]:
			continue

		var item = _create_weapon_instance(drop["item_id"])

		if item.is_empty():
			continue

		pending_loot.append(item)

		_spawn_ground_loot(item, slot_index)

		print(
			"LOOT DROPPED: %s | Damage: %.1f | Instance ID: %d"
			% [
				item["name"],
				item["base_damage"],
				item["instance_id"]
			]
		)

func _spawn_ground_loot(item: Dictionary, slot_index: int) -> void:
	await get_tree().process_frame

	var death_position = _get_enemy_drop_position(slot_index)

	var drop_button = Button.new()
	drop_button.name = "Loot_%d" % item["instance_id"]
	drop_button.size = Vector2(48, 48)
	drop_button.custom_minimum_size = Vector2(48, 48)
	drop_button.focus_mode = Control.FOCUS_NONE
	drop_button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	drop_button.expand_icon = true

	var offset = Vector2(
		randf_range(-55.0, 55.0),
		randf_range(15.0, 65.0)
	)

	drop_button.position = death_position + offset - drop_button.size / 2.0

	var icon_path = item.get("icon", "")

	if icon_path != "":
		var texture = load(icon_path)

		if texture is Texture2D:
			drop_button.icon = texture
		else:
			drop_button.text = "?"
	else:
		drop_button.text = "?"

	drop_button.tooltip_text = "%s\nDamage: %.1f" % [
		item["name"],
		item["base_damage"]
	]

	var normal_style = StyleBoxFlat.new()
	normal_style.bg_color = Color("#181818")
	normal_style.border_color = Color("#777777")
	normal_style.set_border_width_all(1)
	normal_style.set_corner_radius_all(5)

	var hover_style = normal_style.duplicate()
	hover_style.border_color = Color("#E5C35B")
	hover_style.bg_color = Color("#333333")

	drop_button.add_theme_stylebox_override("normal", normal_style)
	drop_button.add_theme_stylebox_override("hover", hover_style)
	drop_button.add_theme_stylebox_override("pressed", hover_style)

	ground_loot_layer.add_child(drop_button)

	drop_button.mouse_entered.connect(
		_on_ground_loot_hovered.bind(item["instance_id"])
	)


func _on_ground_loot_hovered(instance_id: int) -> void:
	if bag_open or combat_state == "between_fights" or combat_state == "game_over":
		return

	var item_index = -1

	for i in range(pending_loot.size()):
		if pending_loot[i]["instance_id"] == instance_id:
			item_index = i
			break

	if item_index == -1:
		return

	if inventory.size() >= _get_inventory_capacity():
		print("Bag Full!")
		return

	var item = pending_loot[item_index]

	if not _add_item_to_inventory(item):
		return

	pending_loot.remove_at(item_index)

	var drop_button = ground_loot_layer.get_node_or_null(
		"Loot_%d" % instance_id
	)

	if drop_button != null:
		drop_button.queue_free()

	print("You collected %s!" % item["name"])
	_add_combat_log(
		"You collected %s!" % item["name"],
		"gold"
	)

	# If the final item is collected after victory, open the stats screen.
	if combat_state == "loot_collection" and pending_loot.is_empty():
		_open_between_fights()


func _clear_ground_loot() -> void:
	for child in ground_loot_layer.get_children():
		child.queue_free()

	pending_loot.clear()


func _load_enemy(enemy_id):
	var enemy_data = enemy_database[enemy_id]
	
	enemy_name = enemy_data["name"]
	enemy_health = enemy_data["max_health"]
	enemy_speed = enemy_data["speed"]
	enemy_attacks = enemy_data["attacks"]
	enemy_xp_reward = enemy_data["xp_reward"]
	
	get_node("Label").text = enemy_name + " HP:" + str(enemy_health)


func _create_enemy_instance(enemy_id):
	var enemy_data = enemy_database[enemy_id]
	var chosen_sprite = enemy_data.get("sprite", "")

	if enemy_data.has("sprites"):
		chosen_sprite = _choose_weighted_sprite(
			enemy_data["sprites"],
			enemy_data["sprite_weights"]
		)

	return {
		"id": enemy_id,
		"name": enemy_data["name"],
		"health": enemy_data["max_health"],
		"max_health": enemy_data["max_health"],
		"speed": enemy_data["speed"],
		"xp_reward": enemy_data["xp_reward"],
		"gold_min": enemy_data["gold_min"],
		"gold_max": enemy_data["gold_max"],
		"attacks": enemy_data["attacks"],
		"resistances": enemy_data.get("resistances", {}).duplicate(true),
		"sprite": chosen_sprite,
	}


func _choose_weighted_sprite(sprites, weights):
	var total_weight = 0
	
	for weight in weights:
		total_weight += weight
	
	var roll = randi_range(1, total_weight)
	
	for i in range(sprites.size()):
		roll -= weights[i]
		
		if roll <= 0:
			return sprites[i]
	
	return sprites.back()

func _spawn_enemy(enemy_id, slot_index):
	if slot_index < 0 or slot_index >= MAX_ENEMY_SLOTS:
		return false
		
	if active_enemies[slot_index] != null:
		return false
	
	if not enemy_database.has(enemy_id):
		return false
	
	active_enemies[slot_index] = _create_enemy_instance(enemy_id)
	
	print(
		"Spawned %s in slot %d" %
		[active_enemies[slot_index]["name"], slot_index + 1]
	)
	
	return true


func _spawn_enemy_in_next_slot(enemy_id):
	for slot_index in ENEMY_SPAWN_ORDER:
		if active_enemies[slot_index] == null:
			return _spawn_enemy(enemy_id, slot_index)
	
	return false


func _get_leftmost_enemy_slot():
	for i in range(MAX_ENEMY_SLOTS):
		if active_enemies[i] != null:
			return i
	
	return -1


func _get_living_enemy_slots():
	var living_slots = []

	for i in range(MAX_ENEMY_SLOTS):
		if active_enemies[i] != null and active_enemies[i]["health"] > 0:
			living_slots.append(i)

	return living_slots


func _select_enemy_by_number(enemy_number):
	var living_slots = _get_living_enemy_slots()
	var index = enemy_number - 1

	if index < 0 or index >= living_slots.size():
		return

	_select_enemy(living_slots[index])


func _select_enemy(slot_index):
	if slot_index < 0 or slot_index >= MAX_ENEMY_SLOTS:
		return
	
	if active_enemies[slot_index] == null:
		return
	
	selected_enemy_slot = slot_index
	_update_target_label()
	_refresh_enemy_slots()


func _select_default_enemy():
	selected_enemy_slot = _get_leftmost_enemy_slot()
	_update_target_label()
	_refresh_enemy_slots()


func _refresh_enemy_slots():
	var container = get_node("EnemySlotsContainer")
	
	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()
	
	for i in range(MAX_ENEMY_SLOTS):
		var slot = enemy_slot_scene.instantiate()
		container.add_child(slot)
		
		var highlighted_slot = selected_enemy_slot

		if current_attacker_slot != -1:
			highlighted_slot = current_attacker_slot

		slot.setup(
			i,
			active_enemies[i],
			i == highlighted_slot
		)
		
		slot.enemy_clicked.connect(_on_enemy_slot_clicked)


func _on_enemy_slot_clicked(slot_index):
	if combat_state != "planning_phase" and combat_state != "attack_preparing":
		return
	
	_select_enemy(slot_index)


func _update_target_label():
	if selected_enemy_slot == -1:
		get_node("Label").text = "No enemies remaining"
		return

	var target = active_enemies[selected_enemy_slot]

	if target != null:
		get_node("Label").text = "%s HP: %s" % [
			target["name"],
			_format_damage(target["health"])
		]


func _living_enemy_count():
	var count = 0
	
	for enemy in active_enemies:
		if enemy != null and enemy["health"] > 0:
			count += 1
	
	return count



func _deploy_reinforcements():
	while not pending_reinforcements.is_empty():
		var next_id = pending_reinforcements.pop_front()

		if not _spawn_enemy_in_next_slot(next_id):
			break

	pending_reinforcements.clear()

	if selected_enemy_slot >= 0 and active_enemies[selected_enemy_slot] != null:
		_select_enemy(selected_enemy_slot)
	else:
		_select_default_enemy()


func _get_enemy_drop_position(slot_index: int) -> Vector2:
	var container = get_node("EnemySlotsContainer")
	
	if slot_index < 0 or slot_index >= container.get_child_count():
		return Vector2(640, 250)
	
	var slot = container.get_child(slot_index)
	
	# Look for the actual enemy sprite.
	var sprite = slot.find_child("EnemySprite", true, false)
	
	if sprite is Control:
		var global_center = sprite.get_global_rect().get_center()
		return ground_loot_layer.to_local(global_center)
	
	if sprite is Node2D:
		return ground_loot_layer.to_local(sprite.global_position)
	
	# Fallback to the center of the slot.
	if slot is Control:
		return ground_loot_layer.to_local(
			slot.get_global_rect().get_center()
		)
	
	return Vector2(640, 250)


func _damage_selected_enemy(
	damage,
	deploy_after_hit = true,
	damage_type_override: String = ""
):
	if selected_enemy_slot < 0:
		return

	if active_enemies[selected_enemy_slot] == null:
		return

	var slot_index = selected_enemy_slot
	var target = active_enemies[slot_index]

	damage = _calculate_damage_against_enemy(
		target,
		damage,
		damage_type_override
	)

	var health_units = maxi(0, roundi(target["health"] * 1000.0))
	var total_damage_units = maxi(0, floori(damage * 1000.0))

	var damage_dealt = mini(total_damage_units, health_units)
	var overkill_units = maxi(0, total_damage_units - health_units)

	var remaining_units = maxi(0, health_units - damage_dealt)

	target["health"] = remaining_units / 1000.0

	_add_combat_log(
		"You attacked %s for %s damage!" %
		[target["name"], _format_damage(damage_dealt / 1000.0)],
		"damage"
	)

	if overkill_units > 0:
		_add_combat_log(
			"OVERKILL! +%s excess damage!" % _format_damage(overkill_units / 1000.0),
			"overkill"
		)

	if remaining_units == 0:

		_gain_xp(target["xp_reward"])

		var gold_reward = randi_range(
			target["gold_min"],
			target["gold_max"]
		)

		_gain_gold(gold_reward)

		# NEW: Generate physical loot at the enemy's death position.
		_generate_enemy_loot(target["id"], slot_index)

		var split_slime = target["id"] == "slime"
		active_enemies[slot_index] = null

		if split_slime:
			for i in range(4):
				pending_reinforcements.append("lesser_slime")

			_add_combat_log(
				"The Slime splits into four Lesser Slimes!",
				"warning"
			)

	if deploy_after_hit:
		_deploy_reinforcements()
	else:
		_refresh_enemy_slots()


func _perform_wide_slash():
	if _living_enemy_count() == 0:
		return

	var damage = _calculate_player_attack_damage(0.7)
	var selected_target = selected_enemy_slot
	
	_add_combat_log("You used Wide Slash!", "damage")
	
	for slot_index in range(MAX_ENEMY_SLOTS):
		var enemy = active_enemies[slot_index]
	
		if enemy == null or enemy["health"] <= 0:
			continue
	
		var enemy_time_limit = _calculate_action_time(
			3.0,
			enemy["speed"]
		)
	
		if attack_elapsed_time <= enemy_time_limit:
			var final_damage = damage
	
			if slot_index == selected_target:
				final_damage += _calculate_player_attack_damage(0.5)
	
			selected_enemy_slot = slot_index
			_damage_selected_enemy(final_damage, false)
		else:
			_add_combat_log(
				"You were too slow! %s dodged your attack!" % enemy["name"],
				"failure"
			)
	
	if selected_target >= 0 and active_enemies[selected_target] != null:
		selected_enemy_slot = selected_target

	_deploy_reinforcements()


func _get_enemy_turn_order():
	var speed_groups = {}

	for i in range(MAX_ENEMY_SLOTS):
		var enemy = active_enemies[i]
	
		if enemy == null or enemy["health"] <= 0:
			continue
	
		var speed = enemy["speed"]

		if not speed_groups.has(speed):
			speed_groups[speed] = []
	
		speed_groups[speed].append(i)
	
	var speeds = speed_groups.keys()
	speeds.sort()
	speeds.reverse()
	
	var order = []
	
	for speed in speeds:
		var group = speed_groups[speed]
		group.shuffle()
		order.append_array(group)
	
	return order


func _begin_enemy_phase(vulnerability):
	pending_vulnerability = vulnerability
	enemy_turn_queue = _get_enemy_turn_order()
	_start_next_enemy_turn()


func _start_next_enemy_turn():
	while not enemy_turn_queue.is_empty():
		var slot_index = enemy_turn_queue.pop_front()
	
		if active_enemies[slot_index] == null:
			continue
	
		current_attacker_slot = slot_index
		_refresh_enemy_slots()
	
		var attacker = active_enemies[slot_index]
	
		enemy_name = attacker["name"]
		enemy_speed = attacker["speed"]
		enemy_attacks = attacker["attacks"]
	
		combat_state = "enemy_preparing"
	
		get_node("AttackLabel").text = \
			"%s is taking its turn..." % enemy_name
	
		get_node("EnemyDelayTimer").start()
		return
	
	current_attacker_slot = -1
	_refresh_enemy_slots()
	combat_state = "planning_phase"
	selected_planning_option = 0
	
	if guard_exhausted:
		_restore_shattered_guard()
	else:
		_recover_guard()
	
	for button in [
		"AttackButton",
		"BagButton",
		"BookButton",
		"RunButton"
	]:
		get_node(button).show()
	
	_update_planning_selection()



func _load_random_enemy():
	var possible_enemies = ["skeleton", "slime"]
	var chosen_enemy = possible_enemies.pick_random()
	
	_load_enemy(chosen_enemy)


func _roll_enemy_count():
	var roll = randi_range(1, 100)
	
	if roll <= 35:
		return 1
	elif roll <= 65:
		return 2
	elif roll <= 85:
		return 3
	else:
		return 4


func _get_wave_type():
	if encounter_number % 10 == 0:
		return "boss"
	
	if encounter_number % 10 == 5:
		return "shop"
	
	return "normal"


func _generate_encounter():
	get_node("CombatLog").clear() 

	_add_combat_log("Wave %d" % encounter_number, "warning")

	if pending_regen_message > 0:
		_add_combat_log(
			"Regeneration restored %d HP!" % pending_regen_message,
			"success"
		)

		pending_regen_message = 0

	# NEW: Remove any abandoned loot from the previous encounter.
	_clear_ground_loot()
	loot_continue_button.hide()

	active_enemies = [null, null, null, null]
	pending_reinforcements.clear()
	enemy_turn_queue.clear()
	current_attacker_slot = -1

	print("Wave type: ", _get_wave_type())

	var enemy_count = _roll_enemy_count()
	var possible_enemies = ["skeleton", "slime"]

	for i in range(enemy_count):
		var enemy_id = possible_enemies.pick_random()
		_spawn_enemy_in_next_slot(enemy_id)

	_select_default_enemy()

	print("Encounter %d: %d enemies spawned" % [
		encounter_number,
		enemy_count
	])


func _on_line_edit_text_changed(new_text: String) -> void:
	var command = new_text.to_lower()

	match command:
		"attack":
			if combat_state == "player_turn" and chosen_attack == "":
				chosen_attack = "attack"
				get_node("LineEdit").editable = false
				get_node("LineEdit").text = ""
				_execute_attack_immediately()

		"heavy attack":
			if combat_state == "player_turn" and chosen_attack == "":
				chosen_attack = "heavy attack"
				get_node("LineEdit").editable = false
				get_node("LineEdit").text = ""
				_execute_attack_immediately()

		"wide slash":
			if combat_state == "player_turn" and chosen_attack == "":
				if _get_total_stat("Strength") >= 25:
					chosen_attack = "wide slash"
					get_node("LineEdit").editable = false
					get_node("LineEdit").text = ""
					_execute_attack_immediately()
				else:
					get_node("LineEdit").text = ""

		"frost wind":
			if combat_state == "player_turn" and chosen_attack == "":
				print("Frost Wind is not implemented yet!")
			get_node("LineEdit").text = ""

		"dodge":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "dodge"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Dodge registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""

		"parry":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "parry"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Parry registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""

		"block":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "block"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Block registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""


func _enemy_attack(damage, health):
	if health == 0:
		return health
	damage = roundi(damage)
	if health > 0:
		var actual_damage = min(damage, health)
		health -= actual_damage
		health = max(0, health)
		get_node("PlayerHP").text = "HP: %d/%d" % [health, player_max_health]
		print(health)
		print("%s attacked you!" % enemy_name)
		if health == 0:
			print("You died to a %s!" % enemy_name)
			get_node("Label").text = "You died by %s!" % enemy_name
			_add_combat_log("You were defeated by %s." % enemy_name, "failure")
	return health


func _finish_player_turn(vulnerability):
	get_node("LineEdit").editable = false
	get_node("LineEdit").hide()

	if _living_enemy_count() == 0 and pending_reinforcements.is_empty():
		# NEW: Stay on the battlefield only if loot remains.
		if not pending_loot.is_empty():
			_enter_loot_collection()
		else:
			_open_between_fights()
	else:
		_begin_enemy_phase(vulnerability)


func _enter_loot_collection() -> void:
	combat_state = "loot_collection"

	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	get_node("ActionTimerBar").hide()
	get_node("ComboTimerBar").hide()

	get_node("AttackLabel").text = "Collect your loot or continue!"

	for button_name in ["AttackButton", "BookButton", "RunButton"]:
		get_node(button_name).hide()

	get_node("BagButton").show()

	loot_continue_button.show()


func _on_loot_continue_pressed() -> void:
	if combat_state != "loot_collection":
		return

	_clear_ground_loot()
	loot_continue_button.hide()
	_open_between_fights()


func _defend(defense_type):
	var damage_taken = incoming_damage
	var result_message = ""
	var attack_name = current_enemy_attack["name"]
	var result_type = "failure"
	
	match defense_type:
		"none":
			result_message = "You failed to react to %s." % attack_name
		"invalid":
			result_message = ""
		"dodge":
			if current_enemy_attack["can_dodge"]:
				damage_taken = 0
				result_message = "You successfully dodged %s." % attack_name
				result_type = "success"
			else:
				result_message = "You failed to dodge %s." % attack_name
	
		"parry":
			if current_enemy_attack["can_parry"]:
				damage_taken = roundi(incoming_damage * 0.10)
				result_message = "You parried %s." % attack_name
				result_type = "success"
			else:
				result_message = "You failed to parry %s." % attack_name
		"block":
			if guard_exhausted:
				result_message = "You failed to block %s! Guard shattered." % attack_name
			
			elif current_enemy_attack["can_block"]:
				if current_enemy_attack["guardbreak"]:
					damage_taken = roundi(incoming_damage * 0.75)
					successful_blocks = 0
					result_message = "%s broke through your guard!" % attack_name
					result_type = "guardbreak"
				
				else:
					successful_blocks += 1
					
					if successful_blocks >= _calculate_block_limit():
						damage_taken = roundi(incoming_damage * 0.75)
						guard_exhausted = true
						guard_recovery_pending = true
						result_message = "Your guard has shattered from exhaustion!"
						result_type = "guardbreak"
					
					else:
						damage_taken = roundi(incoming_damage * 0.35)
						result_message = "You blocked %s. Guard: %d/%d" % [
							attack_name,
							successful_blocks,
							_calculate_block_limit()
						]
						result_type = "success"
			else:
				result_message = "You failed to block %s." % attack_name

	
	var actual_damage_taken = min(damage_taken, player_health)
	if actual_damage_taken > 0:
		result_message += " You took %d damage." % actual_damage_taken
	else:
		result_message += " You took no damage."
	if defense_type != "invalid":
		_add_combat_log(result_message, result_type)
	
	get_node("AttackLabel").text = ""
	
	player_health = _enemy_attack(damage_taken, player_health)
	
	get_node("LineEdit").editable = false
	get_node("LineEdit").hide()
	if player_health > 0 and current_attack_stage + 1 < active_attack_stages.size():
		current_attack_stage += 1
		_start_next_attack_stage()
		return
	if player_health > 0:
		_start_next_enemy_turn()
	else:
		combat_state = "game_over"


func _choose_enemy_attack():
	var total_weight = 0
	
	for attack in enemy_attacks:
		total_weight += attack["weight"]
	
	var roll = randi_range(1, total_weight)
	
	for attack in enemy_attacks:
		roll -= attack["weight"]
		
		if roll <= 0:
			return attack
	
	return enemy_attacks.back()


func _add_combat_log(message, event_type = "normal"):
	var color = "#D0D0D0"
	
	match event_type:
		"success":
			color = "#86C7A0" # Muted green
		"failure":
			color = "#E58B86" # Soft red
		"warning":
			color = "#D8A66A" # Amber
		"damage":
			color = "#75BFFF" # Light blue
		"guardbreak":
			color = "#C59AFF" # Purple
		"gold":
			color = "#E5C35B" # Warm gold yellow
		"overkill":
			color = "#FF55D4" # Vibrant neon pink
	
	var formatted_message = "[color=%s]%s[/color]\n" % [color, message]
	
	get_node("CombatLog").append_text(formatted_message)


func _on_enemy_delay_timer_timeout() -> void:
	_start_enemy_attack()

func _start_enemy_attack():
	if combat_state != "enemy_preparing" and combat_state != "defense_preparing":
		return
	combat_state = "defense_turn"
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = true
	get_node("LineEdit").grab_focus()
	var selected_attack = _choose_enemy_attack()
	
	if selected_attack.has("stages"):
		active_attack_stages = selected_attack["stages"]
	else:
		active_attack_stages = [selected_attack]
	
	if active_attack_stages.size() > 1:
		get_node("ComboTimerBar").value = 100
		get_node("ComboTimerBar").show()
	else:
		get_node("ComboTimerBar").hide()
	
	current_attack_stage = 0
	current_enemy_attack = active_attack_stages[current_attack_stage]
	incoming_damage = roundi(
		current_enemy_attack["damage"] * pending_vulnerability
	)
	print("%s is preparing %s!" % [enemy_name, current_enemy_attack["name"]])
	_add_combat_log("%s is preparing %s!" % [enemy_name, current_enemy_attack["name"]], "warning")
	get_node("AttackLabel").text = "%s is preparing %s!" % [enemy_name, current_enemy_attack["name"]]
	chosen_defense = ""
	defense_timer_accelerated = false
	var base_time = current_enemy_attack["reaction_time"]
	var final_time = _calculate_action_time(base_time)
	defense_original_duration = final_time
	get_node("DefenseTimer").start(final_time)
	get_node("ActionTimerBar").value = 100
	get_node("ActionTimerBar").show()


func _start_next_attack_stage():
	current_enemy_attack = active_attack_stages[current_attack_stage]
	
	incoming_damage = roundi(
		current_enemy_attack["damage"] * pending_vulnerability
	)
	
	chosen_defense = ""
	defense_timer_accelerated = false
	
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = true
	get_node("LineEdit").grab_focus()
	
	get_node("AttackLabel").text = "%s is preparing %s!" % [enemy_name, current_enemy_attack["name"]]
	_add_combat_log("%s follows up with %s!" % [enemy_name, current_enemy_attack["name"]], "warning")
	
	var base_time = current_enemy_attack["reaction_time"]
	var final_time = _calculate_action_time(base_time)
	
	get_node("DefenseTimer").start(final_time)
	
	get_node("ActionTimerBar").value = 0
	get_node("ActionTimerBar").show()
	
	get_node("ComboTimerBar").value = 100
	get_node("ComboTimerBar").show()


func _on_defense_timer_timeout() -> void:
	if chosen_defense == "":
		var attempted_input = get_node("LineEdit").text.strip_edges()

		if not attempted_input.is_empty():
			_add_combat_log(
				'You tried "%s" but it failed!' % attempted_input,
				"failure"
			)
			chosen_defense = "invalid"
		else:
			chosen_defense = "none"
	
	if current_attack_stage == 0:
		get_node("ActionTimerBar").value = 0
	else:
		get_node("ComboTimerBar").value = 0
	
	
	var was_exhausted = guard_exhausted
	var attempted_block = chosen_defense == "block"
	
	_defend(chosen_defense)
	
	if was_exhausted and attempted_block and guard_recovery_pending:
		_restore_shattered_guard()
	
	_update_guard_display()
	
	if combat_state != "defense_turn":
		get_node("ActionTimerBar").hide()
		get_node("ComboTimerBar").hide()


func _calculate_agility_bonus(agility):
	agility = maxi(agility, 0)
	
	var bonus = agility * 0.0095
	
	for milestone in range(10, agility + 1, 10):
		if milestone <= 30:
			bonus += 0.05
		elif milestone <= 60:
			bonus += 0.10
		else:
			bonus += 0.15
	return bonus


func _accelerate_defense_timer():
	if combat_state != "defense_turn":
		return
	
	if chosen_defense == "":
		return
	
	if defense_timer_accelerated:
		return
	
	if active_attack_stages.size() > 1:
		return
	
	var timer = get_node("DefenseTimer")
	
	if timer.is_stopped():
		return
	
	defense_timer_accelerated = true
	timer.start(timer.time_left / 2.0)


func _get_target_speed():
	if selected_enemy_slot < 0 or selected_enemy_slot >= MAX_ENEMY_SLOTS:
		return 0
	
	var target = active_enemies[selected_enemy_slot]
	
	if target == null or target["health"] <= 0:
		return 0
	
	return target["speed"]


func _get_fastest_enemy_speed():
	var fastest_speed = 0
	
	for enemy in active_enemies:
		if enemy == null or enemy["health"] <= 0:
			continue
	
		fastest_speed = maxi(fastest_speed, enemy["speed"])
	
	return fastest_speed


func _calculate_action_time(base_time, speed = enemy_speed):
	var agility_bonus = _calculate_agility_bonus(_get_total_stat("Agility"))
	var speed_multiplier = 100.0 / (100.0 + maxf(speed, 0.0))
	
	var final_time = base_time * speed_multiplier
	final_time *= 1.0 + agility_bonus
	
	return maxf(final_time, 0.001)

func _allocate_stat(stat_name):
	if not player_stats.has(stat_name):
		print("Unknown stat: ", stat_name)
		return false
	
	if stat_points <= 0:
		print("No stat points remaining!")
		return false
	
	if player_stats[stat_name] >= max_stat_value:
		print(stat_name, " has reached its investment limit!")
		return false
	
	player_stats[stat_name] += 1
	stat_points -= 1
	if stat_name == "Fortitude":
		_update_max_health()
	
	if stat_name == "Willpower":
		_update_guard_display()
	
	print("Increased ", stat_name, " to ", _get_total_stat(stat_name))
	print("Remaining stat points: ", stat_points)
	
	return true

func _process(_delta):
	var timer_bar = get_node("ActionTimerBar")
	
	if combat_state == "enemy_preparing":
		var preparation_timer = get_node("EnemyDelayTimer")
		
		if preparation_timer.time_left <= 1.0 and preparation_timer.time_left > 0.0:
			_show_defense_warning()
		
	if combat_state == "defense_turn" or combat_state == "player_turn":
		var timer
		
		if combat_state == "defense_turn":
			timer = get_node("DefenseTimer")
		else:
			timer = get_node("AttackTimer")
		
		if timer.time_left > 0:
			var percentage = (timer.time_left / timer.wait_time) * 100.0
			if combat_state == "defense_turn" and defense_timer_accelerated:
				percentage = (
					timer.time_left * 2.0 / defense_original_duration
				) * 100.0
			if combat_state == "defense_turn" and current_attack_stage > 0:
				get_node("ComboTimerBar").value = percentage
			else:
				timer_bar.value = percentage
	else:
		timer_bar.hide()
		get_node("ComboTimerBar").hide()


func _on_attack_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
		
	combat_state = "attack_preparing"
	
	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).hide()
	get_node("AttackLabel").text = "Prepare to attack!"
	
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = false
	
	get_node("AttackReadyTimer").start()


func _on_attack_ready_timer_timeout() -> void:
	if combat_state != "attack_preparing":
		return
		
	combat_state = "player_turn"
	
	get_node("LineEdit").editable = true
	get_node("LineEdit").grab_focus()
	
	get_node("AttackLabel").text = "Attack!"
	
	chosen_attack = ""
	attack_elapsed_time = 0.0
	var base_time = 3.0
	var final_time = _calculate_action_time(base_time, _get_target_speed())
	
	attack_original_duration = final_time
	get_node("AttackTimer").start(final_time)
	
	get_node("ActionTimerBar").value = 100
	get_node("ActionTimerBar").show()


func _show_defense_warning():
	if combat_state != "enemy_preparing":
		return
	
	combat_state = "defense_preparing"
	
	get_node("AttackLabel").text = "Get ready to defend!"
	
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = false


func _execute_attack_immediately():
	if combat_state != "player_turn":
		return
	
	attack_elapsed_time = attack_original_duration - get_node("AttackTimer").time_left
	
	get_node("AttackTimer").stop()
	_on_attack_timer_timeout()


func _on_attack_timer_timeout() -> void:
	if combat_state != "player_turn":
		return
	
	get_node("ActionTimerBar").value = 0
	get_node("ActionTimerBar").hide()
	
	match chosen_attack:
		"attack":
			var damage = _calculate_player_attack_damage()
			_damage_selected_enemy(damage)
			_finish_player_turn(1.0)
	
		"heavy attack":
			var damage = _calculate_player_attack_damage(1.5, 1.0)
			_damage_selected_enemy(damage)
			_finish_player_turn(1.25)
	
		"wide slash":
			_perform_wide_slash()
			_finish_player_turn(1.0)
	
		_:
			var attempted_input = get_node("LineEdit").text.strip_edges()

			if attempted_input.is_empty():
				_add_combat_log("You failed to attack in time!", "failure")
			else:
				_add_combat_log(
					'You tried "%s" but it failed!' % attempted_input,
					"failure"
				)

			_finish_player_turn(1.0)


func _input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F11 or (event.keycode == KEY_ENTER and event.alt_pressed):
			var current_mode = DisplayServer.window_get_mode()

			if current_mode == DisplayServer.WINDOW_MODE_FULLSCREEN:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			else:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

			get_viewport().set_input_as_handled()


func _unhandled_key_input(event):
	if bag_open:
		return
	
	if not event.pressed or event.echo:
		return
	
	if event.shift_pressed:
		if combat_state != "planning_phase" and combat_state != "attack_preparing":
			return
		
		match event.keycode:
			KEY_1:
				_select_enemy_by_number(1)
			KEY_2:
				_select_enemy_by_number(2)
			KEY_3:
				_select_enemy_by_number(3)
			KEY_4:
				_select_enemy_by_number(4)
			
		return
	
	if combat_state != "planning_phase":
		return
	
	if not event.pressed or event.echo:
		return
	
	
	match event.keycode:
		KEY_1:
			selected_planning_option = 0
		KEY_2:
			selected_planning_option = 1
		KEY_3:
			selected_planning_option = 2
		KEY_4:
			selected_planning_option = 3
		KEY_SPACE:
			_confirm_planning_option()
			return
		_:
			return
	
	_update_planning_selection()


func _confirm_planning_option():
	match selected_planning_option:
		0:
			_on_attack_button_pressed()
		1:
			_on_bag_button_pressed()
		2:
			print("Book selected!")
		3:
			_attempt_escape()


func _update_planning_selection():
	var options = ["Attack", "Bag", "Book", "Run"]
	
	get_node("AttackLabel").text = "Planning Phase"
	
	var buttons = [
		get_node("AttackButton"),
		get_node("BagButton"),
		get_node("BookButton"),
		get_node("RunButton")
	]
	
	for i in range(buttons.size()):
		if i == selected_planning_option:
			buttons[i].modulate = Color("#86C7A0")
		else:
			buttons[i].modulate = Color.WHITE


func _calculate_escape_chance():
	var base_chance = 0.25
	var agility_bonus = (minf(_get_total_stat("Agility"), 100) / 100.0) * 0.50
	
	return base_chance + agility_bonus

func _calculate_block_limit():
	var willpower = _get_total_stat("Willpower")
	var bonus_blocks = floori(willpower / 20.0)
	
	return 4 + bonus_blocks


func _calculate_guard_recovery():
	var willpower = _get_total_stat("Willpower")
	var recovery = 0
	
	if willpower >= 25:
		recovery += 1
	
	if willpower >= 75:
		recovery += 1
	
	if willpower >= 100:
		recovery += 2
	
	return recovery

func _restore_shattered_guard():
	guard_exhausted = false
	guard_recovery_pending = false
	successful_blocks = 0

	_add_combat_log("Your shattered guard has recovered!", "success")
	_update_guard_display()

func _recover_guard():
	if guard_exhausted:
		return
	
	var recovery = _calculate_guard_recovery()
	
	if recovery <= 0 or successful_blocks <= 0:
		return
	
	var actual_recovery = mini(recovery, successful_blocks)
	successful_blocks -= actual_recovery
	
	_add_combat_log(
		"You recovered %d guard!" % actual_recovery,
		"success"
	)
	
	_update_guard_display()


func _update_guard_display():
	var guard_label = get_node("GuardLabel")
	var block_limit = _calculate_block_limit()

	if guard_exhausted:
		guard_label.text = "Guard: SHATTERED"
	else:
		guard_label.text = "Guard: %d/%d" % [
			successful_blocks,
			block_limit
		]


func _calculate_regen():
	var willpower = _get_total_stat("Willpower")
	var regen = floori(willpower / 10.0)
	
	if willpower >= 50:
		regen += 5
	
	if willpower >= 100:
		regen += 5
	
	return regen


func _apply_regen():
	var regen = _calculate_regen()

	if regen <= 0:
		return

	var missing_health = player_max_health - player_health
	var actual_healing = mini(regen, missing_health)

	if actual_healing <= 0:
		return

	player_health += actual_healing
	pending_regen_message = actual_healing

	get_node("PlayerHP").text = "HP: %d/%d" % [
		player_health,
		player_max_health
	]

	_add_combat_log(
		"Regeneration restored %d HP!" % actual_healing,
		"success"
	)


func _calculate_xp_required():
	if player_level >= max_level:
		return 0
	
	return 50 + 25 * (player_level - 1)


func _gain_xp(amount):
	if player_level >= max_level:
		return 0

	var xp_multiplier = 1.0 + (completed_waves * xp_bonus_per_wave)
	var final_xp = roundi(amount * xp_multiplier)

	player_xp += final_xp

	print(
		"XP gained: %d | Wave bonus: +%.0f%% | Multiplier: %.2fx"
		% [
			final_xp,
			completed_waves * xp_bonus_per_wave * 100.0,
			xp_multiplier
		]
	)

	var levels_gained = 0
	
	while player_level < max_level:
		var required_xp = _calculate_xp_required()
	
		if player_xp < required_xp:
			break
	
		player_xp -= required_xp
		player_level += 1
		stat_points += 5
		levels_gained += 1
	
		_add_combat_log(
			"Level up! You reached level %d and gained 5 stat points!"
			% player_level,
			"success"
		)
	
	if player_level >= max_level:
		player_xp = 0
	
	return levels_gained


func _calculate_gold_multiplier() -> float:
	var charisma = _get_total_stat("Charisma")

	var point_bonus = charisma * 0.01
	var milestone_bonus = floori(charisma / 10.0) * 0.05

	return 1.0 + point_bonus + milestone_bonus


func _gain_gold(amount):
	if amount <= 0:
		return

	var multiplier = _calculate_gold_multiplier()
	var final_amount = roundi(amount * multiplier)

	player_gold += final_amount

	_add_combat_log(
		"+%d Gold! Total Gold: %d" % [final_amount, player_gold],
		"gold"
	)


func _get_xp_display():
	if player_level >= max_level:
		return "Level %d (MAX)" % player_level
	
	return "Level %d | XP: %d/%d" % [
		player_level,
		player_xp,
		_calculate_xp_required()
	]


func _calculate_max_health():
	var fortitude = _get_total_stat("Fortitude")
	var milestone_bonus = floori(fortitude / 10.0) * 5
	
	return base_player_health + fortitude + milestone_bonus


func _update_max_health():
	var old_max_health = player_max_health
	
	player_max_health = _calculate_max_health()
	
	var health_difference = player_max_health - old_max_health
	player_health += health_difference
	
	player_health = clampi(player_health, 0, player_max_health)
	
	get_node("PlayerHP").text = "HP: %d/%d" % [
		player_health,
		player_max_health
	]


func _attempt_escape():
	if combat_state != "planning_phase":
		return

	var escape_chance = _calculate_escape_chance()
	var roll = randf()

	print("Agility: ", _get_total_stat("Agility"))
	print("Escape chance: ", escape_chance * 100, "%")
	print("Random roll: ", roll * 100, "%")

	if roll < escape_chance:
		_add_combat_log("You successfully escaped!", "success")

		# NEW: Abandon any uncollected ground loot when escaping.
		_clear_ground_loot()
		loot_continue_button.hide()

		_open_between_fights(true)

	else:
		_add_combat_log("You failed to escape!", "failure")

		for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
			get_node(button).hide()

		_begin_enemy_phase(1.0)


func _on_run_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
	
	selected_planning_option = 3
	_update_planning_selection()
	_confirm_planning_option()


func _on_bag_button_pressed() -> void:
	if bag_open:
		_close_bag()
		return

	# NEW: Allow Bag access while collecting loot after victory.
	if combat_state != "planning_phase" and combat_state != "loot_collection":
		return

	if combat_state == "planning_phase":
		selected_planning_option = 1
		_update_planning_selection()

	_open_bag()


func _open_bag() -> void:
	# NEW: Allow Bag access during post-combat loot collection.
	if bag_open:
		return

	if combat_state != "planning_phase" and combat_state != "loot_collection":
		return

	bag_open = true
	saved_combat_visibility.clear()

	for child in get_children():
		if child is CanvasItem and child.name != "BagPanel":
			saved_combat_visibility[child.name] = child.visible
			child.hide()

	_refresh_bag_grid()
	_refresh_equipped_item_details()
	get_node("BagPanel").show()


func _close_bag() -> void:
	if not bag_open:
		return
	
	get_node("BagPanel").hide()
	_clear_bag_selection()
	
	for node_name in saved_combat_visibility:
		var node = get_node_or_null(NodePath(str(node_name)))
	
		if node is CanvasItem:
			node.visible = saved_combat_visibility[node_name]
	
	saved_combat_visibility.clear()
	bag_open = false


func _refresh_bag_grid() -> void:
	var grid = get_node("BagPanel/BagGrid")
	
	for child in grid.get_children():
		grid.remove_child(child)
		child.queue_free()
	
	for i in range(_get_inventory_capacity()):
		var slot = Button.new()
		slot.custom_minimum_size = Vector2(72, 76)
		slot.focus_mode = Control.FOCUS_NONE
		slot.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		var slot_style = StyleBoxFlat.new()
		slot_style.bg_color = Color("#080808")
		slot_style.border_color = Color("#343434")
		slot_style.set_border_width_all(1)
		slot_style.set_corner_radius_all(5)

		slot.add_theme_stylebox_override("normal", slot_style)
		slot.add_theme_stylebox_override("hover", slot_style)
		slot.add_theme_stylebox_override("pressed", slot_style)
	
		if i < inventory.size():
			var item = inventory[i]
			slot.pressed.connect(
				_on_bag_slot_pressed.bind(item["instance_id"])
			)
	
			slot.tooltip_text = "%s\nDamage: %s" % [
				item["name"],
				str(item["base_damage"])
			]
	
			var icon_path = item.get("icon", "")
	
			if icon_path != "":
				var texture = load(icon_path)
	
				if texture is Texture2D:
					slot.icon = texture
					slot.expand_icon = true
	
		grid.add_child(slot)


func _on_bag_close_button_pressed() -> void:
	_close_bag()


func _setup_bag_item_details() -> void:
	var bag_panel = get_node("BagPanel")
	
	var details = PanelContainer.new()
	details.name = "ItemDetails"
	details.position = Vector2(850, 195)
	details.custom_minimum_size = Vector2(280, 220)
	details.size = Vector2(280, 220)
	details.hide()
	bag_panel.add_child(details)
	
	var layout = VBoxContainer.new()
	layout.name = "VBoxContainer"
	layout.add_theme_constant_override("separation", 10)
	details.add_child(layout)
	
	var info = Label.new()
	info.name = "ItemInfo"
	layout.add_child(info)
	
	var equip_button = Button.new()
	equip_button.text = "Equip"
	equip_button.pressed.connect(_on_bag_equip_pressed)
	layout.add_child(equip_button)
	
	var discard_button = Button.new()
	discard_button.text = "Discard"
	discard_button.pressed.connect(_on_bag_discard_pressed)
	layout.add_child(discard_button)


func _setup_equipped_item_details() -> void:
	var bag_panel = get_node("BagPanel")

	var details = PanelContainer.new()
	details.name = "EquippedDetails"
	details.position = Vector2(40, 195)
	details.custom_minimum_size = Vector2(280, 220)
	details.size = Vector2(280, 220)
	bag_panel.add_child(details)

	var layout = VBoxContainer.new()
	layout.add_theme_constant_override("separation", 10)
	details.add_child(layout)

	var title = Label.new()
	title.text = "Currently Equipped"
	layout.add_child(title)

	var info = Label.new()
	info.name = "EquippedInfo"
	layout.add_child(info)

	_refresh_equipped_item_details()


func _refresh_equipped_item_details() -> void:
	var details = get_node("BagPanel/EquippedDetails")
	var info = details.get_node("VBoxContainer/EquippedInfo") if details.has_node("VBoxContainer/EquippedInfo") else null

	if info == null:
		info = details.get_child(0).get_node("EquippedInfo")

	if equipped_weapon.is_empty():
		info.text = "Nothing equipped"
		return

	info.text = (
		"%s\nBase Damage: %.1f\nType: %s\nPenetration: %.1f%%"
		% [
			equipped_weapon["name"],
			equipped_weapon["base_damage"],
			", ".join(equipped_weapon["damage_types"]),
			equipped_weapon["penetration"] * 100.0
		]
	)


func _on_bag_slot_pressed(instance_id: int) -> void:
	selected_bag_item_id = instance_id

	for item in inventory:
		if item["instance_id"] == instance_id:
			var details = get_node("BagPanel/ItemDetails")
			var info = details.get_node("VBoxContainer/ItemInfo")
	
			info.text = (
				"%s\nBase Damage: %.1f\nType: %s\nPenetration: %.1f%%"
				% [
					item["name"],
					item["base_damage"],
					", ".join(item["damage_types"]),
					item["penetration"] * 100.0
				]
			)
	
			details.show()
			return


func _on_bag_equip_pressed() -> void:
	if selected_bag_item_id == -1:
		return
	
	if _equip_weapon_from_inventory(selected_bag_item_id):
		print("Weapon equipped successfully!")
		_refresh_bag_grid()
		_refresh_equipped_item_details()
		_clear_bag_selection()


func _on_bag_discard_pressed() -> void:
	if selected_bag_item_id == -1:
		return
	
	if _discard_inventory_item(selected_bag_item_id):
		_refresh_bag_grid()
		_clear_bag_selection()


func _clear_bag_selection() -> void:
	selected_bag_item_id = -1
	get_node("BagPanel/ItemDetails").hide()


func _on_book_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
	
	selected_planning_option = 2
	_update_planning_selection()
	_confirm_planning_option()


func _on_attack_button_mouse_entered() -> void:
	selected_planning_option = 0
	_update_planning_selection()


func _on_bag_button_mouse_entered() -> void:
	selected_planning_option = 1
	_update_planning_selection()


func _on_book_button_mouse_entered() -> void:
	selected_planning_option = 2
	_update_planning_selection()


func _on_run_button_mouse_entered() -> void:
	selected_planning_option = 3
	_update_planning_selection()


func _get_total_stat(stat_name):
	return player_stats[stat_name] + racial_stats[stat_name]


func _get_strength_penetration() -> float:
	var strength = _get_total_stat("Strength")
	var milestones = floori(strength / 10.0)
	return milestones * 0.05


func _apply_resistance(
	damage: float,
	resistance: float,
	penetration: float
) -> float:
	var effective_penetration = clampf(penetration, 0.0, 1.0)
	var effective_resistance = resistance * (1.0 - effective_penetration)
	
	return damage * (1.0 - effective_resistance)


func _create_weapon_instance(weapon_id: String) -> Dictionary:
	if not weapon_database.has(weapon_id):
		push_error("Unknown weapon: " + weapon_id)
		return {}
	
	var weapon = weapon_database[weapon_id].duplicate(true)
	
	weapon["template_id"] = weapon_id
	weapon["instance_id"] = next_item_instance_id
	next_item_instance_id += 1
	
	weapon["base_damage"] = (
		randi_range(
			roundi(weapon["base_damage_min"] * 10),
			roundi(weapon["base_damage_max"] * 10)
		) / 10.0
	)
	
	weapon["penetration"] = randf_range(
		weapon["penetration_min"],
		weapon["penetration_max"]
	)
	
	weapon.erase("base_damage_min")
	weapon.erase("base_damage_max")
	weapon.erase("penetration_min")
	weapon.erase("penetration_max")
	
	return weapon
	
	
func _get_equipped_weapon() -> Dictionary:
	return equipped_weapon



func _get_inventory_capacity() -> int:
	return base_inventory_capacity


func _add_item_to_inventory(item: Dictionary) -> bool:
	if item.is_empty():
		return false
	
	if inventory.size() >= _get_inventory_capacity():
		print("Your bag is full!")
		return false
	
	inventory.append(item)
	print("Added to bag: ", item["name"])
	return true


func _remove_item_from_inventory(instance_id: int) -> Dictionary:
	for i in range(inventory.size()):
		if inventory[i]["instance_id"] == instance_id:
			return inventory.pop_at(i)
	
	return {}


func _discard_inventory_item(instance_id: int) -> bool:
	var item = _remove_item_from_inventory(instance_id)
	
	if item.is_empty():
		return false
	
	print("Discarded: ", item["name"])
	return true


func _equip_weapon_from_inventory(instance_id: int) -> bool:
	var item_index = -1
	
	for i in range(inventory.size()):
		if inventory[i]["instance_id"] == instance_id:
			item_index = i
			break
	
	if item_index == -1:
		return false
	
	var new_weapon = inventory[item_index]
	var old_weapon = equipped_weapon
	
	inventory.remove_at(item_index)
	
	if not old_weapon.is_empty():
		inventory.append(old_weapon)
	
	equipped_weapon = new_weapon
	
	print("Equipped: ", equipped_weapon["name"])
	print("Base damage: ", equipped_weapon["base_damage"])
	
	return true



func _get_weapon_penetration() -> float:
	var weapon = _get_equipped_weapon()
	var weapon_penetration = weapon.get("penetration", 0.0)
	var strength_penetration = _get_strength_penetration()

	return clampf(
		weapon_penetration + strength_penetration,
		0.0,
		1.0
	)


func _calculate_damage_against_enemy(
	enemy: Dictionary,
	physical_damage: float,
	damage_type_override: String = ""
) -> float:
	var weapon = _get_equipped_weapon()
	var resistances = enemy.get("resistances", {})
	var penetration = _get_weapon_penetration()
	var total_damage = 0.0
	
	var damage_type = weapon["damage_types"][0]
	
	if damage_type_override != "":
		damage_type = damage_type_override
	
	var physical_resistance = (
		resistances.get("Physical", 0.0)
		+ resistances.get(damage_type, 0.0)
	)
	
	total_damage += _apply_resistance(
		physical_damage,
		clampf(physical_resistance, 0.0, 1.0),
		penetration
	)
	
	for element in weapon["magic_damage"]:
		var elemental_damage = weapon["magic_damage"][element]
	
		var elemental_resistance = (
			resistances.get("Elemental", 0.0)
			+ resistances.get(element, 0.0)
		)
	
		total_damage += _apply_resistance(
			elemental_damage,
			clampf(elemental_resistance, 0.0, 1.0),
			penetration
		)
	
	return floorf(total_damage * 1000.0) / 1000.0


func _get_weapon_damage() -> float:
	var weapon = _get_equipped_weapon()
	var base_damage = weapon["base_damage"]
	var scaling_bonus = 0.0

	for stat_name in weapon["scalings"]:
		var scaling = weapon["scalings"][stat_name]
		var stat_value = _get_total_stat(stat_name)

		scaling_bonus += (stat_value / 5.0) * (scaling / 2.0)

	var total_damage = base_damage + scaling_bonus

	return floorf(total_damage * 1000.0) / 1000.0


func _calculate_player_attack_damage(multiplier: float = 1.0, strength_scaling: float = 0.0) -> float:
	var weapon_damage = _get_weapon_damage()
	var attack_damage = weapon_damage * multiplier
	
	var strength = _get_total_stat("Strength")
	var strength_bonus = (strength / 5.0) * (strength_scaling / 2.0)
	
	attack_damage += strength_bonus
	
	return floorf(attack_damage * 1000.0) / 1000.0


func _format_damage(value: float) -> String:
	var thousandths = maxi(0, roundi(value * 1000.0))
	var hundredths = floori(thousandths / 10.0)

	var whole_part = floori(hundredths / 100.0)
	var decimal_part = hundredths % 100

	if decimal_part == 0:
		return str(whole_part)

	return "%d.%02d" % [whole_part, decimal_part]


func _refresh_stat_display():
	var container = get_node("BetweenFightsPanel/StatsContainer")
	for child in container.get_children():
		child.queue_free()

	for stat_name in player_stats:
		var row = stat_row_scene.instantiate()

		var invested = player_stats[stat_name]
		var racial = racial_stats[stat_name]
		var total = _get_total_stat(stat_name)

		var can_allocate = stat_points > 0 and invested < max_stat_value

		container.add_child(row)
		row.setup(stat_name, invested, racial, total, can_allocate)
		row.stat_requested.connect(_on_stat_requested)

	get_node("BetweenFightsPanel/StatPointsLabel").text = \
		"Available stat points: %d" % stat_points

func _on_stat_requested(stat_name):
	if combat_state != "between_fights":
		return

	if _allocate_stat(stat_name):
		_refresh_stat_display()


func _open_between_fights(escaped = false):
	combat_state = "between_fights"

	if not escaped:
		_apply_regen()

		# A fully defeated wave permanently increases future XP rewards.
		completed_waves += 1

		var bonus_percent = completed_waves * xp_bonus_per_wave * 100.0

		_add_combat_log(
			"Wave %d cleared! XP bonus is now +%.0f%%!"
			% [encounter_number, bonus_percent],
			"success"
		)

		print(
			"Completed waves: %d | Permanent XP bonus: +%.0f%%"
			% [completed_waves, bonus_percent]
		)

	get_node("EnemySlotsContainer").hide()
	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	get_node("AttackLabel").text = ""

	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).hide()

	for node_name in ["Label", "CombatLog", "ActionTimerBar", "ComboTimerBar", "GuardLabel"]:
		get_node(node_name).hide()

	if escaped:
		get_node("BetweenFightsPanel/VictoryLabel").text = "Escaped!"
	else:
		get_node("BetweenFightsPanel/VictoryLabel").text = "Victory!"

	get_node("BetweenFightsPanel/XPLabel").text = _get_xp_display()
	get_node("BetweenFightsPanel/GoldLabel").text = "Gold: %d" % player_gold
	var gold_label = get_node("BetweenFightsPanel/GoldLabel")
	gold_label.position.x = 320 - gold_label.size.x / 2.0

	_refresh_stat_display()
	get_node("BetweenFightsPanel").show()

	get_node("HPBackground").show()
	get_node("PlayerHP").show()




func _on_continue_button_pressed():
	if combat_state != "between_fights":
		return
	
	get_node("BetweenFightsPanel").hide()
	get_node("EnemySlotsContainer").show()
	
	for node_name in ["PlayerHP", "Label", "CombatLog", "GuardLabel"]:
		get_node(node_name).show()
	
	encounter_number += 1
	successful_blocks = 0
	guard_exhausted = false
	guard_recovery_pending = false
	_update_guard_display()
	_generate_encounter()
	
	combat_state = "planning_phase"
	selected_planning_option = 0
	
	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).show()
	
	_update_planning_selection()


func _refresh_combat_header_layout() -> void:
	var target_label = get_node("Label") as Label
	var attack_label = get_node("AttackLabel") as Label
	var input = get_node("LineEdit") as LineEdit
	var bag_button = get_node("BagButton") as Button
	var book_button = get_node("BookButton") as Button
	
	var center_x: float
	var heading_y: float
	
	if input.visible:
		center_x = input.get_global_rect().get_center().x
		heading_y = input.get_global_rect().position.y - 58.0
	else:
		center_x = (bag_button.get_global_rect().get_center().x + book_button.get_global_rect().get_center().x) / 2.0
		heading_y = bag_button.get_global_rect().position.y - 58.0
	
	# Match both headings to the actual center of the active controls.
	for label in [target_label, attack_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	
	target_label.size = Vector2(540, 30)
	attack_label.size = Vector2(540, 34)
	
	attack_label.global_position = Vector2(
		center_x - attack_label.size.x / 2.0,
		heading_y
	)
	
	target_label.global_position = Vector2(
		center_x - target_label.size.x / 2.0,
		heading_y - 40.0
	)


func _layout_ui() -> void:
	# Control geometry
	var layout = {
		"PlayerHP": [Vector2(530, -10), Vector2(220, 36)],
		"GuardLabel": [Vector2(530, 26), Vector2(220, 26)],

		"Label": [Vector2(0, 473), Vector2(1280, 30)],
		"AttackLabel": [Vector2(365, 506), Vector2(550, 34)],

		"LineEdit": [Vector2(490, 565), Vector2(300, 40)],
		"ActionTimerBar": [Vector2(490, 608), Vector2(300, 8)],
		"ComboTimerBar": [Vector2(490, 619), Vector2(300, 8)],

		"CombatLog": [Vector2(8, 490), Vector2(320, 170)],

		"AttackButton": [Vector2(365, 545), Vector2(125, 58)],
		"BagButton": [Vector2(507, 545), Vector2(125, 58)],
		"BookButton": [Vector2(649, 545), Vector2(125, 58)],
		"RunButton": [Vector2(791, 545), Vector2(125, 58)]
	}

	for node_name in layout:
		var control = get_node_or_null(node_name) as Control
		if control == null:
			push_warning("Missing UI node: " + node_name)
			continue

		control.custom_minimum_size = Vector2.ZERO
		control.grow_horizontal = Control.GROW_DIRECTION_END
		control.grow_vertical = Control.GROW_DIRECTION_END
		control.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
		control.scale = Vector2.ONE
		control.rotation = 0.0
		control.position = layout[node_name][0]
		control.size = layout[node_name][1]

	# Player HP and Guard
	var hp_background = get_node_or_null("HPBackground") as ColorRect
	if hp_background == null:
		hp_background = ColorRect.new()
		hp_background.name = "HPBackground"
		add_child(hp_background)

	hp_background.custom_minimum_size = Vector2.ZERO
	hp_background.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	hp_background.position = Vector2(530, 0)
	hp_background.size = Vector2(220, 36)
	hp_background.color = Color("#292929")
	hp_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_background.z_index = 20

	var hp_label = get_node("PlayerHP") as Label
	var guard_label = get_node("GuardLabel") as Label

	for label in [hp_label, guard_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label.z_index = 21

	hp_label.add_theme_font_size_override("font_size", 24)
	guard_label.add_theme_font_size_override("font_size", 18)
	hp_label.add_theme_color_override("font_color", Color.WHITE)
	guard_label.add_theme_color_override("font_color", Color("#D8D8D8"))

	# Centered target and combat announcements
	var target_label = get_node("Label") as Label
	var attack_label = get_node("AttackLabel") as Label

	for label in [target_label, attack_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.layout_direction = Control.LAYOUT_DIRECTION_LTR
		label.autowrap_mode = TextServer.AUTOWRAP_OFF
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		target_label.z_index = 5
		attack_label.z_index = 5

	target_label.add_theme_font_size_override("font_size", 21)
	attack_label.add_theme_font_size_override("font_size", 24)
	target_label.add_theme_color_override("font_color", Color("#E0E0E0"))
	attack_label.add_theme_color_override("font_color", Color.WHITE)

	# Typing box
	var input = get_node("LineEdit") as LineEdit
	input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	input.placeholder_text = "Type your command"
	input.add_theme_font_size_override("font_size", 20)
	input.add_theme_color_override("font_color", Color.WHITE)
	input.add_theme_color_override("font_placeholder_color", Color("#999999"))
	input.add_theme_color_override("caret_color", Color.WHITE)

	var input_style = StyleBoxFlat.new()
	input_style.bg_color = Color("#292929")
	input_style.border_color = Color("#999999")
	input_style.set_border_width_all(1)
	input_style.set_corner_radius_all(4)
	input_style.content_margin_left = 12
	input_style.content_margin_right = 12
	input_style.content_margin_top = 7
	input_style.content_margin_bottom = 7

	input.add_theme_stylebox_override("normal", input_style)
	input.add_theme_stylebox_override("read_only", input_style)

	var focus_style = input_style.duplicate() as StyleBoxFlat
	focus_style.border_color = Color("#D0D0D0")
	input.add_theme_stylebox_override("focus", focus_style)

	# Timer bars below input
	for bar_name in ["ActionTimerBar", "ComboTimerBar"]:
		var bar = get_node(bar_name) as ProgressBar
		bar.show_percentage = false

		var background_style = StyleBoxFlat.new()
		background_style.bg_color = Color("#303030")
		background_style.set_corner_radius_all(4)

		var fill_style = StyleBoxFlat.new()
		fill_style.bg_color = Color("#A0A0A0")
		fill_style.set_corner_radius_all(4)

		bar.add_theme_stylebox_override("background", background_style)
		bar.add_theme_stylebox_override("fill", fill_style)

	# Combat log
	var combat_log = get_node("CombatLog") as RichTextLabel
	combat_log.add_theme_font_size_override("normal_font_size", 17)

	var log_style = StyleBoxFlat.new()
	log_style.bg_color = Color("#292929")
	log_style.set_corner_radius_all(5)
	log_style.content_margin_left = 10
	log_style.content_margin_right = 10
	log_style.content_margin_top = 10
	log_style.content_margin_bottom = 10

	combat_log.add_theme_stylebox_override("normal", log_style)

	# Planning buttons
	for button_name in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		var button = get_node(button_name) as Button
		button.add_theme_font_size_override("font_size", 22)
		button.add_theme_color_override("font_color", Color("#E8E8E8"))

		var button_style = StyleBoxFlat.new()
		button_style.bg_color = Color("#292929")
		button_style.border_color = Color("#777777")
		button_style.set_border_width_all(1)
		button_style.set_corner_radius_all(4)
		button.add_theme_stylebox_override("normal", button_style)

		var hover_style = button_style.duplicate() as StyleBoxFlat
		hover_style.bg_color = Color("#3D3D3D")
		button.add_theme_stylebox_override("hover", hover_style)

		var pressed_style = button_style.duplicate() as StyleBoxFlat
		pressed_style.bg_color = Color("#202020")
		button.add_theme_stylebox_override("pressed", pressed_style)

	# Enemy display
	var enemy_container = get_node("EnemySlotsContainer") as Control
	enemy_container.set_anchors_preset(Control.PRESET_TOP_LEFT)
	enemy_container.position = Vector2(280, 100)
	enemy_container.size = Vector2(1020, 250)
	enemy_container.scale = Vector2(0.70, 0.70)

	if enemy_container is BoxContainer:
		enemy_container.alignment = BoxContainer.ALIGNMENT_CENTER
		enemy_container.add_theme_constant_override("separation", 12)

	# Automatically reposition announcements when typing begins/ends
	if not input.visibility_changed.is_connected(_refresh_combat_header_layout):
		input.visibility_changed.connect(_refresh_combat_header_layout)
	_refresh_combat_header_layout()
