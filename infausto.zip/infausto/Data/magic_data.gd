extends RefCounted

const MAGIC_ELEMENTS = {
	"Flarebreath": "Fire",
	"Terraton": "Earth",
	"Gustemp": "Wind",
	"Blitzten": "Lightning",
	"Hoarfrost": "Frost",
	"Umbra": "Shadow",
	"Hallow": "Holy"
}

const SPELLS = {
	"flame_roar": {
		"name": "Flame Roar", "magic_type": "Flarebreath", "required_investment": 15, "mana_cost": 2,
		"description": "Apply Burn to all enemies for 2 turns."
	},
	"earth_pillars": {
		"name": "Earth Pillars", "magic_type": "Terraton", "required_investment": 15, "mana_cost": 2,
		"description": "For 5 turns, your attacks have a 25% chance to summon an Earth Pillar. Other pillar effects roll separately."
	},
	"wind_cuts": {
		"name": "Wind Cuts", "magic_type": "Gustemp", "required_investment": 15, "mana_cost": 1,
		"description": "Deal 10 base Wind damage with 2.0× Gustemp scaling and apply Bleed for 2 turns."
	},
	"lightning_orbs": {
		"name": "Lightning Orbs", "magic_type": "Blitzten", "required_investment": 15, "mana_cost": 3,
		"description": "Launch 5 orbs, each dealing 4 base Lightning damage with 1.5× Blitzten scaling to a random living enemy."
	},
	"frost_tag": {
		"name": "Frost Tag", "magic_type": "Hoarfrost", "required_investment": 15, "mana_cost": 3,
		"description": "Has an 85% chance to Freeze one enemy for 2 turns."
	},
	"siphon": {
		"name": "Siphon", "magic_type": "Umbra", "required_investment": 15, "mana_cost": 2,
		"description": "Deal 7 base Shadow damage with 1.0× Umbra scaling. Heal for 10% of the damage dealt."
	},
	"holy_sacrifice": {
		"name": "Holy Sacrifice", "magic_type": "Hallow", "required_investment": 15, "mana_cost": 2,
		"description": "Sacrifice 5% of your max HP and deal that amount to all enemies. Gain +25% damage for 1 turn per enemy hit"
	},
	"conjure_blades": {
		"name": "Conjure Blades",
		"magic_type": "",
		"required_investment": 0,
		"scroll_only": true,
		"mana_cost": 2,
		"description": "Launch 2–8 blades at one enemy. Each blade deals 4 damage."
	},
	"call_forth_zeus": {
		"name": "Call Forth Zeus.",
		"magic_type": "Blitzten",
		"required_investment": 50,
		"scroll_only": true,
		"mana_cost": 5,
		"description": "Strike one enemy with a bolt for 30 base Blitzten damage with 1.0× Blitzten scaling. Apply Shock for 5 turns."
	},
	"flare_volley": {
		"name": "Flare Volley",
		"magic_type": "Flarebreath",
		"required_investment": 25,
		"scroll_only": true,
		"mana_cost": 5,
		"description": "Rain fire down 1–6 times on random living enemies. Each hit deals 5 base Fire damage with 0.5× Flarebreath scaling and applies Burn for 1 turn."
	}
}
