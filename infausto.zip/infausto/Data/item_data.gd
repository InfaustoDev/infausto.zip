extends RefCounted
const WEAPONS = {
	"terra": {
		"name": "Worldbreaker Knuckles", "rarity": "Legendary", "item_type": "weapon",
		"weapon": "Light", "weapon_type": "Knuckles",
		"icon": "res://Assets/playerweapons/EarthKnuckles.png",
		"base_damage_min": 20.0, "base_damage_max": 28.0,
		"scalings": {"Terraton": 3.0}, "magic_school": "Terraton",
		"damage_types": ["Blunt"], "magic_damage": {},
		"status_effects": [],
		"rock_pillar": {
			"chance": 0.25,
			"base_damage": 15.0,
			"scaling": 3.5
		},
		"special_attacks": {
			"faultline": {
				"damage_multiplier": 1.25,
				"guaranteed_rock_pillar": true
			}
		},
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"blitz": {
		"name": "Thunderseal Grimoire", "rarity": "Epic", "item_type": "weapon",
		"weapon": "Medium", "weapon_type": "Book",
		"icon": "res://Assets/playerweapons/ElectricBook.png",
		"base_damage_min": 16.0, "base_damage_max": 24.0,
		"scalings": {"Blitzten": 2.0}, "magic_school": "Blitzten",
		"damage_types": [], "magic_damage": {},
		"status_effects": [
			{"id": "shock", "chance": 0.25, "stacks": 1, "turns": 2}
		],
		"special_attacks": {
			"storm verdict": {
				"damage_multiplier": 1.15,
				"guaranteed_effects": [
					{"id": "shock", "stacks": 2, "turns": 2}
				]
			}
		},
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"gust": {
		"name": "Jadewind Greatstaff", "rarity": "Uncommon", "item_type": "weapon",
		"weapon": "Heavy", "weapon_type": "Staff",
		"icon": "res://Assets/playerweapons/GreatEmeraldStaff.png",
		"base_damage_min": 14.0, "base_damage_max": 19.0,
		"scalings": {"Gustemp": 1.4}, "magic_school": "Gustemp",
		"damage_types": [], "magic_damage": {},
		"status_effects": [
			{"id": "weakness", "chance": 0.25, "stacks": 1, "turns": 2}
		],
		"special_attacks": {
			"downdraft": {
				"damage_multiplier": 0.9,
				"guaranteed_effects": [
					{"id": "weakness", "stacks": 1, "turns": 2}
				]
			}
		},
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"hallow": {
		"name": "Dawnbell Greatstaff", "rarity": "Uncommon", "item_type": "weapon",
		"weapon": "Heavy", "weapon_type": "Staff",
		"icon": "res://Assets/playerweapons/HolyStaff.png",
		"base_damage_min": 14.0, "base_damage_max": 19.0,
		"scalings": {"Hallow": 1.4}, "magic_school": "Hallow",
		"damage_types": [], "magic_damage": {},
		"status_effects": [
			{"id": "vulnerable", "chance": 0.25, "stacks": 1, "turns": 2}
		],
		"special_attacks": {
			"dawn verdict": {
				"damage_multiplier": 1.0,
				"guaranteed_effects": [
					{"id": "vulnerable", "stacks": 1, "turns": 2}
				]
			}
		},
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"flarebreath": {
		"name": "Cinderwick Wand", "rarity": "Common", "item_type": "weapon",
		"weapon": "Medium", "weapon_type": "Wand",
		"icon": "res://Assets/playerweapons/JohnWond.png",
		"base_damage_min": 13.0, "base_damage_max": 17.0,
		"scalings": {"Flarebreath": 1.0}, "magic_school": "Flarebreath",
		"damage_types": [], "magic_damage": {},
		"status_effects": [
			{"id": "burn", "chance": 0.25, "stacks": 1, "turns": 1}
		],
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"hoarfrost": {
		"name": "Rimeglass Wand", "rarity": "Common", "item_type": "weapon",
		"weapon": "Medium", "weapon_type": "Wand",
		"icon": "res://Assets/playerweapons/JohnWondBlue.png",
		"base_damage_min": 13.0, "base_damage_max": 17.0,
		"scalings": {"Hoarfrost": 1.0}, "magic_school": "Hoarfrost",
		"damage_types": [], "magic_damage": {},
		"status_effects": [
			{"id": "freeze", "chance": 0.25, "stacks": 1, "turns": 1}
		],
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"umbra": {
		"name": "Graveveil Bow", "rarity": "Epic", "item_type": "weapon",
		"weapon": "Medium", "weapon_type": "Bow",
		"icon": "res://Assets/playerweapons/ShadowBow.png",
		"base_damage_min": 17.0, "base_damage_max": 25.0,
		"scalings": {"Umbra": 2.3}, "magic_school": "Umbra",
		"magic_share": 0.5,
		"damage_types": ["Slash"], "magic_damage": {},
		"status_effects": [
			{"id": "decay", "chance": 0.25, "stacks": 1, "turns": 2}
		],
		"special_attacks": {
			"eclipse arrow": {
				"damage_multiplier": 1.2,
				"guaranteed_effects": [
					{"id": "decay", "stacks": 2, "turns": 3}
				]
			}
		},
		"attack_speed": 0.0, "penetration_min": 0.0, "penetration_max": 0.0,
		"enchantments": []
	},
	"basic_sword": {
		"name": "Basic Sword",
		"rarity": "Common",
		"weapon": "Medium",
		"weapon_type": "Sword",
		"item_type": "weapon",
		"base_damage_min": 10.0,
		"base_damage_max": 14.0,
		"scalings": {
			"Medium Weapons": 1.0
		},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"icon": "res://Assets/playerweapons/basicsword.png",
		"attack_speed": 0.0,
		"penetration_min": 0.0,
		"penetration_max": 0.0,
		"enchantments": []
	},
	"slightly_basic_sword": {
		"name": "Slightly Basic Sword",
		"rarity": "Uncommon",
		"weapon": "Medium",
		"weapon_type": "Sword",
		"item_type": "weapon",
		"base_damage_min": 12.5,
		"base_damage_max": 19.0,
		"scalings": {
			"Medium Weapons": 1.5
		},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"icon": "res://Assets/playerweapons/slightlybasicsword.png",
		"attack_speed": 0.0,
		"penetration_min": 0.0,
		"penetration_max": 0.0,
		"enchantments": []
	},
	"steel_sword": {
		"name": "Steel Sword",
		"rarity": "Uncommon",
		"weapon": "Medium",
		"weapon_type": "Sword",
		"item_type": "weapon",
		"base_damage_min": 16,
		"base_damage_max": 21,
		"scalings": {
			"Medium Weapons": 2.0
		},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"icon": "res://Assets/playerweapons/steelsword.png",
		"attack_speed": 0.0,
		"penetration_min": 0.05,
		"penetration_max": 0.05,
		"enchantments": []
	},
	"batsickle": {
		"name": "Batsickle",
		"rarity": "Uncommon",
		"weapon": "Medium",
		"weapon_type": "Sword",
		"item_type": "weapon",
		"base_damage_min": 10.0,
		"base_damage_max": 18.0,
		"scalings": {
			"Medium Weapons": 2.0
		},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [
			{"id": "bleed", "chance": 0.25, "stacks": 1, "turns": 1},
			{"id": "poison", "chance": 0.25, "stacks": 1, "turns": 1}
		],
		"special_attacks": {
			"wing inject": {
				"damage_multiplier": 0.75,
				"guaranteed_effects": [
					{"id": "bleed", "stacks": 3, "turns": 3},
					{"id": "poison", "stacks": 3, "turns": 3}
				]
			}
		},
		"icon": "res://Assets/playerweapons/Batsickle.png",
		"attack_speed": 0.0,
		"penetration_min": 0.0,
		"penetration_max": 0.0,
		"enchantments": []
	},

	"skeleton_dagger": {
		"name": "Skeleton Dagger",
		"rarity": "Common",
		"weapon": "Light",
		"weapon_type": "Dagger",
		"item_type": "weapon",
		"base_damage_min": 9.0,
		"base_damage_max": 17.0,
		"scalings": {"Light Weapons": 1.5},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"special_attacks": {
			"weak point": {
				"damage_multiplier": 0.5,
				"guaranteed_effects": [
					{"id": "vulnerable", "stacks": 1, "turns": 2},
					{"id": "bleed", "stacks": 2, "turns": 2}
			]
		}
	},
		"icon": "res://Assets/playerweapons/SkeleKnife.png",
		"attack_speed": 0.15,
		"penetration_min": 0.02,
		"penetration_max": 0.05,
		"enchantments": []
	},

	"skeleton_caestus": {
		"name": "Skeleton Caestus",
		"rarity": "Common",
		"weapon": "Light",
		"weapon_type": "Caestus",
		"item_type": "weapon",
		"base_damage_min": 11.0,
		"base_damage_max": 17.0,
		"scalings": {
			"Light Weapons": 1.8,
			"Strength": 1.5
		},

		"damage_types": ["Blunt"],
		"magic_damage": {},
		"status_effects": [],
		"special_attacks": {
			"uppercut": {
				"damage_multiplier": 1.25,
				"chance_effects": [
					{
						"id": "freeze",
						"chance": 0.40,
						"stacks": 1,
						"turns": 1
					}
				]
			},

			"bite": {
				"damage_multiplier": 0.25,
				"guaranteed_effects": [
					{"id": "bleed", "stacks": 5, "turns": 5}
				]
			}
		},
	
		"icon": "res://Assets/playerweapons/SkeleCaestus.png",
		"attack_speed": 0.05,
		"penetration_min": 0.0,
		"penetration_max": 0.0,
		"enchantments": []
	},

	"skeleton_spear": {
		"name": "Skeleton Spear",
		"rarity": "Common",
		"weapon": "Medium",
		"weapon_type": "Spear",
		"item_type": "weapon",
		"base_damage_min": 13.0,
		"base_damage_max": 19.0,
		"scalings": {"Medium Weapons": 1.8},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"special_attacks": {
			"pierce": {
				"damage_multiplier": 1.2,
				"ignore_resistance": true
			}
		},
	
		"icon": "res://Assets/playerweapons/SkeleSpear.png",
		"attack_speed": 0.0,
		"penetration_min": 0.05,
		"penetration_max": 0.10,
		"enchantments": []
	},

	"reinforced_spear": {
		"name": "Reinforced Skeleton Spear",
		"rarity": "Rare",
		"weapon": "Medium",
		"weapon_type": "Spear",
		"item_type": "weapon",
		"base_damage_min": 17.0,
		"base_damage_max": 25.0,
		"scalings": {"Medium Weapons": 1.7},
		"damage_types": ["Slash"],
		"magic_damage": {},
		"status_effects": [],
		"special_attacks": {
			"pierce": {
				"damage_multiplier": 1.2,
				"ignore_resistance": true
			}
		},
		"icon": "res://Assets/playerweapons/ReinforcedSkeleSpear.png",
		"attack_speed": 0.0,
		"penetration_min": 0.10,
		"penetration_max": 0.15,
		"enchantments": []
	},
}

const WEAPON_TYPES = {
	"Sword": {
		"attack_speed_bonus": 0.0
	},
	"Rapier": {
		"attack_speed_bonus": 0.0
	},
	"Spear": {
		"attack_speed_bonus": 0.0
	}
}

const ARMOR = {
	"trailrider_boots": {
		"name": "Trailrider Boots",
		"item_type": "armor", "armor_slot": "boots", "rarity": "Common",
		"health_min": 2, "health_max": 7,
		"resistance_ranges": {"Physical": {"min": 2, "max": 5}},
		"chest_loot": true,
		"icon": "res://Assets/Armor/2cowboyboots.png"
	},
	"windlink_leggings": {
		"name": "Windlink Leggings",
		"item_type": "armor", "armor_slot": "legs", "rarity": "Uncommon",
		"health_min": 4, "health_max": 10,
		"resistance_ranges": {
			"Physical": {"min": 3, "max": 7},
			"Elemental": {"min": 2, "max": 5}
		},
		"gear_bonus_ranges": {"speed_percent": [2, 5]},
		"chest_loot": true,
		"icon": "res://Assets/Armor/ChainLeggings.png"
	},
	"lookout_cape": {
		"name": "Lookout Cape",
		"item_type": "armor", "armor_slot": "cape", "rarity": "Uncommon",
		"health_min": 6, "health_max": 16,
		"chest_loot": true,
		"icon": "res://Assets/Armor/FarmingCapeShiny.png"
	},
	"wellstride_boots": {
		"name": "Wellstride Boots",
		"item_type": "armor", "armor_slot": "boots", "rarity": "Rare",
		"health_min": 4, "health_max": 10,
		"resistance_ranges": {
			"Physical": {"min": 1, "max": 4},
			"Elemental": {"min": 6, "max": 11}
		},
		"mana_regen_bonus": 1,
		"gear_bonus_ranges": {"starting_mana_bonus": [1, 3]},
		"chest_loot": true,
		"icon": "res://Assets/Armor/MagicBoots.png"
	},
	"ring_of_the_deep_well": {
		"name": "Ring of the Deep Well",
		"item_type": "armor", "armor_slot": "accessory", "rarity": "Rare",
		"health_min": 1, "health_max": 5,
		"starting_mana_bonus": 1,
		"gear_bonus_ranges": {"max_mana_bonus": [1, 3]},
		"chest_loot": true,
		"icon": "res://Assets/Armor/Manaring.png"
	},
	"ironwake_ring": {
		"name": "Ironwake Ring",
		"item_type": "armor", "armor_slot": "accessory", "rarity": "Rare",
		"health_min": 1, "health_max": 8,
		"gear_bonus_ranges": {"physical_damage_percent": [1, 4]},
		"chest_loot": true,
		"icon": "res://Assets/Armor/PhysicalEmpowering ring.png"
	},
	"rogue_hood": {
		"name": "Rogue Hood",
		"item_type": "armor",
		"armor_slot": "head",
		"rarity": "Common",
		"health_min": 1,
		"health_max": 6,
		"stat_bonuses": {},
		"stat_bonus_ranges": {
			"Agility": {
				"min": 2,
				"max": 8
			}
		},
		"resistances": {},
		"icon": "res://Assets/Armor/Rogue Hood.png"
	},

	"skeleton_helm": {
		"name": "Skeleton Helm",
		"item_type": "armor",
		"armor_slot": "head",
		"rarity": "Uncommon",
		"health_min": 5,
		"health_max": 15,
		"stat_bonuses": {},
		"resistance_ranges": {
			"Physical": {
				"min": 5,
				"max": 12
			}
		},
		"icon": "res://Assets/Armor/Helm.png"
	},

	"skeleton_pauldron": {
		"name": "Skeleton Pauldron",
		"armor_type": "Pauldron",
		"item_type": "armor",
		"armor_slot": "chest",
		"rarity": "Common",
		"health_min": 3,
		"health_max": 10,
		"stat_bonuses": {},
		"resistance_ranges": {
			"Physical": {
				"min": 3,
				"max": 7
			}
		},
		"icon": "res://Assets/Armor/Pauldron.png"
	}
}

const CONSUMABLES = {
	"enchant_dust": {
		"name": "Enchant Dust",
		"item_type": "enchant_material",
		"rarity": "Epic",
		"enchant_target": "weapon",
		"icon": "res://Assets/use items/EnchantDust.png"
	},
	"enchant_wax": {
		"name": "Enchant Wax",
		"item_type": "enchant_material",
		"rarity": "Epic",
		"enchant_target": "armor",
		"icon": "res://Assets/use items/EnchantWax1.png"
	},
	"scroll_conjure_blades": {
		"name": "Conjure Blades",
		"item_type": "scroll",
		"rarity": "Uncommon",
		"spell_id": "conjure_blades",
		"icon": "res://Assets/use items/Scroll1.png"
	},
	"scroll_call_forth_zeus": {
		"name": "Call Forth Zeus.",
		"item_type": "scroll",
		"rarity": "Uncommon",
		"spell_id": "call_forth_zeus",
		"icon": "res://Assets/use items/Scroll1.png"
	},
	"scroll_flare_volley": {
		"name": "Flare Volley",
		"item_type": "scroll",
		"rarity": "Uncommon",
		"spell_id": "flare_volley",
		"icon": "res://Assets/use items/Scroll1.png"
	},
	"lesser_health_potion": {
		"name": "Lesser Health Potion",
		"item_type": "consumable",
		"rarity": "Common",
		"heal_amount": 10,
		"max_stack": 5,
		"commands": [
			"lesser hp pot",
			"lesser health potion"
		],
		"description": "A small healing potion that restores 10 HP.",
		"icon": "res://Assets/use items/lesserHPpot.png"
	},

	"bat_wing": {
		"name": "Bat Wing",
		"item_type": "consumable",
		"rarity": "Common",
		"heal_amount": 20,
		"max_stack": 5,
		"commands": [
			"bat wing",
			"eat bat wing"
		],
		"on_use_effects": [
			{"id": "poison", "stacks": 3, "turns": 3}
		],
		"description": "Restores 20 HP, But doesnt sit too well.",
		"icon": "res://Assets/use items/Bat wing.png"
	}
}

const SET_BONUSES = {
	"barrage": {
		"required_weapon_types": ["Caestus", "Knuckles", "Fist"],
		"required_chest_armor_type": "Pauldron",
		"reward_text": "Unlocks attack: Barrage",
		"ora_damage_multiplier": 0.4
	}
}


const WEAPON_ENCHANTMENTS = {
	"champion": {
		"name": "Champion",
		"description": "+20% damage while at or above half HP."
	},
	"greed": {
		"name": "Curse of Greed",
		"description": "Converts 20% of damage into gold."
	},
	"unwilling": {
		"name": "Curse of the Unwilling",
		"description": "Status effects you apply spread to everyone."
	},
	"omnivamp": {
		"name": "Omnivamp",
		"description": "Restore 1% of max HP when your attack hits."
	},
	"flare": {
		"name": "Flare",
		"description": "Apply 1 turn of Burn when you damage an enemy."
	},
	"speculation": {
		"name": "Curse of Speculation",
		"description": "On hit, roll a random effect. It can change your HP, posture, or gold, or inflict Vulnerable or Weakness on you or the target."
	},
	"quickdraw": {
		"name": "Quickdraw",
		"description": "Deal 20% more damage in the first third of the attack window."
	},
	"hourglass": {
		"name": "Curse of the Hourglass",
		"description": "Your attack window is 20% shorter. Deal 35% more damage in its final third."
	},
	"clumsy": {
		"name": "Curse of Clumsy",
		"description": "Each attack has a 25% chance to miss and drop your weapon. If you keep your weapon, roll the target's normal loot."
	}
}

const ARMOR_ENCHANTMENTS = {
	"virtuous": {
		"name": "Virtuous",
		"description": "Taking damage that drops you below 20% HP doubles every hit of your next damaging attack."
	},
	"guardly": {
		"name": "Guardly",
		"description": "A block that would shatter your guard from accumulated posture instead deals a full counter and prevents the hit."
	},
	"healthy": {
		"name": "Curse of the Healthy",
		"description": "Heal 5% of max HP after winning a fight. Take 20% more damage while equipped."
	},
	"thwart": {
		"name": "Thwart",
		"description": "Taking damage has a 25% chance to grant +25% physical and magic resistance for 2 turns."
	},
	"speed_demon": {
		"name": "Curse of the Speed Demon",
		"description": "At the start of each turn, roll a 25% chance for half Agility or a 75% chance for 1.5× Agility."
	}
}
