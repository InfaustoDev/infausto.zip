extends RefCounted

# Slime Chest and allied Slime settings. Fractions use 0.25 for 25%.
const BOSS_ID = "slime_potentate"
const CENTER_SLOT = 2
const CHEST_MIN_DROPS = 3
const CHEST_MAX_DROPS = 6
const SUMMON_LIMIT = 4
const SUMMON_HEALTH_MULTIPLIER = 0.75
const SUMMON_TARGET_CHANCE = 0.25
const SLUGGISH_SPEED_MULTIPLIER = 0.75
const FLAMMABLE_SLIME_DAMAGE_MULTIPLIER = 2.0
const BRAIN_MANA_DISCOUNT = 1
const SLIME_SET_NEGATE_CHANCE = 0.20
const STATUS_EFFECTS = {
	"sluggish": {
		"name": "Sluggish",
		"duration": 2,
		"max_turns": 3,
		"description": "25% slower.",
	},
	"flammable_slime": {
		"name": "Flammable Slime",
		"duration": 4,
		"max_turns": 4,
		"description": "Takes double Fire tick damage.",
	},
}

const CHEST_POOL = {
	"Common": ["slime_ball_scroll"],
	"Uncommon": ["slime_brain"],
	"Rare": ["slime_helm", "slime_chest", "slime_legs", "slime_boots"],
	"Epic": ["slime_sword", "slime_in_a_bottle"],
	"Mythic": ["slime_dna"],
}
const PASSIVES = {
	"slime_brain": {
		"name": "Slime Brain",
		"rarity": "Uncommon",
		"max_stack": 99,
		"description": "Each Brain reduces all mana costs by 1, to a minimum of 0.",
	},
	"slime_in_a_bottle": {
		"name": "Slime in a Bottle",
		"rarity": "Epic",
		"max_stack": SUMMON_LIMIT,
		"description": "Each bottle summons one allied Slime at the start of a fight.",
	},
}
const SPELLS = {
	"slime_ball": {
		"damage": 10.0,
		"flammable_turns": 4,
		"name": "Slime Ball",
		"magic_type": "",
		"required_investment": 0,
		"mana_cost": 2,
		"scroll_only": true,
		"description": "Deal 10 unscaled damage and coat an enemy in slime. It takes double Fire tick damage for 4 turns.",
	},
	"slime_summon": {
		"health_cost_fraction": 0.02,
		"name": "Slime Summon",
		"magic_type": "",
		"required_investment": 0,
		"mana_cost": 2,
		"scroll_only": true,
		"description": "Sacrifice 2% max HP to summon a Slime. At four summons, replaces the one with the lowest HP.",
	},
	"slime_crush": {
		"damage_multiplier": 1.5,
		"sluggish_turns": 2,
		"name": "Slime Crush",
		"magic_type": "",
		"required_investment": 0,
		"mana_cost": 3,
		"scroll_only": true,
		"description": "Deal 150% main damage to all enemies and apply Sluggish for 2 turns.",
	},
	"slime_absorb": {
		"heal_fraction": 0.02,
		"damage_multiplier": 1.25,
		"buff_turns": 3,
		"name": "Slime Absorb",
		"magic_type": "",
		"required_investment": 0,
		"mana_cost": 1,
		"scroll_only": true,
		"description": "Consume one allied Slime to recover 2% max HP and gain +25% damage for 3 turns.",
	},
}

static func install_items(weapons: Dictionary, armor: Dictionary, consumables: Dictionary) -> void:
	weapons["slime_sword"] = {
		"name": "Slime Sword", "item_type": "weapon", "rarity": "Epic", "weapon": "Medium", "weapon_type": "Sword",
		"icon": "res://Assets/playerweapons/SlimeSword.png", "base_damage_min": 20.0, "base_damage_max": 30.0,
		"scalings": {"Medium Weapons": 2.5}, "requirements": {"Medium Weapons": 20},
		"damage_types": ["Slash"], "magic_damage": {}, "attack_speed": 0.0,
		"penetration_min": 0.0, "penetration_max": 0.0, "enchantments": [],
		"status_effects": [{"id": "sluggish", "chance": 0.75, "turns": 2}],
		"special_attacks": {"slime splurge": {"damage_multiplier": 0.75, "area_attack": true,
			"guaranteed_effects": [{"id": "sluggish", "turns": 3}]}},
	}
	armor["slime_helm"] = {
		"name": "Slime Helm",
		"armor_slot": "head",
		"item_type": "armor",
		"rarity": "Rare",
		"icon": "res://Assets/Armor/SlimeHelm.png",
		"health_min": 5,
		"health_max": 10,
		"gear_bonus_ranges": {
			"health_regen": [
				1,
				1,
			],
		},
		"slime_set": true,
	}
	armor["slime_chest"] = {
		"name": "Slime Carapace",
		"armor_slot": "chest",
		"item_type": "armor",
		"rarity": "Rare",
		"icon": "res://Assets/Armor/SlimeChest.png",
		"health_min": 8,
		"health_max": 15,
		"gear_bonus_ranges": {
			"health_regen": [
				1,
				2,
			],
		},
		"slime_set": true,
	}
	armor["slime_legs"] = {
		"name": "Slime Leggings",
		"armor_slot": "legs",
		"item_type": "armor",
		"rarity": "Rare",
		"icon": "res://Assets/Armor/Slimepantsbigger.png",
		"health_min": 6,
		"health_max": 12,
		"gear_bonus_ranges": {
			"health_regen": [
				1,
				2,
			],
		},
		"slime_set": true,
	}
	armor["slime_boots"] = {
		"name": "Slime Boots",
		"armor_slot": "boots",
		"item_type": "armor",
		"rarity": "Rare",
		"icon": "res://Assets/Armor/SlimeBoots.png",
		"health_min": 4,
		"health_max": 9,
		"gear_bonus_ranges": {
			"health_regen": [
				1,
				1,
			],
		},
		"slime_set": true,
	}
	consumables["slime_goop"] = {"name": "Slime Goop", "rarity": "Common", "item_type": "consumable",
		"icon": "res://Assets/use items/SlimeGoop.png", "commands": ["slime goop", "use slime goop"],
		"heal_fraction": 0.15, "max_stack": 5, "description": "Restores 15% of your maximum HP."}
	consumables["slime_ball_scroll"] = {"name": "Slime Ball Scroll", "rarity": "Common", "item_type": "scroll",
		"spell_id": "slime_ball", "boss_only": true, "icon": "res://Assets/use items/Scroll1.png"}
	consumables["slime_dna"] = {"name": "Slime DNA", "rarity": "Mythic", "item_type": "slime_dna",
		"boss_only": true, "icon": "res://Assets/general sprites/placeholder.png",
		"description": "Fuse to learn Slime Summon, Slime Crush, and Slime Absorb."}
	for item_id in PASSIVES:
		var item: Dictionary = PASSIVES[item_id].duplicate(true)
		item["item_type"] = "passive"
		item["boss_only"] = true
		item["icon"] = "res://Assets/general sprites/placeholder.png"
		consumables[item_id] = item
