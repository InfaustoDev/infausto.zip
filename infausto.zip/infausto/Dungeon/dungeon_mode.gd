extends "res://main.gd"

const DungeonFloor = preload("res://Dungeon/floor.gd")
const DungeonMinimap = preload("res://Dungeon/minimap.gd")
const MODE_MENU := "res://mode_select.tscn"
const MOVE_KEYS := {
	KEY_W: Vector2i.UP, KEY_1: Vector2i.UP,
	KEY_A: Vector2i.LEFT, KEY_2: Vector2i.LEFT,
	KEY_S: Vector2i.DOWN, KEY_3: Vector2i.DOWN,
	KEY_D: Vector2i.RIGHT, KEY_4: Vector2i.RIGHT,
}

var floor_data := DungeonFloor.new()
var discovered: Dictionary = {}
var current_room := Vector2i.ZERO
var previous_room := Vector2i.ZERO
var room_loot: Dictionary = {}
var loot_spawns_in_progress := 0
var floor_initialized := false
var roster: Array = []
var roster_index := 0
var minimap: DungeonMinimap
var room_actions: HBoxContainer
var rest_button: Button
var merchant_button: Button
var extract_button: Button
var end_run_button: Button


func _ready():
	super._ready()
	_setup_dungeon_controls()
	_begin_floor()


func _setup_dungeon_controls() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 2
	add_child(layer)

	minimap = DungeonMinimap.new()
	layer.add_child(minimap)
	minimap.room_clicked.connect(_move_to_room)

	var layout := CenterContainer.new()
	layout.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(layout)
	layout.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	layout.offset_left = -300
	layout.offset_right = 300
	layout.offset_top = -92
	layout.offset_bottom = -32

	room_actions = HBoxContainer.new()
	room_actions.add_theme_constant_override("separation", 12)
	layout.add_child(room_actions)
	rest_button = _add_room_button("Rest", _rest_at_campfire)
	merchant_button = _add_room_button("Shop", _open_shop)
	extract_button = _add_room_button("Extract", _extract_to_next_floor)
	end_run_button = _add_room_button("End Run", _return_to_menu)


func _add_room_button(caption: String, action: Callable) -> Button:
	var button := Button.new()
	button.text = caption
	button.focus_mode = Control.FOCUS_NONE
	button.custom_minimum_size = Vector2(105, 44)
	button.pressed.connect(action)
	room_actions.add_child(button)
	return button


func _begin_floor() -> void:
	if not floor_initialized:
		ground_loot_layer.queue_free()
	else:
		for storage in room_loot.values():
			storage["layer"].hide()
			storage["layer"].queue_free()
			if is_instance_valid(storage["chest"]):
				storage["chest"].hide()
				storage["chest"].queue_free()

	room_loot.clear()
	discovered.clear()
	floor_data.generate(randi())
	floor_initialized = true
	current_room = floor_data.spawn
	previous_room = current_room
	boss_intro_seen = false
	encounter_number = 1
	_enter_room()


func _room() -> Dictionary:
	return floor_data.rooms[current_room]


func _enter_room() -> void:
	var room := _room()
	room["visited"] = true
	discovered[current_room] = true
	for direction in DungeonFloor.DIRECTIONS:
		var neighbor: Vector2i = current_room + direction
		if floor_data.rooms.has(neighbor):
			discovered[neighbor] = true

	minimap.set_expanded(false)
	_load_room_loot()
	minimap.update_rooms(floor_data.rooms, discovered, current_room)

	if not room["resolved"] and (
		room["kind"] == "boss" or not room["enemies"].is_empty()
	):
		_start_room_fight(room)
	else:
		_show_exploration()


func _load_room_loot() -> void:
	if not room_loot.has(current_room):
		var layer := Node2D.new()
		layer.name = "RoomLoot_%d_%d" % [current_room.x, current_room.y]
		layer.z_index = 30
		add_child(layer)
		var items: Array[Dictionary] = []
		room_loot[current_room] = {"layer": layer, "items": items, "chest": null}

	var storage: Dictionary = room_loot[current_room]
	ground_loot_layer = storage["layer"]
	pending_loot = storage["items"]
	loot_chest = storage["chest"]
	ground_loot_layer.show()


func _show_loot_chest(boss_id: String = "") -> void:
	super._show_loot_chest(boss_id)
	room_loot[current_room]["chest"] = loot_chest


func _on_loot_chest_pressed() -> void:
	super._on_loot_chest_pressed()
	if is_instance_valid(loot_chest) and loot_chest.disabled:
		var room := _room()
		room["chest"] = "opened"
		if room["kind"] == "treasure":
			room["resolved"] = true
		if combat_state == "loot_collection":
			_update_exploration_hint()
		minimap.queue_redraw()


func _spawn_ground_loot(item: Dictionary, slot_index: int, chest_origin: Vector2 = Vector2.INF, chest_landing: Vector2 = Vector2.ZERO) -> void:
	# The inherited function yields one frame before adding the item button.
	loot_spawns_in_progress += 1
	await super._spawn_ground_loot(item, slot_index, chest_origin, chest_landing)
	loot_spawns_in_progress -= 1


func _clear_ground_loot() -> void:
	# Dungeon rooms own their loot and retain their nodes until extraction.
	pass


func _hide_room_loot() -> void:
	_hide_ground_loot_tooltip()
	ground_loot_layer.hide()
	if is_instance_valid(loot_chest):
		loot_chest.hide()


func _show_exploration() -> void:
	combat_state = "loot_collection"
	$BetweenFightsPanel.hide()
	$EnemySlotsContainer.hide()
	$Label.hide()
	$GuardLabel.hide()
	$CombatLog.hide()
	$AttackButton.hide()
	$BookButton.show()
	$RunButton.hide()
	$LineEdit.hide()
	loot_continue_button.hide()
	_hide_attack_stage_bars()
	$BagButton.show()
	$PlayerHP.show()
	$HPBackground.show()

	var room := _room()
	if room["chest"] == "closed" and not is_instance_valid(loot_chest):
		_show_loot_chest(SlimeContent.BOSS_ID if room["kind"] == "boss" else "")
	if is_instance_valid(loot_chest):
		loot_chest.show()
	_update_exploration_hint()

	rest_button.visible = room["kind"] == "campfire" and not room["resolved"]
	merchant_button.visible = room["kind"] == "shop"
	extract_button.visible = room["kind"] == "boss" and room["resolved"]
	end_run_button.visible = extract_button.visible
	minimap.update_rooms(floor_data.rooms, discovered, current_room)


func _update_exploration_hint() -> void:
	if _room()["chest"] == "closed":
		$AttackLabel.text = "Click the chest to open it"
	else:
		$AttackLabel.text = "WASD / 1–4 to move   ·   M for map"


func _can_explore() -> bool:
	return (
		combat_state == "loot_collection"
		and not bag_open
		and not $NotebookLayer/EnemyNotebook.visible
		and not is_instance_valid(dragged_loot_button)
		and loot_spawns_in_progress == 0
	)


func _move_to_room(destination: Vector2i) -> void:
	var displacement := destination - current_room
	if not _can_explore() or absi(displacement.x) + absi(displacement.y) != 1:
		return
	if not floor_data.rooms.has(destination):
		return

	_hide_room_loot()
	previous_room = current_room
	current_room = destination
	_enter_room()


func _input(event):
	if is_instance_valid(minimap) and minimap.visible and _can_explore():
		if event is InputEventMouse and minimap.get_global_rect().has_point(event.position):
			return
	super._input(event)


func _unhandled_key_input(event):
	if _can_explore() and event.pressed and not event.echo:
		if event.keycode == KEY_M:
			minimap.set_expanded(not minimap.expanded)
			get_viewport().set_input_as_handled()
			return
		if MOVE_KEYS.has(event.keycode):
			_move_to_room(current_room + MOVE_KEYS[event.keycode])
			get_viewport().set_input_as_handled()
			return
	super._unhandled_key_input(event)


func _process(delta) -> void:
	super._process(delta)
	var notebook_open: bool = $NotebookLayer/EnemyNotebook.visible
	var obstructed: bool = bag_open or notebook_open or combat_state in ["shop", "between_fights"]
	minimap.visible = not obstructed
	minimap.interactive = _can_explore()
	room_actions.visible = combat_state == "loot_collection" and not obstructed and not minimap.expanded


func _start_room_fight(room: Dictionary) -> void:
	combat_state = "planning_phase"
	selected_planning_option = 0
	successful_blocks = 0
	guard_exhausted = false
	guard_recovery_pending = false
	_update_guard_display()
	$EnemySlotsContainer.show()
	$Label.show()
	$GuardLabel.show()
	$CombatLog.show()
	player_status_container.show()
	for button_name in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button_name).show()

	_hide_room_loot()
	_generate_encounter()
	_update_planning_selection()
	if boss_encounter and not boss_intro_seen:
		_show_boss_intro()


func _generate_encounter() -> void:
	if not floor_initialized:
		return

	var room := _room()
	roster = room["enemies"]
	roster_index = 0
	super._generate_encounter()

	# Chest eligibility in this mode is tied to victory in this room.
	wave_has_chest = false
	if room.has("survivors"):
		active_enemies = room["survivors"]
		pending_reinforcements = room["reinforcements"]
		if room.has("boss_state"):
			var state: Array = room["boss_state"]
			boss_summoned = state[0]
			boss_absorbed = state[1]
			boss_exploded = state[2]
			boss_attacks_since_summon = state[3]
			boss_absorb_turns = state[4]
			boss_absorb_damage = state[5]
		if not pending_reinforcements.is_empty():
			_deploy_reinforcements()
		_select_default_enemy()

	ground_loot_layer.show()


func _roll_enemy_count():
	return roster.size()


func _roll_enemy_type() -> String:
	var enemy_id := str(roster[roster_index])
	roster_index += 1
	return enemy_id


func _get_wave_type():
	return "boss" if _room()["kind"] == "boss" else "normal"


func _get_enemy_wave_multiplier() -> float:
	return 1.0


func _enter_loot_collection() -> void:
	var room := _room()
	if room.get("fight_won", false):
		return
	room["fight_won"] = true
	room["enemies"] = []
	room.erase("survivors")
	room.erase("reinforcements")
	room.erase("boss_state")
	if room["kind"] == "treasure":
		wave_has_chest = true
	else:
		room["resolved"] = true
		if room["kind"] == "boss" or randf() < 0.05:
			room["chest"] = "closed"
			wave_has_chest = room["kind"] == "combat"
	super._enter_loot_collection()
	_apply_regen()
	encounter_number += 1
	_show_exploration()


func _on_loot_continue_pressed() -> void:
	if combat_state == "loot_collection" and not bag_open:
		_show_exploration()


func _open_between_fights(escaped = false):
	if not escaped:
		return

	var room := _room()
	room["survivors"] = active_enemies.duplicate(true)
	room["reinforcements"] = pending_reinforcements.duplicate(true)
	if boss_encounter:
		room["boss_state"] = [
			boss_summoned, boss_absorbed, boss_exploded,
			boss_attacks_since_summon, boss_absorb_turns, boss_absorb_damage,
		]
	_clear_player_status_effects()
	_clear_temporary_summons()
	_hide_room_loot()
	current_room = previous_room
	_enter_room()


func _rest_at_campfire() -> void:
	var room := _room()
	if not _can_explore() or room["kind"] != "campfire" or room["resolved"]:
		return
	room["resolved"] = true
	var previous_hp: int = player_health
	player_health = mini(player_max_health, player_health + roundi(float(player_max_health) * 0.25))
	_refresh_boss_update_hp()
	_hide_room_loot()
	super._open_between_fights(true)
	$BetweenFightsPanel/VictoryLabel.text = "Campfire  ·  +%d HP" % (player_health - previous_hp)
	minimap.queue_redraw()


func _on_continue_button_pressed():
	if combat_state == "between_fights":
		_dismiss_campfire_intro()
		ground_loot_layer.show()
		_show_exploration()


func _open_shop() -> void:
	var room := _room()
	if not _can_explore() or room["kind"] != "shop":
		return

	if not room.has("stock"):
		room["stock"] = _create_dungeon_stock()

	combat_state = "shop"
	_hide_room_loot()
	var layer := CanvasLayer.new()
	layer.layer = 50
	add_child(layer)
	shop_backdrop = ColorRect.new()
	shop_backdrop.color = Color("#242527")
	layer.add_child(shop_backdrop)
	shop_backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	shop_backdrop.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var list := VBoxContainer.new()
	list.custom_minimum_size.x = 440
	list.add_theme_constant_override("separation", 8)
	panel.add_child(list)

	shop_gold_label = Label.new()
	shop_gold_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	shop_gold_label.text = "Shop  ·  %d gold" % player_gold
	list.add_child(shop_gold_label)
	var feedback := Label.new()
	for entry in room["stock"]:
		var item: Dictionary = entry["item"]
		var price: int = entry["price"]
		var button := Button.new()
		button.text = "%s  ·  %d gold" % [item["name"], price]
		button.tooltip_text = _format_item_tooltip(item)
		button.disabled = entry["sold"]
		if button.disabled:
			button.text += "  |  Sold"
		button.pressed.connect(_buy_dungeon_stock.bind(entry, button, feedback))
		list.add_child(button)
	list.add_child(feedback)

	var bag_button := Button.new()
	bag_button.text = "Bag"
	bag_button.pressed.connect(_open_bag)
	list.add_child(bag_button)
	var leave_button := Button.new()
	leave_button.text = "Leave"
	leave_button.pressed.connect(_leave_dungeon_shop.bind(layer))
	list.add_child(leave_button)


func _create_dungeon_stock() -> Array[Dictionary]:
	var materials: Array[String] = []
	var scrolls: Array[String] = []
	for item_id in consumable_database:
		var data: Dictionary = consumable_database[item_id]
		if data.get("boss_only", false):
			continue
		match data.get("item_type"):
			"enchant_material":
				materials.append(item_id)
			"scroll":
				scrolls.append(item_id)

	var stock: Array[Dictionary] = []
	for group in [materials, scrolls]:
		if group.is_empty():
			continue
		var count := randi_range(2, 4) if group == materials else randi_range(1, 2)
		for index in range(count):
			var item := _create_item_instance(str(group.pick_random()))
			var price := roundi(_get_shop_buy_price(_roll_shop_base_price(item)) * 1.5)
			stock.append({"item": item, "price": price, "sold": false})
	return stock


func _buy_dungeon_stock(entry: Dictionary, button: Button, feedback: Label) -> void:
	_buy_shop_item(entry["item"], entry["price"], button, shop_gold_label, feedback)
	entry["sold"] = button.disabled


func _leave_dungeon_shop(layer: CanvasLayer) -> void:
	shop_backdrop.hide()
	shop_backdrop = null
	shop_gold_label = null
	layer.queue_free()
	ground_loot_layer.show()
	_show_exploration()


func _extract_to_next_floor() -> void:
	if _can_explore() and _room()["kind"] == "boss" and _room()["resolved"]:
		_begin_floor()


func _return_to_menu() -> void:
	Engine.time_scale = 1.0
	var result := get_tree().change_scene_to_file(MODE_MENU)
	if result != OK:
		push_error("Could not open the mode menu: %s" % error_string(result))

func _on_book_button_pressed() -> void:
	if combat_state == "loot_collection":
		if not bag_open:
			_open_enemy_notebook()
		return

	super._on_book_button_pressed()
