extends Node2D
const SlimeContent = preload("res://Data/slime_content.gd")
const ItemData = preload("res://Data/item_data.gd")
const ENCHANTED_SLOT_COLOR = Color("#C0D7C6")
var stat_row_scene = preload("res://stat_row.tscn")
var enemy_slot_scene = preload("res://enemy_slot.tscn")
const MagicData = preload("res://Data/magic_data.gd")
const MAGIC_ELEMENTS = MagicData.MAGIC_ELEMENTS
var spells: Dictionary = MagicData.SPELLS.merged(SlimeContent.SPELLS)
var enemy_health = 50
var enemy_name = "Slime"
var enemy_xp_reward = 0
var test_game_speed = 1.0
var rarity_weights = {
	"Common": 32.5,
	"Uncommon": 22.5,
	"Rare": 17.5,
	"Epic": 12.5,
	"Legendary": 7.5,
	"Mythic": 5.0,
	"Exotic": 2.5
}


var weapon_database = ItemData.WEAPONS.duplicate(true)

var weapon_type_database = ItemData.WEAPON_TYPES.duplicate(true)

var status_effect_database = preload("res://Data/status_effect_data.gd").EFFECTS.duplicate(true)

var armor_database = ItemData.ARMOR.duplicate(true)

var consumable_database = ItemData.CONSUMABLES.duplicate(true)

var set_bonus_database = ItemData.SET_BONUSES.duplicate(true)


func _has_set_bonus(bonus_id: String) -> bool:
	var bonus: Dictionary = set_bonus_database.get(bonus_id, {})
	if bonus.is_empty():
		return false

	var weapon_types: Array = bonus.get("required_weapon_types", [])
	if not weapon_types.is_empty() and equipped_weapon.get("weapon_type", "") not in weapon_types:
		return false

	var chest_type = str(bonus.get("required_chest_armor_type", ""))
	var chest_armor: Dictionary = equipped_armor.get("chest", {})
	if not chest_type.is_empty() and chest_armor.get("armor_type", "") != chest_type:
		return false

	var equipped_ids: Array = [equipped_weapon.get("template_id", "")]
	for item in equipped_armor.values():
		equipped_ids.append(item.get("template_id", ""))

	for item_id in bonus.get("required_items", []):
		if item_id not in equipped_ids:
			return false

	return true

var equipped_weapon: Dictionary = {}

var equipped_armor: Dictionary = {
	"head": {},
	"chest": {},
	"legs": {},
	"boots": {},
	"cape": {},
	"accessory_1": {},
	"accessory_2": {},
	"accessory_3": {},
	"accessory_4": {}
}

var next_item_instance_id = 1
var inventory: Array[Dictionary] = []
var next_pickup_order: int = 1
var base_inventory_capacity = 10
var inventory_capacity = 10
var bag_open = false
var saved_combat_visibility: Dictionary = {}
var selected_bag_item_id = -1
var active_enchant_material_id: int = -1
var bag_sort_mode: int = 0
var encounter_number = 1
var completed_waves = 0
var wave_flawless: bool = true
var flawless_awarded: bool = false
var wave_xp_earned: int = 0
var wave_gold_earned: int = 0
var xp_bonus_per_wave = 0.15
var pending_loot: Array[Dictionary] = []
var dragged_loot_id: int = -1
var dragged_loot_button: Button = null
var bag_drag_original_styles: Dictionary = {}
var ground_loot_layer: Node2D
var ground_loot_tooltip: PanelContainer
var loot_continue_button: Button
var wave_has_chest: bool = false
var loot_chest: Button
const CHEST_VARIANTS := {
	"": {
		"name": "chest",
		"closed_icon": "res://Assets/general sprites/chest.png",
		"open_icon": "res://Assets/general sprites/chest1open.png",
	},
	SlimeContent.BOSS_ID: {
		"name": "Slime Chest",
		"closed_icon": "res://Assets/general sprites/SlimeChest.png",
		"open_icon": "res://Assets/general sprites/SlimeChestOpen.png",
		"loot_pool": SlimeContent.CHEST_POOL,
		"min_drops": SlimeContent.CHEST_MIN_DROPS,
		"max_drops": SlimeContent.CHEST_MAX_DROPS,
	},
}
var debug_chest_index := 0
var restart_button: Button
const MAX_ENEMY_SLOTS = 5
const ENEMY_SPAWN_ORDER = [1, 2, 0, 3]
var active_enemies = [null, null, null, null, null]
var selected_enemy_slot = 0
var enemy_turn_queue = []
var current_attacker_slot = -1
var pending_reinforcements = []
var base_player_health = 100
var player_max_health = 100
var pending_regen_message = 0
var player_health = 100
var player_mana: int = 0
var mana_bar: HBoxContainer

var earth_pillars_turns: int = 0
var holy_sacrifice_turns: int = 0

var learned_spell_codes: Dictionary = {}
var spellbook_dialog: AcceptDialog
var spellbook_text: RichTextLabel
var player_active_effects: Array = []
var player_status_container: HFlowContainer
var combat_state = "planning_phase"
var base_crit_chance = 0.05
var base_crit_multiplier = 2.0
var hidden_luck = 0
var incoming_damage = 0
var pending_vulnerability = 1.0
var player_stats = {
	"Strength": 0,
	"Fortitude": 0,
	"Agility": 0,
	"Intelligence": 0,
	"Willpower": 0,
	"Charisma": 0,
	"Heavy Weapons": 0,
	"Medium Weapons": 0,
	"Light Weapons": 0,
	"Flarebreath": 0,
	"Terraton": 0,
	"Gustemp": 0,
	"Blitzten": 0,
	"Hoarfrost": 0,
	"Umbra": 0,
	"Hallow": 0
}
var racial_stats = {
	"Strength": 0,
	"Fortitude": 0,
	"Agility": 0,
	"Intelligence": 0,
	"Willpower": 0,
	"Charisma": 0,
	"Heavy Weapons": 0,
	"Medium Weapons": 0,
	"Light Weapons": 0,
	"Flarebreath": 0,
	"Terraton": 0,
	"Gustemp": 0,
	"Blitzten": 0,
	"Hoarfrost": 0,
	"Umbra": 0,
	"Hallow": 0
}
var player_level = 1
var player_xp = 0
var player_gold = 0
var stat_points = 10
var held_stat_name: String = ""
var stat_hold_timer: float = 0.0
var max_level = 60
var max_stat_value = 100
var enemy_speed = 0
var chosen_defense = ""
var defense_timer_accelerated = false
var defense_original_duration = 0.0
var successful_blocks = 0
var guard_exhausted = false
var guard_recovery_pending = false
var chosen_attack = ""
var virtuous_charged: bool = false
var virtuous_active: bool = false
var speed_demon_factor: float = 1.0
var barrage_hits: int = 0
var focus_damage_ready = false
var focus_used_this_turn = false
var attack_original_duration = 0.0
var attack_elapsed_time = 0.0
var selected_planning_option = 0
var current_enemy_attack = {}
var active_attack_stages = []
var current_attack_stage = 0
var extra_combo_bars: Array[ProgressBar] = []
var enemy_attacks = []
const EnemyData = preload("res://Data/enemy_data.gd")
var enemy_database = EnemyData.ENEMIES.duplicate(true)

const NOTEBOOK_ENEMY_ORDER := {
	1: [
		"lesser_slime", "slime",
		"bat", "skeleton",
		"rogue_skeleton", "spear_skeleton",
		"caestus_skeleton", "sword skeleton",
		"helmet_spear_skeleton", SlimeContent.BOSS_ID,
	],
}

var current_dungeon_floor: int = 1
var notebook_discoveries: Dictionary = {}

func _ready():
	_install_slime_content()
	equipped_weapon = _create_weapon_instance("basic_sword")

	# NEW: Starting sword always has the minimum damage.
	equipped_weapon["base_damage"] = 10.0

	# NEW: Starting sword has no bonus penetration.
	equipped_weapon["penetration"] = 0.0
	
	print("Starting weapon: ", equipped_weapon["name"])
	print("Starting base damage: ", equipped_weapon["base_damage"])
	print("Starting penetration: ", equipped_weapon["penetration"] * 100.0, "%")
	print("Weapon instance ID: ", equipped_weapon["instance_id"])
	
	player_max_health = _calculate_max_health()
	player_health = player_max_health
	get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]
	_update_guard_display()
	get_node("AttackButton").show()
	selected_planning_option = 0
	_update_planning_selection()
	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	get_node("LineEdit").shortcut_keys_enabled = false
	get_node("LineEdit").context_menu_enabled = false
	get_node("LineEdit").middle_mouse_paste_enabled = false
	get_node("BetweenFightsPanel").hide()
	get_node("BetweenFightsPanel").mouse_filter = Control.MOUSE_FILTER_IGNORE
	get_node("BagPanel").hide()
	
	var bag_grid = get_node("BagPanel/BagScroll/BagGrid")
	bag_grid.columns = 5
	bag_grid.add_theme_constant_override("h_separation", 8)
	bag_grid.add_theme_constant_override("v_separation", 8)
	var close_button = get_node("BagPanel/BagCloseButton")
	close_button.position.x = 1010
	
	close_button.text = "Bag | Close"
	close_button.add_theme_font_size_override("font_size", 22)
	close_button.add_theme_color_override("font_color", Color("#F0F0F0"))
	close_button.add_theme_color_override("font_hover_color", Color("#FFFFFF"))
	close_button.add_theme_color_override("font_pressed_color", Color("#D0D0D0"))
	
	close_button.pressed.connect(_on_bag_close_button_pressed)
	_setup_bag_item_details()
	_setup_equipped_item_details()

	_setup_ground_loot()
	_setup_loot_continue_button()
	_setup_restart_button()

	_setup_mana_bar()
	_generate_encounter()
	_layout_ui()
	get_node("BetweenFightsPanel/VictoryLabel").position.y -= 135.0
	get_node("BetweenFightsPanel/XPLabel").position.y -= 135.0
	_refresh_summons()
	get_node("BetweenFightsPanel").visibility_changed.connect(_build_floor_one_room)
	_build_floor_one_room()
	get_viewport().size_changed.connect(_build_floor_one_room)
	get_viewport().size_changed.connect(_position_summon_row)
	get_viewport().size_changed.connect(_position_boss_intro)
	get_viewport().size_changed.connect(_position_campfire_intro)
	_setup_extra_combo_bars()
	_setup_player_status_display()
	$NotebookLayer/EnemyNotebook.hide()
	$BetweenFightsPanel/CampNotebookButton.pressed.connect(_open_enemy_notebook)

func _get_status_color(effect_id: String) -> Color:
	match effect_id:
		"poison":
			return Color("#48B76A")
		"burn", "cursed_flame":
			return Color("#E05252")
		"frostbite", "freeze":
			return Color("#65B8FF")
		"bleed":
			return Color("#BD3548")
		"decay":
			return Color("#8960A8")
		"corrosion":
			return Color("#A8BF49")
		"shock":
			return Color("#F0CD55")
		"weakness":
			return Color("#A889DD")
		"vulnerable":
			return Color("#E889A2")
		"regeneration":
			return Color("#55C5AA")
		"protected":
			return Color("#E5C35B")
		"thwart":
			return Color("#71C9EB")
		_:
			return Color("#B0B0B0")

func _get_status_tooltip(effect: Dictionary) -> String:
	var effect_id = str(effect.get("id", ""))
	var data: Dictionary = status_effect_database.get(effect_id, {})
	var turns = int(effect.get("remaining_turns", 0))
	var effect_name = str(data.get("name", effect_id))
	var duration_text = "Permanent" if turns < 0 else "%d turns remaining" % turns
	var description = ""

	if float(data.get("damage_per_turn", 0.0)) > 0.0:
		description = "%s damage per turn" % _format_damage(
			_get_status_tick_damage(effect_id, data, turns)
		)
	else:
		match effect_id:
			"weakness":
				description = "Deals %.0f%% less damage" % (
					absf(float(data.get("outgoing_damage_modifier", 0.0))) * 100.0
				)
			"vulnerable":
				description = "Takes %.0f%% more damage" % (
					float(data.get("incoming_damage_modifier", 0.0)) * 100.0
				)
			"corrosion":
				description = "Reduces physical resistance by %.0f%%" % (5.0 * maxi(turns, 1))
			"regeneration":
				description = "Restores %s HP per turn" % _format_damage(
					float(data.get("healing_per_turn", 0.0))
				)
			"freeze":
				description = "Cannot perform an attack"
			"shock":
				description = "On you: shorter defense windows. On an enemy: %.0f%% more time to defend against its attacks." % minf(75.0, 15.0 * maxi(turns, 1))
			"protected":
				description = "Negates the next direct hit"
			"thwart":
				description = "+25% physical and magic resistance"
			"sluggish", "flammable_slime":
				description = str(data.get("description", ""))

	if description.is_empty():
		return "%s\n%s" % [effect_name, duration_text]

	return "%s\n\n%s\n%s" % [effect_name, description, duration_text]

func _setup_player_status_display() -> void:
	player_status_container = HFlowContainer.new()
	player_status_container.name = "PlayerStatusContainer"
	player_status_container.position = Vector2(365, 635)
	player_status_container.size = Vector2(550, 76)
	player_status_container.add_theme_constant_override("h_separation", 8)
	player_status_container.add_theme_constant_override("v_separation", 6)
	player_status_container.mouse_filter = Control.MOUSE_FILTER_PASS
	player_status_container.z_index = 10

	add_child(player_status_container)
	_refresh_player_status_display()


func _refresh_player_status_display() -> void:
	if not is_instance_valid(player_status_container):
		return

	for child in player_status_container.get_children():
		player_status_container.remove_child(child)
		child.queue_free()

	for effect in player_active_effects:
		var effect_id = str(effect.get("id", ""))

		if not status_effect_database.has(effect_id):
			continue

		var color = _get_status_color(effect_id)

		var status_box = PanelContainer.new()
		status_box.custom_minimum_size = Vector2(34, 25)
		status_box.mouse_filter = Control.MOUSE_FILTER_STOP
		status_box.tooltip_text = _get_status_tooltip(effect)

		var style = StyleBoxFlat.new()
		style.bg_color = color.darkened(0.65)
		style.border_color = color
		style.set_border_width_all(1)
		style.set_corner_radius_all(4)
		style.content_margin_left = 4
		style.content_margin_right = 4
		style.content_margin_top = 2
		style.content_margin_bottom = 2

		status_box.add_theme_stylebox_override("panel", style)

		var status_label = Label.new()
		var turns_left = int(effect.get("remaining_turns", 0))
		status_label.text = "%s%s" % [
			effect_id.substr(0, 1).to_upper(),
			"∞" if turns_left < 0 else str(turns_left)
		]

		status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		status_label.add_theme_font_size_override("font_size", 13)
		status_label.add_theme_color_override(
			"font_color",
			color.lightened(0.35)
		)
		status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

		status_box.add_child(status_label)
		player_status_container.add_child(status_box)


func _setup_ground_loot() -> void:
	ground_loot_layer = Node2D.new()
	ground_loot_layer.name = "GroundLootLayer"
	ground_loot_layer.z_index = 30
	add_child(ground_loot_layer)

	ground_loot_tooltip = PanelContainer.new()
	ground_loot_tooltip.name = "GroundLootTooltip"
	ground_loot_tooltip.z_index = 100
	ground_loot_tooltip.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var tooltip_label = Label.new()
	tooltip_label.name = "StatsLabel"
	tooltip_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

	ground_loot_tooltip.add_child(tooltip_label)
	add_child(ground_loot_tooltip)
	ground_loot_tooltip.hide()


func _setup_loot_continue_button() -> void:
	loot_continue_button = Button.new()
	loot_continue_button.name = "LootContinueButton"
	loot_continue_button.text = "Continue"
	loot_continue_button.position = Vector2(960, 545)
	loot_continue_button.size = Vector2(160, 58)
	loot_continue_button.z_index = 20
	loot_continue_button.focus_mode = Control.FOCUS_NONE
	loot_continue_button.add_theme_font_size_override("font_size", 22)
	loot_continue_button.pressed.connect(_on_loot_continue_pressed)

	add_child(loot_continue_button)
	loot_continue_button.hide()


func _generate_enemy_loot(enemy_id: String, slot_index: int, guaranteed: bool = false) -> void:
	var enemy = active_enemies[slot_index]
	if enemy != null and enemy.get("boss_spawn", false):
		return
	if not enemy_database.has(enemy_id):
		return

	var enemy_data = enemy_database[enemy_id]
	var loot_table = enemy_data.get("loot_table", [])
	var rolled_items = {}

	for drop in loot_table:
		if drop.get("on_kill_only", false) and (enemy == null or float(enemy["health"]) > 0.0):
			continue

		var item_id = str(drop.get("item_id", ""))

		# Prevent duplicate item types from the same enemy.
		if rolled_items.has(item_id):
			continue

		rolled_items[item_id] = true

		if (not guaranteed or drop.get("on_kill_only", false)) and randf() >= float(drop.get("chance", 0.0)):
			continue

		var item = _create_item_instance(item_id, true)

		if item.is_empty():
			continue

		pending_loot.append(item)
		_spawn_ground_loot(item, slot_index)

		print(
			"LOOT DROPPED: %s | Rarity: %s | Instance ID: %d"
			% [
				item["name"],
				item.get("rarity", "Common"),
				item["instance_id"]
			]
		)


func _setup_restart_button() -> void:
	restart_button = Button.new()
	restart_button.name = "RestartButton"
	restart_button.text = "Restart Run"
	restart_button.position = Vector2(540, 545)
	restart_button.size = Vector2(200, 58)
	restart_button.z_index = 50
	restart_button.focus_mode = Control.FOCUS_NONE

	restart_button.add_theme_font_size_override("font_size", 24)

	restart_button.pressed.connect(_on_restart_button_pressed)

	add_child(restart_button)
	restart_button.hide()


func _on_restart_button_pressed() -> void:
	if combat_state != "game_over":
		return

	Engine.time_scale = 1.0
	get_tree().reload_current_scene()


func _format_item_tooltip(item: Dictionary, show_current_damage: bool = false) -> String:
	var tooltip = "%s\nRarity: %s" % [
		item.get("name", "Unknown Item"),
		item.get("rarity", "Common")
	]

	var item_type = item.get("item_type", "")

	if item_type == "passive":
		return tooltip + "\n\n" + str(item["description"]) + "\nMax stack: %d" % item["max_stack"]

	if item_type == "enchant_material":
		var pool := _get_material_enchantment_pool(item)
		for enchantment_id in _get_material_enchantments(item):
			var enchantment: Dictionary = pool.get(enchantment_id, {})
			tooltip += "\n\nApplies %s\n%s" % [
				enchantment.get("name", enchantment_id),
				enchantment.get("description", "")
			]
		return tooltip

	if item_type == "scroll":
		var spell: Dictionary = spells[item["spell_id"]]
		var description = str(spell["name"])
		var required = int(spell["required_investment"])
		if required > 0:
			description += "\nRequires %d invested %s" % [required, spell["magic_type"]]
		return description

	if item_type == "consumable":
		var healing = int(item.get("heal_amount", 0))

		if healing != 0:
			tooltip += "\nRestores %d HP" % healing
		if item.has("heal_fraction"):
			tooltip += "\nRestores %.0f%% of max HP" % (100.0 * float(item["heal_fraction"]))

		tooltip += "\nQuantity: %d" % item.get("quantity", 1)
		var on_use_effects = item.get("on_use_effects", [])

		for effect in on_use_effects:
			var effect_id = str(effect.get("id", ""))
			var effect_name = str(
				status_effect_database.get(effect_id, {}).get(
					"name", effect_id
				)
			)

			tooltip += "\nApplies %s for %d turns" % [
				effect_name,
				int(effect.get("turns", 1))
			]


	elif item_type == "armor":
		var armor_slot = str(item.get("armor_slot", "unknown"))

		tooltip += "\nSlot: %s" % armor_slot.capitalize()
		var bonus_health = int(item.get("bonus_health", 0))

		if bonus_health > 0:
			tooltip += "\nMax HP: +%d" % bonus_health

		var bonuses = item.get("stat_bonuses", {})

		if not bonuses.is_empty():
			tooltip += "\n\nStat Bonuses:"

			for stat_name in bonuses:
				tooltip += "\n%s: +%d" % [
					stat_name,
					int(bonuses[stat_name])
				]

		var resistances = item.get("resistances", {})

		if not resistances.is_empty():
			tooltip += "\n\nResistances:"

			for resistance_name in resistances:
				tooltip += "\n%s: +%.0f%%" % [
					"Magic" if resistance_name == "Elemental" else resistance_name,
					float(resistances[resistance_name]) * 100.0
				]

		var gear_bonus_labels = {
			"health_regen": "Health Regen",
			"mana_regen_bonus": "Mana Regen",
			"starting_mana_bonus": "Starting Mana",
			"max_mana_bonus": "Max Mana",
			"physical_damage_percent": "Physical Damage"
		}
		for bonus_name in gear_bonus_labels:
			var amount = int(item.get(bonus_name, 0))
			if amount != 0:
				var suffix = "%" if bonus_name == "physical_damage_percent" else ""
				tooltip += "\n%s: +%d%s" % [gear_bonus_labels[bonus_name], amount, suffix]

	elif item_type == "slime_dna":
		tooltip += "\n\n" + str(item["description"])
		tooltip += "\nAllied Slimes gain +%.0f%% max HP and attack damage for this run." % ((SLIME_DNA_SUMMON_MULTIPLIER - 1.0) * 100.0)
	elif item_type == "weapon":
		var requirements: Dictionary = item.get("requirements", {})
		for stat_name in requirements:
			tooltip += "\nRequires %d %s" % [requirements[stat_name], stat_name]
		tooltip += "\n\nWeapon: %s" % item.get("weapon_type", "Unknown")
		tooltip += "\nBase Damage: %.1f" % float(item.get("base_damage", 0.0))

		if show_current_damage:
			tooltip += "\nCurrent Damage: %s" % _format_damage(_get_weapon_damage())

		var penetration = float(item.get("penetration", 0.0))

		if not is_zero_approx(penetration):
			tooltip += "\nPenetration: %+.1f%%" % (penetration * 100.0)

		var crit_chance = float(item.get("crit_chance", 0.0))

		if not is_zero_approx(crit_chance):
			tooltip += "\nCritical Chance: %+.1f%%" % (crit_chance * 100.0)

		var damage_types = item.get("damage_types", [])

		if not damage_types.is_empty():
			tooltip += "\nDamage Type: " + ", ".join(damage_types)

		var school = str(item.get("magic_school", ""))
		if not school.is_empty():
			tooltip += "\nMagic Type: %s" % school

		var pillar: Dictionary = item.get("rock_pillar", {})
		if not pillar.is_empty():
			tooltip += "\nRock Pillar: %.0f%% on hit. %.0f base Earth damage, %.1fx Terraton scaling." % [
				float(pillar["chance"]) * 100.0,
				float(pillar["base_damage"]),
				float(pillar["scaling"])
			]

		var scalings = item.get("scalings", {})
		var scaling_text = ""

		for stat_name in scalings:
			var scaling_value = float(scalings[stat_name])

			if not is_zero_approx(scaling_value):
				scaling_text += "\n%s: %.1fx" % [
					stat_name,
					scaling_value
				]

		if scaling_text != "":
			tooltip += "\n\nStat Scaling:" + scaling_text

		var status_effects = item.get("status_effects", [])

		if not status_effects.is_empty():
			tooltip += "\n\nStatus Effects:"

			for effect in status_effects:
				var effect_id = str(effect.get("id", ""))
				var effect_name = status_effect_database.get(effect_id, {}).get("name", effect_id)
				var chance = float(effect.get("chance", 0.0)) * 100.0
				var turns = int(effect.get("turns", effect.get("stacks", 1)))

				tooltip += "\n- %s: %.0f%% chance, %d turn(s)" % [
					effect_name,
					chance,
					turns
				]
		var special_attacks = item.get("special_attacks", {})

		if not special_attacks.is_empty():
			for attack_id in special_attacks:
				tooltip += "\n\nBuilt in move: %s" % attack_id.capitalize()
				if special_attacks[attack_id].get("guaranteed_rock_pillar", false):
					tooltip += "\nSummons a Rock Pillar if the target survives the hit."

	var enchantments = item.get("enchantments", [])
	if not enchantments.is_empty():
		var pool = ItemData.ARMOR_ENCHANTMENTS if item_type == "armor" else ItemData.WEAPON_ENCHANTMENTS
		tooltip += "\n\nEnchantments:"
		for enchantment_id in enchantments:
			var enchantment: Dictionary = pool.get(enchantment_id, {})
			tooltip += "\n- %s" % enchantment.get("name", str(enchantment_id))
			if enchantment.has("description"):
				tooltip += "\n%s" % enchantment["description"]

	var speed_bonus = float(item.get("attack_speed", 0.0))
	if item_type in ["weapon", "armor"] and not is_zero_approx(speed_bonus):
		tooltip += "\nAgility Modifier: %+.1f%%" % (speed_bonus * 100.0)
	var barrage: Dictionary = set_bonus_database["barrage"]
	var is_fist_weapon = (
		item_type == "weapon"
		and item.get("weapon_type", "") in barrage["required_weapon_types"]
	)
	var is_pauldron = (
		item_type == "armor"
		and item.get("armor_slot", "") == "chest"
		and item.get("armor_type", "") == barrage["required_chest_armor_type"]
	)
	if is_fist_weapon or is_pauldron:
		tooltip += "\n\nSet Bonus\n- Any fist weapon\n- Any chest-slot Pauldron\n%s" % barrage["reward_text"]

	var template_id = item.get("template_id", "")
	for bonus in set_bonus_database.values():
		var required_items: Array = bonus.get("required_items", [])
		if template_id not in required_items:
			continue

		tooltip += "\n\nSet Bonus"
		for required_id in required_items:
			var item_data: Dictionary = weapon_database.get(
				required_id, armor_database.get(required_id, {})
			)
			tooltip += "\n- %s" % item_data.get("name", required_id)

		tooltip += "\n%s" % bonus["reward_text"]

	return tooltip


func _spawn_ground_loot(item: Dictionary, slot_index: int, chest_origin: Vector2 = Vector2.INF, chest_landing: Vector2 = Vector2.ZERO) -> void:
	var from_chest = chest_origin != Vector2.INF
	var death_position = chest_origin if from_chest else _get_enemy_drop_position(slot_index)
	await get_tree().process_frame

	if not pending_loot.has(item):
		return

	var drop_button = Button.new()
	drop_button.name = "Loot_%d" % item["instance_id"]
	drop_button.size = Vector2(48, 48)
	drop_button.custom_minimum_size = Vector2(48, 48)
	drop_button.focus_mode = Control.FOCUS_NONE
	drop_button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	drop_button.expand_icon = true

	var offset = Vector2(
		randf_range(-55.0, 55.0),
		randf_range(15.0, 65.0)
	)

	var landing_center = chest_landing if from_chest else death_position + offset
	drop_button.position = landing_center - drop_button.size / 2.0
	var label_top = ground_loot_layer.to_local(get_node("Label").global_position).y
	drop_button.position.y = minf(drop_button.position.y, label_top - drop_button.size.y - 12.0)

	var icon_path = item.get("icon", "")

	if icon_path != "" and ResourceLoader.exists(icon_path):
		var texture = load(icon_path)

		if texture is Texture2D:
			drop_button.icon = texture
		else:
			drop_button.text = "?"
	else:
		drop_button.text = "P" if item.get("item_type") == "consumable" else "?"

	drop_button.set_meta("loot_tooltip", _format_item_tooltip(item))
	drop_button.set_meta("loot_id", item["instance_id"])

	var normal_style = StyleBoxFlat.new()
	normal_style.bg_color = ENCHANTED_SLOT_COLOR if not item.get("enchantments", []).is_empty() else Color("#181818")
	normal_style.border_color = Color("#777777")
	normal_style.set_border_width_all(1)
	normal_style.set_corner_radius_all(5)

	var hover_style = normal_style.duplicate()
	hover_style.border_color = Color("#E5C35B")
	hover_style.bg_color = ENCHANTED_SLOT_COLOR if not item.get("enchantments", []).is_empty() else Color("#333333")

	drop_button.add_theme_stylebox_override("normal", normal_style)
	drop_button.add_theme_stylebox_override("hover", hover_style)
	drop_button.add_theme_stylebox_override("pressed", hover_style)

	ground_loot_layer.add_child(drop_button)

	if from_chest:
		var landing = drop_button.position
		var launch = chest_origin - drop_button.size / 2.0
		var peak = launch.lerp(landing, 0.5) + Vector2(0, -65)
		drop_button.position = launch
		drop_button.disabled = true

		var flight = drop_button.create_tween()
		flight.tween_property(drop_button, "position", peak, 0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		flight.tween_property(drop_button, "position", landing, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		flight.tween_callback(drop_button.set_disabled.bind(false))

func _set_bag_drag_glow(active: bool) -> void:
	var bag_button = get_node("BagButton") as Button

	if active:
		if not bag_drag_original_styles.is_empty():
			return

		for style_name in ["normal", "hover", "pressed", "focus"]:
			bag_drag_original_styles[style_name] = bag_button.get_theme_stylebox(style_name)

		var glow_style = StyleBoxFlat.new()
		glow_style.bg_color = Color("#183C2B")
		glow_style.border_color = Color("#76CDA0")
		glow_style.set_border_width_all(3)
		glow_style.set_corner_radius_all(7)
		glow_style.shadow_color = Color("#76CDA0", 0.75)
		glow_style.shadow_size = 14

		for style_name in ["normal", "hover", "pressed", "focus"]:
			bag_button.add_theme_stylebox_override(style_name, glow_style)

	else:
		if bag_drag_original_styles.is_empty():
			return

		for style_name in bag_drag_original_styles:
			bag_button.add_theme_stylebox_override(
				style_name,
				bag_drag_original_styles[style_name]
			)

		bag_drag_original_styles.clear()


func _on_ground_loot_pressed(instance_id: int, drop_button: Button) -> void:
	if bag_open or combat_state == "between_fights" or combat_state == "game_over":
		return

	dragged_loot_id = instance_id
	dragged_loot_button = drop_button
	_set_bag_drag_glow(true)
	get_node("BagButton").modulate = Color.WHITE
	_hide_ground_loot_tooltip()

	print("Started dragging loot: ", instance_id)


func _show_ground_loot_tooltip(tooltip: String) -> void:
	if dragged_loot_button != null:
		return

	if not is_instance_valid(ground_loot_tooltip):
		return

	ground_loot_tooltip.get_node("StatsLabel").text = tooltip
	ground_loot_tooltip.reset_size()
	ground_loot_tooltip.show()


func _hide_ground_loot_tooltip() -> void:
	if is_instance_valid(ground_loot_tooltip):
		ground_loot_tooltip.hide()


func _on_ground_loot_hovered(instance_id: int) -> void:
	if bag_open or combat_state == "between_fights" or combat_state == "game_over":
		return

	var item_index = -1

	for i in range(pending_loot.size()):
		if pending_loot[i]["instance_id"] == instance_id:
			item_index = i
			break

	if item_index == -1:
		return

	var item = pending_loot[item_index]

	var collected := _add_passive_item(item) if item.get("item_type") == "passive" else _add_item_to_inventory(item)
	if not collected:
		return

	pending_loot.remove_at(item_index)
	_hide_ground_loot_tooltip()

	var drop_button = ground_loot_layer.get_node_or_null(
		"Loot_%d" % instance_id
	)

	if drop_button != null:
		drop_button.hide()
		drop_button.queue_free()

	print("You collected %s!" % item["name"])

	_add_combat_log(
		"You collected %s!" % item["name"],
		"gold"
	)


func _clear_ground_loot() -> void:
	if is_instance_valid(loot_chest):
		loot_chest.hide()
		loot_chest.queue_free()
		loot_chest = null
	dragged_loot_button = null
	_set_bag_drag_glow(false)
	dragged_loot_id = -1

	if is_instance_valid(ground_loot_tooltip):
		ground_loot_tooltip.hide()

	for child in ground_loot_layer.get_children():
		child.queue_free()

	pending_loot.clear()


func _load_enemy(enemy_id):
	var enemy_data = enemy_database[enemy_id]
	
	enemy_name = enemy_data["name"]
	enemy_health = enemy_data["max_health"]
	enemy_speed = enemy_data["speed"]
	enemy_attacks = enemy_data["attacks"]
	enemy_xp_reward = enemy_data["xp_reward"]
	
	get_node("Label").text = enemy_name + " HP:" + str(enemy_health)


func _get_enemy_wave_multiplier() -> float:
	var scaling_tiers := floori(float(encounter_number - 1) / EnemyData.WAVES_PER_SCALING_TIER)
	return pow(EnemyData.ENEMY_SCALING_PER_TIER, scaling_tiers)


func _create_enemy_instance(enemy_id):
	var enemy_data = enemy_database[enemy_id]
	var wave_multiplier = _get_enemy_wave_multiplier()

	var scaled_attacks = enemy_data["attacks"].duplicate(true)

	for attack in scaled_attacks:
		if attack.has("stages"):
			for stage in attack["stages"]:
				stage["damage"] = float(stage["damage"]) * wave_multiplier
		elif attack.has("repeated_attack"):
			var repeat: Dictionary = attack["repeated_attack"]
			for stage in [repeat["hit"], repeat["finisher"]]:
				stage["damage"] = float(stage["damage"]) * wave_multiplier
		else:
			attack["damage"] = float(attack["damage"]) * wave_multiplier

	var chosen_sprite = enemy_data.get("sprite", "")

	if enemy_data.has("sprites"):
		chosen_sprite = _choose_weighted_sprite(
			enemy_data["sprites"],
			enemy_data["sprite_weights"]
		)

	return {
		"id": enemy_id,
		"name": enemy_data["name"],
		"speed": enemy_data["speed"],
		"health": roundi(enemy_data["max_health"] * wave_multiplier),
		"max_health": roundi(enemy_data["max_health"] * wave_multiplier),
		"attacks": scaled_attacks,
		"xp_reward": enemy_data["xp_reward"],
		"gold_min": enemy_data["gold_min"],
		"gold_max": enemy_data["gold_max"],
		"resistances": enemy_data.get("resistances", {}).duplicate(true),
		"active_effects": [],
		"sprite": chosen_sprite,
	}


func _apply_status_effect(target: Dictionary, effect_id: String, stack_amount: int = 1, turns_amount: int = -1) -> void:
	if float(target.get("health", 1.0)) > 0.0:
		_apply_status_to_target(target, effect_id, stack_amount, turns_amount)

	if not _has_weapon_enchantment("unwilling"):
		return

	if target.get("name", "") != "You" and player_health > 0:
		var applied_turns = _get_applied_status_duration(effect_id, stack_amount, turns_amount)
		var reflected_turns = floori(applied_turns / 2.0)
		var effect_data: Dictionary = status_effect_database.get(effect_id, {})
		if reflected_turns > 0 and not effect_data.get("permanent", false):
			_apply_player_status_effect(effect_id, stack_amount, reflected_turns, false)

	for enemy in active_enemies:
		if enemy != null and enemy["health"] > 0.0 and not is_same(enemy, target):
			_apply_status_to_target(enemy, effect_id, stack_amount, turns_amount)

func _get_applied_status_duration(effect_id: String, legacy_amount: int, turns_amount: int) -> int:
	var data: Dictionary = status_effect_database.get(effect_id, {})
	var duration = turns_amount

	if duration < 0:
		duration = legacy_amount if float(data.get("damage_per_turn", 0.0)) > 0.0 else int(data.get("duration", legacy_amount))

	return clampi(duration, 1, maxi(1, int(data.get("max_turns", 100))))

func _apply_status_to_target(target: Dictionary, effect_id: String, legacy_amount: int, turns_amount: int) -> void:
	if legacy_amount <= 0:
		return
	if not status_effect_database.has(effect_id):
		push_warning("Unknown status effect: " + effect_id)
		return

	var data: Dictionary = status_effect_database[effect_id]
	var max_turns = maxi(1, int(data.get("max_turns", 100)))
	var turns_left = _get_applied_status_duration(effect_id, legacy_amount, turns_amount)
	var effects: Array = target.get("active_effects", [])
	target["active_effects"] = effects

	var active: Dictionary = {}
	for effect in effects:
		if effect["id"] == effect_id:
			active = effect
			break

	if active.is_empty():
		active = {"id": effect_id}
		effects.append(active)
	elif effect_id in ["freeze", "protected", "thwart"]:
		turns_left = maxi(turns_left, int(active["remaining_turns"]))
	else:
		turns_left = mini(max_turns, turns_left + int(active["remaining_turns"]))

	if bool(data.get("permanent", false)):
		turns_left = -1

	active["remaining_turns"] = turns_left
	active.erase("stacks")

	var duration_text = "permanent" if turns_left < 0 else "%d turns remaining" % turns_left
	_add_combat_log(
		"%s: %s (%s)." % [target["name"], data["name"], duration_text],
		"status_damage"
	)
	if target["name"] == "You":
		_refresh_player_status_display()
	else:
		_refresh_enemy_slots()


func _get_status_turns(effects: Array, effect_id: String) -> int:
	for effect in effects:
		if effect.get("id", "") == effect_id:
			return maxi(1, int(effect.get("remaining_turns", 1)))

	return 0


func _get_status_tick_damage(effect_id: String, data: Dictionary, turns: int) -> float:
	var damage = float(data.get("damage_per_turn", 0.0))
	if damage <= 0.0:
		return 0.0
	if effect_id == "poison" and turns > 0:
		damage = float(turns)
	if bool(data.get("milestone_bonus", true)):
		damage *= 1.0 + 0.5 * floori(maxi(turns, 0) / 5.0)
	return damage

func _consume_protection() -> bool:
	for effect in player_active_effects:
		if effect.get("id", "") == "protected":
			player_active_effects.erase(effect)
			_refresh_player_status_display()

			_add_combat_log(
				"Protect absorbed the incoming damage!",
				"success"
			)

			return true

	return false

func _apply_player_status_effect(effect_id: String, stack_amount: int = 1, turns_amount: int = -1, spread: bool = true) -> void:
	var player_target = {
		"name": "You",
		"active_effects": player_active_effects
	}

	if spread:
		_apply_status_effect(player_target, effect_id, stack_amount, turns_amount)
	else:
		_apply_status_to_target(player_target, effect_id, stack_amount, turns_amount)



func _apply_weapon_hit_effects(
	target: Dictionary,
	attack_name: String
) -> void:
	var special_attacks = equipped_weapon.get("special_attacks", {})

	if special_attacks.has(attack_name):
		var special_attack = special_attacks[attack_name]

		if float(target.get("health", 0.0)) > 0.0 or _has_weapon_enchantment("unwilling"):
			for effect in special_attack.get("guaranteed_effects", []):
				var effect_id = str(effect.get("id", ""))
				var stacks = maxi(1, int(effect.get("stacks", 1)))
				var turns = int(effect.get("turns", -1))

				_apply_status_effect(
					target,
					effect_id,
					stacks,
					turns
				)

			for effect in special_attack.get("chance_effects", []):
				var chance = clampf(
					float(effect.get("chance", 0.0)),
					0.0,
					1.0
				)

				if randf() < chance:
					var effect_id = str(effect.get("id", ""))
					var stacks = maxi(1, int(effect.get("stacks", 1)))
					var turns = int(effect.get("turns", -1))

					_apply_status_effect(
						target,
						effect_id,
						stacks,
						turns
					)

					if float(target["health"]) <= 0.0:
						continue

					_add_combat_log(
						"%s was affected by %s!" % [
							target["name"],
							str(
								status_effect_database.get(
									effect_id, {}
								).get("name", effect_id)
							)
						],
						"success"
					)

	for effect in equipped_weapon.get("status_effects", []):
		var effect_id = str(effect.get("id", ""))
		if attack_name == "slime splurge" and effect_id == "sluggish":
			continue
		var chance = clampf(
			float(effect.get("chance", 0.0)),
			0.0,
			1.0
		)
		var stacks = maxi(1, int(effect.get("stacks", 1)))
		var turns = int(effect.get("turns", -1))

		if float(target.get("health", 0.0)) > 0.0 or _has_weapon_enchantment("unwilling"):
			if randf() < chance:
				_apply_status_effect(
					target,
					effect_id,
					stacks,
					turns
				)


func _tick_actor_status_effects(
	effects: Array,
	target_name: String,
	enemy_slot: int = -1
) -> void:
	var flammable := _get_status_turns(effects, "flammable_slime") > 0
	for effect in effects.duplicate():
		var effect_id = str(effect.get("id", ""))

		if not status_effect_database.has(effect_id):
			effects.erase(effect)
			continue

		var data = status_effect_database[effect_id]
		var turns = int(effect.get("remaining_turns", 0))
		var damage = _get_status_tick_damage(effect_id, data, turns)
		if (effect_id in ["burn", "cursed_flame"] or data.get("damage_type") == "Fire") and flammable:
			damage *= SlimeContent.FLAMMABLE_SLIME_DAMAGE_MULTIPLIER
		var healing = float(data.get("healing_per_turn", 0.0))

		if enemy_slot >= 0:
			var enemy = active_enemies[enemy_slot]

			if enemy == null:
				return

			if damage > 0.0:
				var damage_type = str(data.get("damage_type", ""))
				var resistances = enemy.get("resistances", {})
				var resistance = float(resistances.get(damage_type, 0.0))

				if damage_type != "Physical":
					resistance += float(resistances.get("Elemental", 0.0))

				damage = _apply_resistance(
					damage,
					clampf(resistance, 0.0, 1.0),
					0.0
				)
				damage = _apply_weapon_damage_enchantments(damage, float(enemy["health"]))
				damage = floorf(damage * 1000.0) / 1000.0
				damage = minf(damage, float(enemy["health"]))

				enemy["health"] = maxf(
					0.0,
					float(enemy["health"]) - damage
				)

				if damage > 0.0:
					_add_combat_log(
						"%s took %s %s damage!" % [
							target_name,
							_format_damage(damage),
							data["name"]
						],
						"status_damage"
					)

			if healing > 0.0 and enemy["health"] > 0:
				var restored = minf(
					healing,
					float(enemy["max_health"]) - float(enemy["health"])
				)

				enemy["health"] += restored

				if restored > 0.0:
					_add_combat_log(
						"%s regenerated %s HP!" % [
							target_name,
							_format_damage(restored)
						],
						"success"
					)

			if enemy["health"] <= 0:
				_add_combat_log(
					"%s was defeated by %s!" % [
						target_name,
						data["name"]
					],
					"status_damage"
				)

				_defeat_enemy(enemy_slot)
				return

		else:
			if damage > 0.0:
				var resistance = _thwart_resistance()
				var actual_damage = mini(roundi(damage * (1.0 - resistance) * _healthy_damage_multiplier()), player_health)
				var previous_hp = player_health
				player_health -= actual_damage
				_on_player_damaged(previous_hp)

				if actual_damage > 0:
					wave_flawless = false

					_add_combat_log(
						"You took %d %s damage!" % [
							actual_damage,
							data["name"]
						],
						"status_damage"
					)

			if healing > 0.0 and player_health > 0:
				var restored = mini(
					roundi(healing),
					player_max_health - player_health
				)

				player_health += restored

				if restored > 0:
					_add_combat_log(
						"You regenerated %d HP!" % restored,
						"success"
					)

			get_node("PlayerHP").text = "HP: %d/%d" % [
				player_health,
				player_max_health
			]

			if player_health <= 0:
				_add_combat_log(
					"You were defeated by %s!" % data["name"],
					"failure"
				)
				return

		if not bool(data.get("permanent", false)):
			effect["remaining_turns"] = int(
				effect["remaining_turns"]
			) - 1


			if effect["remaining_turns"] <= 0:
				effects.erase(effect)

				_add_combat_log(
					"%s wore off of %s." % [
						data["name"],
						target_name
					],
					"normal"
				)


func _tick_all_status_effects() -> void:
	for slot_index in range(MAX_ENEMY_SLOTS):
		var enemy = active_enemies[slot_index]

		if enemy == null:
			continue

		_tick_actor_status_effects(
			enemy["active_effects"],
			enemy["name"],
			slot_index
		)

	_tick_actor_status_effects(
		player_active_effects,
		"You"
	)

	if not pending_reinforcements.is_empty():
		_deploy_reinforcements()

	_refresh_enemy_slots()
	_update_target_label()
	_refresh_player_status_display()

func _choose_weighted_sprite(sprites, weights):
	var total_weight = 0
	
	for weight in weights:
		total_weight += weight
	
	var roll = randi_range(1, total_weight)
	
	for i in range(sprites.size()):
		roll -= weights[i]
		
		if roll <= 0:
			return sprites[i]
	
	return sprites.back()

func _spawn_enemy(enemy_id, slot_index):
	if slot_index < 0 or slot_index >= MAX_ENEMY_SLOTS:
		return false
		
	if active_enemies[slot_index] != null:
		return false
	
	if not enemy_database.has(enemy_id):
		return false
	
	active_enemies[slot_index] = _create_enemy_instance(enemy_id)
	var discoveries: Dictionary = notebook_discoveries.get(current_dungeon_floor, {})
	var enemy_key := str(enemy_id)
	if not discoveries.has(enemy_key):
		discoveries[enemy_key] = str(active_enemies[slot_index].get("sprite", ""))
		notebook_discoveries[current_dungeon_floor] = discoveries
	
	print(
		"Spawned %s in slot %d" %
		[active_enemies[slot_index]["name"], slot_index + 1]
	)
	
	return true


func _spawn_enemy_in_next_slot(enemy_id):
	var order := [1, 3, 0, 4] if boss_encounter else ENEMY_SPAWN_ORDER
	for slot_index in order:
		if active_enemies[slot_index] == null:
			return _spawn_enemy(enemy_id, slot_index)
	
	return false


func _get_leftmost_enemy_slot():
	for i in range(MAX_ENEMY_SLOTS):
		if active_enemies[i] != null:
			return i
	
	return -1


func _get_living_enemy_slots():
	var living_slots = []

	for i in range(MAX_ENEMY_SLOTS):
		if active_enemies[i] != null and active_enemies[i]["health"] > 0:
			living_slots.append(i)

	return living_slots


func _select_enemy_by_number(enemy_number):
	var living_slots = _get_living_enemy_slots()
	var index = enemy_number - 1

	if index < 0 or index >= living_slots.size():
		return

	_select_enemy(living_slots[index])


func _select_enemy(slot_index):
	if slot_index < 0 or slot_index >= MAX_ENEMY_SLOTS:
		return
	
	if active_enemies[slot_index] == null:
		return
	
	selected_enemy_slot = slot_index
	_update_target_label()
	_refresh_enemy_slots()


func _select_default_enemy():
	selected_enemy_slot = _get_leftmost_enemy_slot()
	_update_target_label()
	_refresh_enemy_slots()

func _add_enemy_status_boxes(slot: Control, enemy: Dictionary) -> void:
	if enemy == null:
		return

	var effects = enemy.get("active_effects", [])

	if effects.is_empty():
		return

	var status_row = HBoxContainer.new()
	status_row.name = "EnemyStatusRow"
	status_row.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	status_row.offset_top = 4
	status_row.offset_bottom = 30
	status_row.offset_left = 0
	status_row.offset_right = 0
	status_row.alignment = BoxContainer.ALIGNMENT_CENTER
	status_row.add_theme_constant_override("separation", 5)
	status_row.mouse_filter = Control.MOUSE_FILTER_PASS
	status_row.z_index = 10

	slot.add_child(status_row)

	for effect in effects:
		var effect_id = str(effect.get("id", ""))

		if not status_effect_database.has(effect_id):
			continue

		var color = _get_status_color(effect_id)

		var status_box = PanelContainer.new()
		status_box.custom_minimum_size = Vector2(34, 25)
		status_box.mouse_filter = Control.MOUSE_FILTER_STOP
		status_box.tooltip_text = _get_status_tooltip(effect)

		var style = StyleBoxFlat.new()
		style.bg_color = color.darkened(0.65)
		style.border_color = color
		style.set_border_width_all(1)
		style.set_corner_radius_all(4)
		style.content_margin_left = 4
		style.content_margin_right = 4
		style.content_margin_top = 2
		style.content_margin_bottom = 2

		status_box.add_theme_stylebox_override("panel", style)

		var status_label = Label.new()
		var turns_left = int(effect.get("remaining_turns", 0))
		status_label.text = "%s%s" % [
			effect_id.substr(0, 1).to_upper(),
			"∞" if turns_left < 0 else str(turns_left)
		]

		status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		status_label.add_theme_font_size_override("font_size", 13)
		status_label.add_theme_color_override("font_color", color.lightened(0.35))
		status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

		status_box.add_child(status_label)
		status_row.add_child(status_box)

func _refresh_enemy_slots():
	var container = get_node("EnemySlotsContainer")
	if boss_encounter:
		container.position.x = 210.0
		container.size.x = 1230.0
	else:
		container.position.x = 280.0
		container.size.x = 1020.0

	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()
	
	for i in range(MAX_ENEMY_SLOTS if boss_encounter else ENEMY_SPAWN_ORDER.size()):
		var slot = enemy_slot_scene.instantiate()
		container.add_child(slot)
		
		var highlighted_slot = selected_enemy_slot

		if current_attacker_slot != -1:
			highlighted_slot = current_attacker_slot

		slot.setup(
			i,
			active_enemies[i],
			i == highlighted_slot
		)

		slot.clip_contents = false

		if active_enemies[i] != null:
			var enemy: Dictionary = active_enemies[i]
			var visual := slot.find_child("EnemySprite", true, false) as CanvasItem
			if visual is TextureButton:
				_add_texture_button_enemy_shadow(visual as TextureButton, str(enemy["id"]))
			elif visual != null:
				_add_combat_shadow(visual, str(enemy["id"]))
			_add_enemy_status_boxes(slot, enemy)

		slot.enemy_clicked.connect(_on_enemy_slot_clicked)

func _add_texture_button_enemy_shadow(button: TextureButton, enemy_id: String) -> void:
	var art := button.texture_normal
	if art == null:
		push_warning("EnemySprite has no normal texture for " + enemy_id)
		return

	var shadow_texture := load("res://Assets/general sprites/shadowenemy.png") as Texture2D
	if shadow_texture == null:
		push_warning("Could not load shadowenemy.png")
		return

	var is_skeleton := enemy_id.to_lower().contains("skeleton")
	var artwork_bounds := Rect2(0.0, 0.0, 1.0, 1.0)
	var image := art.get_image()
	if image != null and not image.is_empty():
		var used := image.get_used_rect()
		if used.has_area():
			if is_skeleton:
				# Measure the lowest 14% of the artwork around the feet.
				var foot_rows := maxi(1, ceili(used.size.y * 0.14))
				var foot_y := used.position.y if button.flip_v else used.end.y - foot_rows
				var foot_area := Rect2i(used.position.x, foot_y, used.size.x, foot_rows)
				var feet := image.get_region(foot_area).get_used_rect()
				if feet.has_area():
					used = Rect2i(foot_area.position + feet.position, feet.size)

			var image_size := Vector2(image.get_size())
			artwork_bounds = Rect2(
				Vector2(used.position) / image_size,
				Vector2(used.size) / image_size
			)

	if button.flip_h:
		artwork_bounds.position.x = 1.0 - artwork_bounds.end.x
	if button.flip_v:
		artwork_bounds.position.y = 1.0 - artwork_bounds.end.y

	var is_bat := enemy_id.to_lower().contains("bat")
	var shadow := Sprite2D.new()
	shadow.name = "CombatShadow"
	shadow.texture = shadow_texture
	shadow.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	shadow.z_as_relative = false
	shadow.z_index = 1
	shadow.self_modulate.a = 0.30 if is_bat else 0.42
	if is_skeleton:
		shadow.self_modulate.a = 0.34

	button.clip_contents = false
	button.z_as_relative = false
	button.z_index = 2
	button.add_child(shadow)

	var update_shadow := func() -> void:
		var art_size := art.get_size()
		var draw_size := art_size
		var draw_offset := Vector2.ZERO
		var fit := button.size / art_size

		match button.stretch_mode:
			TextureButton.STRETCH_SCALE, TextureButton.STRETCH_TILE:
				draw_size = button.size
			TextureButton.STRETCH_KEEP_CENTERED:
				draw_offset = (button.size - draw_size) * 0.5
			TextureButton.STRETCH_KEEP_ASPECT:
				draw_size *= minf(fit.x, fit.y)
			TextureButton.STRETCH_KEEP_ASPECT_CENTERED:
				draw_size *= minf(fit.x, fit.y)
				draw_offset = (button.size - draw_size) * 0.5
			TextureButton.STRETCH_KEEP_ASPECT_COVERED:
				draw_size *= maxf(fit.x, fit.y)
				draw_offset = (button.size - draw_size) * 0.5

		var visible_art := Rect2(
			draw_offset + artwork_bounds.position * draw_size,
			artwork_bounds.size * draw_size
		)
		if button.stretch_mode == TextureButton.STRETCH_KEEP_ASPECT_COVERED:
			visible_art = visible_art.intersection(Rect2(Vector2.ZERO, button.size))

		var width := maxf(14.0, visible_art.size.x * (0.45 if is_bat else 0.75))
		var height := width * 0.25
		var drop := 58.0 if is_bat else 3.0

		if is_skeleton:
			width = maxf(14.0, visible_art.size.x * 0.90)
			height = width * 0.17
			drop = 0.0
		elif enemy_id in ["slime", "lesser_slime"]:
			drop = -1.0
		elif enemy_id == SlimeContent.BOSS_ID:
			width = maxf(14.0, visible_art.size.x * 0.60)
			height = width * 0.15
			drop = -3.0
			shadow.self_modulate.a = 0.34

		if enemy_database.get(enemy_id, {}).get("is_boss", false):
			button.pivot_offset = Vector2(visible_art.get_center().x, visible_art.end.y)
			button.scale = Vector2.ONE * 1.4

		shadow.scale = Vector2(width, height) / shadow_texture.get_size()
		shadow.position = Vector2(
			visible_art.get_center().x,
			visible_art.end.y + drop
		).round()

	button.resized.connect(update_shadow)
	update_shadow.call()


func _on_enemy_slot_clicked(slot_index):
	if combat_state != "planning_phase" and combat_state != "attack_preparing":
		return
	
	_select_enemy(slot_index)


func _update_target_label():
	var display_slot = selected_enemy_slot

	if current_attacker_slot != -1:
		display_slot = current_attacker_slot

	if display_slot < 0 or display_slot >= MAX_ENEMY_SLOTS:
		get_node("Label").text = "No enemies remaining"
		return

	var target = active_enemies[display_slot]

	if target != null:
		get_node("Label").text = "%s HP: %s" % [
			target["name"],
			_format_damage(target["health"])
		]


func _living_enemy_count():
	var count = 0
	
	for enemy in active_enemies:
		if enemy != null and enemy["health"] > 0:
			count += 1
	
	return count



func _deploy_reinforcements():
	while not pending_reinforcements.is_empty():
		var next_enemy = pending_reinforcements.pop_front()
		if next_enemy is Dictionary:
			for slot_index in [1, 3, 0, 4]:
				if _spawn_enemy(next_enemy["id"], slot_index):
					active_enemies[slot_index]["boss_spawn"] = true
					break
			continue

		if not _spawn_enemy_in_next_slot(next_enemy):
			break

	pending_reinforcements.clear()

	if selected_enemy_slot >= 0 and active_enemies[selected_enemy_slot] != null:
		_select_enemy(selected_enemy_slot)
	else:
		_select_default_enemy()


func _get_enemy_drop_position(slot_index: int) -> Vector2:
	var container = get_node("EnemySlotsContainer")
	
	if slot_index < 0 or slot_index >= container.get_child_count():
		return Vector2(640, 250)
	
	var slot = container.get_child(slot_index)
	
	# Look for the actual enemy sprite.
	var sprite = slot.find_child("EnemySprite", true, false)
	
	if sprite is Control:
		var global_center = sprite.get_global_rect().get_center()
		return ground_loot_layer.to_local(global_center)
	
	if sprite is Node2D:
		return ground_loot_layer.to_local(sprite.global_position)
	
	# Fallback to the center of the slot.
	if slot is Control:
		return ground_loot_layer.to_local(
			slot.get_global_rect().get_center()
		)
	
	return Vector2(640, 250)


func _get_player_crit_chance() -> float:
	var chance = base_crit_chance

	chance += float(equipped_weapon.get("crit_chance", 0.0))

	# Future hidden Luck bonus goes here.

	return clampf(chance, 0.0, 1.0)


func _roll_player_critical_hit() -> bool:
	return randf() < _get_player_crit_chance()


func _defeat_enemy(slot_index: int, guaranteed: bool = false) -> void:
	var target = active_enemies[slot_index]

	if target == null:
		return

	if target.get("boss_spawn", false):
		active_enemies[slot_index] = null
		if target["id"] == "slime":
			for i in range(4):
				pending_reinforcements.append({"id": "lesser_slime"})
		return

	target["health"] = 0.0
	if target["id"] == SlimeContent.BOSS_ID:
		boss_chest_pending = true

	_gain_xp(target["xp_reward"])

	var gold_reward = randi_range(
		target["gold_min"],
		target["gold_max"]
	)

	_gain_gold(gold_reward)
	_generate_enemy_loot(target["id"], slot_index, guaranteed)

	var split_slime = target["id"] == "slime"
	active_enemies[slot_index] = null

	if split_slime:
		for i in range(4):
			pending_reinforcements.append("lesser_slime")

		_add_combat_log(
			"The Slime splits into four Lesser Slimes!",
			"warning"
		)

func _roll_rock_pillar_damage(attack_name: String) -> float:
	var raw_damage = 0.0
	var pillar: Dictionary = equipped_weapon.get("rock_pillar", {})

	if not pillar.is_empty():
		var moves: Dictionary = equipped_weapon.get("special_attacks", {})
		var move: Dictionary = moves.get(attack_name, {})
		if move.get("guaranteed_rock_pillar", false) or randf() < float(pillar["chance"]):
			raw_damage += _get_scaled_spell_damage(
				float(pillar["base_damage"]), "Terraton", float(pillar["scaling"])
			)

	if earth_pillars_turns > 0 and randf() < 0.25:
		raw_damage += _get_scaled_spell_damage(15.0, "Terraton", 3.5)

	return raw_damage

func _damage_selected_enemy(
	damage,
	deploy_after_hit = true,
	damage_type_override: String = "",
	target_slot: int = -1,
	attack_name: String = "",
	ignore_resistance: bool = false,
	trigger_attack_enchantments: bool = true,
	allow_summon_follow_up: bool = true
) -> bool:
	var slot_index = selected_enemy_slot

	if target_slot >= 0:
		slot_index = target_slot

	if slot_index < 0 or slot_index >= MAX_ENEMY_SLOTS or active_enemies[slot_index] == null:
		if target_slot >= 0:
			return false

		slot_index = _get_leftmost_enemy_slot()

		if slot_index < 0:
			return false

		selected_enemy_slot = slot_index
		_update_target_label()

	var target = active_enemies[slot_index]


	if attack_name == "":
		attack_name = chosen_attack
	var is_critical = _roll_player_critical_hit()

	if is_critical:
		damage *= base_crit_multiplier

	damage = _calculate_damage_against_enemy(
		target,
		damage,
		damage_type_override,
		ignore_resistance
	)

	if damage > 0.0:
		damage *= _attack_enchantment_multiplier() * _holy_damage_multiplier()

	damage = _apply_weapon_damage_enchantments(damage, float(target["health"]))
	var health_units = maxi(0, roundi(target["health"] * 1000.0))
	var total_damage_units = maxi(0, floori(damage * 1000.0))

	var damage_dealt = mini(total_damage_units, health_units)
	var pillar_raw_damage := _roll_rock_pillar_damage(attack_name) if damage_dealt > 0 else 0.0
	var pillar_units := 0
	if pillar_raw_damage > 0.0 and damage_dealt < health_units:
		var resisted_damage := _apply_spell_resistance(target, pillar_raw_damage, "Terraton")
		pillar_units = maxi(0, floori(resisted_damage * _holy_damage_multiplier() * 1000.0))

	var pillar_damage_dealt = mini(pillar_units, health_units - damage_dealt)
	var overkill_units = maxi(0, total_damage_units + pillar_units - health_units)
	var remaining_units = health_units - damage_dealt - pillar_damage_dealt

	target["health"] = remaining_units / 1000.0

	if damage_dealt > 0:
		_apply_weapon_hit_effects(target, attack_name)
		if _has_weapon_enchantment("flare"):
			_apply_status_effect(target, "burn", 1, 1)
		if trigger_attack_enchantments:
			_trigger_attack_enchantments(target)

	if is_critical:
		_add_combat_log(
			"CRITICAL HIT! You attacked %s for %s damage!" %
			[target["name"], _format_damage(damage_dealt / 1000.0)],
			"critical"
		)
	else:
		_add_combat_log(
			"You attacked %s for %s damage!" %
			[target["name"], _format_damage(damage_dealt / 1000.0)],
			"damage"
		)

	if pillar_damage_dealt > 0:
		_add_combat_log(
			"A Rock Pillar struck %s for %s Earth damage!" %
			[target["name"], _format_damage(pillar_damage_dealt / 1000.0)],
			"damage"
		)

	if overkill_units > 0:
		var excess_damage = overkill_units / 1000.0
		var bonus_gold = ceili(excess_damage / 4.0)

		_add_combat_log(
			"OVERKILL! +%s excess damage!" % _format_damage(excess_damage),
			"overkill"
		)

		_gain_overkill_gold(bonus_gold)

	if remaining_units == 0:
		_defeat_enemy(slot_index)

	if pillar_raw_damage > 0.0 and damage_dealt == health_units:
		var living_slots: Array = _get_living_enemy_slots()
		if not living_slots.is_empty():
			var pillar_slot: int = living_slots.pick_random()
			var resisted_damage := _apply_spell_resistance(active_enemies[pillar_slot], pillar_raw_damage, "Terraton")
			_hit_with_spell(pillar_slot, resisted_damage * _holy_damage_multiplier(), "Rock Pillar", false)

	if damage_dealt > 0 and allow_summon_follow_up:
		_allied_slimes_follow_up(slot_index, target)
	if deploy_after_hit:
		_deploy_reinforcements()
	else:
		_refresh_enemy_slots()
	return true


func _perform_wide_slash():
	if _living_enemy_count() == 0:
		return

	var damage = _calculate_player_attack_damage(0.7)
	var selected_target = selected_enemy_slot
	var hit_target: Dictionary = {}
	
	_add_combat_log("You used Wide Slash!", "damage")
	
	for slot_index in range(MAX_ENEMY_SLOTS):
		var enemy = active_enemies[slot_index]
	
		if enemy == null or enemy["health"] <= 0:
			continue
	
		var sluggish := _sluggish_speed_factor(enemy.get("active_effects", []))
		var enemy_time_limit = _calculate_action_time(3.0, float(enemy["speed"]) * sluggish) / sluggish
	
		if attack_elapsed_time <= enemy_time_limit:
			var final_damage = damage
	
			if slot_index == selected_target:
				final_damage += _calculate_player_attack_damage(0.5)
	
			selected_enemy_slot = slot_index
			var previous_health = float(enemy["health"])
			_damage_selected_enemy(final_damage, false, "", slot_index, "", false, false)
			if float(enemy["health"]) < previous_health:
				if hit_target.is_empty() or float(hit_target["health"]) <= 0.0:
					hit_target = enemy
		else:
			_add_combat_log(
				"You were too slow! %s dodged your attack!" % enemy["name"],
				"failure"
			)
	if not hit_target.is_empty():
		_trigger_attack_enchantments(hit_target)
	if selected_target >= 0 and active_enemies[selected_target] != null:
		selected_enemy_slot = selected_target

	_deploy_reinforcements()


func _get_enemy_turn_order():
	var speed_groups = {}

	for i in range(MAX_ENEMY_SLOTS):
		var enemy = active_enemies[i]
	
		if enemy == null or enemy["health"] <= 0:
			continue
	
		var frostbite_stacks = _get_status_turns(
			enemy.get("active_effects", []),
			"frostbite"
		)

		var frostbite_penalty = float(
			status_effect_database["frostbite"]["speed_modifier"]
		) * frostbite_stacks

		var speed = maxf(0.0, float(enemy["speed"]) + frostbite_penalty) * _sluggish_speed_factor(enemy.get("active_effects", []))

		if not speed_groups.has(speed):
			speed_groups[speed] = []
	
		speed_groups[speed].append(i)
	
	var speeds = speed_groups.keys()
	speeds.sort()
	speeds.reverse()
	
	var order = []
	
	for speed in speeds:
		var group = speed_groups[speed]
		group.shuffle()
		order.append_array(group)
	
	return order


func _begin_enemy_phase(vulnerability):
	pending_vulnerability = vulnerability
	enemy_turn_queue = _get_enemy_turn_order()
	_start_next_enemy_turn()


func _start_next_enemy_turn():
	while not enemy_turn_queue.is_empty():
		var slot_index = enemy_turn_queue.pop_front()
	
		if active_enemies[slot_index] == null:
			continue

		var enemy = active_enemies[slot_index]
		var is_frozen = false

		for effect in enemy.get("active_effects", []):
			if effect.get("id", "") == "freeze":
				is_frozen = true
				break

		if is_frozen:
			_add_combat_log(
				"%s is frozen and cannot attack!" % enemy["name"],
				"success"
			)
			continue

		current_attacker_slot = slot_index
		_refresh_enemy_slots()
		_update_target_label()
	
		var attacker = active_enemies[slot_index]
	
		enemy_name = attacker["name"]
		enemy_speed = maxf(
			0.0,
			float(attacker["speed"]) +
			_get_status_turns(attacker.get("active_effects", []), "frostbite") *
			float(status_effect_database["frostbite"]["speed_modifier"])
		)
		slime_defense_time_multiplier = 1.0 / _sluggish_speed_factor(attacker.get("active_effects", []))
		enemy_attacks = attacker["attacks"]
	
		combat_state = "enemy_preparing"
	
		get_node("AttackLabel").text = \
			"%s is taking its turn..." % enemy_name
	
		get_node("EnemyDelayTimer").start()
		return
	
	current_attacker_slot = -1

	taunt_active = false
	_tick_all_status_effects()

	if player_health <= 0:
		combat_state = "game_over"
		get_node("AttackLabel").text = "You were defeated!"
		get_node("LineEdit").hide()
		get_node("LineEdit").editable = false

		for button_name in [
			"AttackButton",
			"BagButton",
			"BookButton",
			"RunButton"
		]:
			get_node(button_name).hide()

		restart_button.show()
		return

	if _living_enemy_count() == 0 and pending_reinforcements.is_empty():
		_enter_loot_collection()
		return

	combat_state = "planning_phase"
	_roll_speed_demon()
	earth_pillars_turns = maxi(0, earth_pillars_turns - 1)
	holy_sacrifice_turns = maxi(0, holy_sacrifice_turns - 1)
	player_absorb_turns = maxi(0, player_absorb_turns - 1)
	boss_absorb_turns = maxi(0, boss_absorb_turns - 1)
	var intelligence = int(_get_total_stat("Intelligence"))
	var mana_regen = 1

	if intelligence >= 25:
		mana_regen += 1
	if intelligence >= 75:
		mana_regen += 1
	_set_mana(player_mana + mana_regen + _get_gear_bonus("mana_regen_bonus"))
	selected_planning_option = 0
	
	if guard_exhausted:
		_restore_shattered_guard()
	else:
		_recover_guard()
	
	for button in [
		"AttackButton",
		"BagButton",
		"BookButton",
		"RunButton"
	]:
		get_node(button).show()
	
	_update_planning_selection()



func _load_random_enemy():
	var possible_enemies = ["skeleton", "slime"]
	var chosen_enemy = possible_enemies.pick_random()
	
	_load_enemy(chosen_enemy)


func _roll_enemy_count():
	var roll = randi_range(1, 100)
	
	if roll <= 35:
		return 1
	elif roll <= 65:
		return 2
	elif roll <= 85:
		return 3
	else:
		return 4

const SHOP_SELL_RANGES = {
	"Common": Vector2i(15, 40),
	"Uncommon": Vector2i(25, 60),
	"Rare": Vector2i(50, 75),
	"Epic": Vector2i(65, 95),
	"Legendary": Vector2i(100, 150),
	"Mythic": Vector2i(150, 250),
	"Exotic": Vector2i(250, 500),
}

var shop_gold_label: Label

var shop_backdrop: ColorRect
var shops_visited: int = 0
var last_counted_shop_wave: int = -1


func _register_shop_visit() -> void:
	if last_counted_shop_wave == encounter_number:
		return

	last_counted_shop_wave = encounter_number
	shops_visited += 1


func _roll_shop_base_price(item: Dictionary) -> int:
	if item.get("item_type") == "scroll":
		return randi_range(300, 550)

	return randi_range(150, 300)


func _get_shop_buy_price(base_price: int) -> int:
	return roundi(base_price * pow(1.25, maxi(0, shops_visited - 1)))

func _get_shop_sell_price(item: Dictionary) -> int:
	if item.get("item_type") == "enchant_material":
		return 100
	if not item.has("shop_sell_price"):
		var bounds: Vector2i = SHOP_SELL_RANGES.get(
			item.get("rarity", "Common"), SHOP_SELL_RANGES["Common"]
		)
		item["shop_sell_price"] = randi_range(bounds.x, bounds.y)

	var enchantments: Array = item.get("enchantments", [])
	return int(item["shop_sell_price"]) + 100 * enchantments.size()

func _open_shop() -> void:
	_register_shop_visit()
	combat_state = "shop"
	get_node("BetweenFightsPanel").hide()

	get_node("HPBackground").hide()
	get_node("PlayerHP").hide()

	var shop_layer := CanvasLayer.new()
	shop_layer.layer = 50
	add_child(shop_layer)

	var backdrop := ColorRect.new()
	shop_backdrop = backdrop
	backdrop.color = Color("#252525")
	backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	shop_layer.add_child(backdrop)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center := CenterContainer.new()
	backdrop.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel := PanelContainer.new()
	center.add_child(panel)

	var list := VBoxContainer.new()
	list.custom_minimum_size.x = 540
	list.add_theme_constant_override("separation", 8)
	panel.add_child(list)

	var title := Label.new()
	title.text = "Wave %d Shop" % encounter_number
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(title)

	var gold := Label.new()
	shop_gold_label = gold
	gold.text = "Gold: %d" % player_gold
	gold.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(gold)

	var feedback := Label.new()
	var materials: Array[String] = []
	var scrolls: Array[String] = []

	for item_id in consumable_database:
		if consumable_database[item_id].get("boss_only", false):
			continue
		match consumable_database[item_id].get("item_type"):
			"enchant_material":
				materials.append(item_id)
			"scroll":
				scrolls.append(item_id)

	for group in [materials, scrolls]:
		if group.is_empty():
			continue

		var count := randi_range(2, 4) if group == materials else randi_range(1, 2)
		for index in range(count):
			var item := _create_item_instance(str(group.pick_random()))
			var price := _get_shop_buy_price(_roll_shop_base_price(item))
			var item_name := str(item["name"])

			if item.get("item_type") == "enchant_material":
				var pool := _get_material_enchantment_pool(item)
				var enchantment_ids := _get_material_enchantments(item)
				if not enchantment_ids.is_empty():
					var enchantment: Dictionary = pool.get(enchantment_ids[0], {})
					item_name += " · " + str(enchantment.get("name", enchantment_ids[0]))
					if enchantment_ids.size() > 1:
						item_name += " +%d more" % (enchantment_ids.size() - 1)

			var buy := Button.new()
			buy.text = "%s  |  %d gold" % [item_name, price]
			buy.tooltip_text = _format_item_tooltip(item)
			buy.pressed.connect(_buy_shop_item.bind(item, price, buy, gold, feedback))
			list.add_child(buy)

	list.add_child(feedback)

	var leave := Button.new()
	leave.text = "Continue"
	leave.custom_minimum_size = Vector2(200, 48)
	leave.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	leave.pressed.connect(func():
		if combat_state != "shop":
			return

		backdrop.hide()
		shop_backdrop = null
		shop_gold_label = null
		shop_layer.queue_free()
		get_node("HPBackground").show()
		get_node("PlayerHP").show()
		combat_state = "between_fights"
		_on_continue_button_pressed()
	)
	var actions := HBoxContainer.new()
	actions.alignment = BoxContainer.ALIGNMENT_CENTER
	actions.add_theme_constant_override("separation", 12)
	list.add_child(actions)

	var bag_button := Button.new()
	bag_button.text = "Bag"
	bag_button.custom_minimum_size = Vector2(140, 48)
	bag_button.pressed.connect(_open_bag)
	actions.add_child(bag_button)
	actions.add_child(leave)


func _buy_shop_item(item: Dictionary, price: int, buy: Button, gold: Label, feedback: Label) -> void:
	if combat_state != "shop" or buy.disabled:
		return

	if player_gold < price:
		feedback.text = "You need %d more gold." % (price - player_gold)
		return

	if not _add_item_to_inventory(item):
		feedback.text = "Your Bag is full."
		return

	player_gold -= price
	gold.text = "Gold: %d" % player_gold
	buy.disabled = true
	buy.text += "  |  Sold"
	feedback.text = "Added to your Bag."

func _get_wave_type():
	if encounter_number == EnemyData.SLIME_POTENTATE_WAVE:
		return "boss"
	
	if encounter_number % 10 == 5:
		return "shop"
	
	return "normal"





func _roll_enemy_type() -> String:
	var basic_enemies = [
		"slime",
		"skeleton",
		"bat"
	]

	var weapon_enemies = [
		"sword skeleton",
		"rogue_skeleton",
		"caestus_skeleton",
		"spear_skeleton",
		"helmet_spear_skeleton"
	]

	if randf() < 0.75:
		return basic_enemies.pick_random()
	else:
		return weapon_enemies.pick_random()






func _generate_encounter() -> void:
	boss_encounter = _get_wave_type() == "boss"
	boss_chest_pending = false
	boss_summoned = false
	boss_absorbed = false
	boss_exploded = false
	boss_attacks_since_summon = 0
	boss_absorb_turns = 0
	boss_absorb_damage = 0.0
	player_absorb_turns = 0
	taunt_active = false
	_clear_temporary_summons()
	for i in range(int(passive_inventory.get("slime_in_a_bottle", {}).get("quantity", 0))):
		_summon_allied_slime()
	_refresh_summons()
	earth_pillars_turns = 0
	holy_sacrifice_turns = 0
	_set_mana(
		1 + floori(float(_get_total_stat("Intelligence")) / 20.0)
		+ _get_gear_bonus("starting_mana_bonus")
	)
	wave_has_chest = _get_wave_type() == "normal" and randf() < 0.25
	wave_flawless = true
	flawless_awarded = false
	wave_xp_earned = 0
	wave_gold_earned = 0
	get_node("CombatLog").clear()

	_add_combat_log("Wave %d" % encounter_number, "warning")
	_roll_speed_demon()
	virtuous_charged = false
	virtuous_active = false


	if pending_regen_message > 0:
		_add_combat_log(
			"Regeneration restored %d HP!" % pending_regen_message,
			"success"
		)
		pending_regen_message = 0

	_clear_ground_loot()
	loot_continue_button.hide()

	active_enemies = [null, null, null, null, null]
	pending_reinforcements.clear()
	enemy_turn_queue.clear()
	current_attacker_slot = -1

	print("Wave type: ", _get_wave_type())

	if boss_encounter:
		_spawn_enemy(SlimeContent.BOSS_ID, SlimeContent.CENTER_SLOT)
		_select_enemy(SlimeContent.CENTER_SLOT)
		return

	var enemy_count = _roll_enemy_count()

	for i in range(enemy_count):
		var enemy_id = _roll_enemy_type()
		_spawn_enemy_in_next_slot(enemy_id)

	_select_default_enemy()

	print("Encounter %d: %d enemies spawned" % [
		encounter_number,
		enemy_count
	])




func _on_line_edit_text_changed(new_text: String) -> void:
	var command = new_text.strip_edges().to_lower()
	if combat_state == "player_turn" and chosen_attack == "" and _try_cast_spell(command):
		return
	if combat_state == "player_turn" and chosen_attack == "barrage":
		if command == "ora":
			_perform_barrage_hit()
		return

	if combat_state == "player_turn":
		if _try_use_consumable_command(command):
			return


	if combat_state == "player_turn" and chosen_attack == "":
		var special_attacks = equipped_weapon.get(
			"special_attacks", {}
		)

		if command == "barrage":
			get_node("LineEdit").text = ""

			if not _has_set_bonus("barrage"):
				_add_combat_log(
					"Barrage requires a fist weapon and a Pauldron equipped in the chest slot!",
					"warning"
				)
				return

			_start_barrage()
			return

		if special_attacks.has(command) or command in ["pierce", "weak point", "uppercut", "bite", "wing inject"]:
			if special_attacks.has(command):
				chosen_attack = command
				get_node("LineEdit").editable = false
				get_node("LineEdit").clear()
				_execute_attack_immediately()
			else:
				_add_combat_log(
					"Your equipped weapon cannot use %s!" % command,
					"warning"
				)
				get_node("LineEdit").clear()

			return


	match command:
		"taunt":
			if combat_state == "player_turn" and chosen_attack == "" and not allied_summons.is_empty():
				taunt_active = true
				get_node("LineEdit").clear()
				_add_combat_log("Taunt: enemies will target you this round.", "success")

		"focus":
			if combat_state == "player_turn":
				_use_focus()

		"attack":
			if combat_state == "player_turn" and chosen_attack == "":
				chosen_attack = "attack"
				get_node("LineEdit").editable = false
				get_node("LineEdit").text = ""
				_execute_attack_immediately()

		"body slam":
			if combat_state == "player_turn" and chosen_attack == "":
				if _get_total_stat("Fortitude") >= 25:
					chosen_attack = "body slam"
					get_node("LineEdit").editable = false
					get_node("LineEdit").clear()
					_execute_attack_immediately()
				else:
					get_node("LineEdit").clear()
					_add_combat_log("Body Slam requires 25 Fortitude!", "warning")

		"protect":
			if combat_state == "player_turn" and chosen_attack == "":
				if _get_total_stat("Fortitude") >= 50:
					chosen_attack = "protect"
					get_node("LineEdit").editable = false
					get_node("LineEdit").clear()
					_execute_attack_immediately()
				else:
					get_node("LineEdit").clear()
					_add_combat_log("Protect requires 50 Fortitude!", "warning")

			elif combat_state == "defense_turn" and chosen_defense == "":
				if _get_total_stat("Fortitude") >= 50:
					chosen_defense = "protect"
					_accelerate_defense_timer()
					get_node("AttackLabel").text = "Protect registered!"
					get_node("LineEdit").editable = false
				else:
					_add_combat_log("Protect requires 50 Fortitude!", "warning")

				get_node("LineEdit").clear()

		"heavy attack":
			if combat_state == "player_turn" and chosen_attack == "":
				chosen_attack = "heavy attack"
				get_node("LineEdit").editable = false
				get_node("LineEdit").text = ""
				_execute_attack_immediately()

		"wide slash":
			if combat_state == "player_turn" and chosen_attack == "":
				if _get_total_stat("Strength") >= 25:
					chosen_attack = "wide slash"
					get_node("LineEdit").editable = false
					get_node("LineEdit").text = ""
					_execute_attack_immediately()
				else:
					get_node("LineEdit").text = ""

		"exposing hug":
			if combat_state == "player_turn" and chosen_attack == "":
				if _get_total_stat("Charisma") >= 25:
					chosen_attack = "exposing hug"
					get_node("LineEdit").editable = false
					get_node("LineEdit").text = ""
					_execute_attack_immediately()
				else:
					get_node("LineEdit").text = ""

		"frost wind":
			if combat_state == "player_turn" and chosen_attack == "":
				print("Frost Wind is not implemented yet!")
			get_node("LineEdit").text = ""

		"counter":
			if combat_state == "defense_turn" and chosen_defense == "":
				if not _is_last_enemy_attack_stage():
					_add_combat_log(
						"Counter can only be used on the final attack of a combo!",
						"warning"
					)

				elif _get_total_stat("Strength") >= 15:
					chosen_defense = "counter"
					_accelerate_defense_timer()
					get_node("AttackLabel").text = "Counter registered!"
					get_node("LineEdit").editable = false

				else:
					_add_combat_log("Counter requires 15 Strength!", "warning")

				get_node("LineEdit").clear()

		"attack through", "attack thru":
			if combat_state == "defense_turn" and chosen_defense == "":
				if not _is_last_enemy_attack_stage():
					_add_combat_log(
						"Attack Through can only be used on the final attack of a combo!",
						"warning"
					)

				elif _get_total_stat("Willpower") >= 25:
					chosen_defense = "attack through"
					_accelerate_defense_timer()
					get_node("AttackLabel").text = "Attack Through registered!"
					get_node("LineEdit").editable = false

				else:
					_add_combat_log(
						"Attack Through requires 25 Willpower!",
						"warning"
					)

				get_node("LineEdit").clear()

		"dodge":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "dodge"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Dodge registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""

		"parry":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "parry"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Parry registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""

		"block":
			if combat_state == "defense_turn" and chosen_defense == "":
				chosen_defense = "block"
				_accelerate_defense_timer()
				get_node("AttackLabel").text = "Block registered!"
				get_node("LineEdit").editable = false
			get_node("LineEdit").text = ""


func _use_focus() -> void:
	if combat_state != "player_turn":
		return

	if chosen_attack != "":
		return

	if _get_total_stat("Willpower") < 15:
		get_node("LineEdit").clear()
		_add_combat_log("Focus requires 15 Willpower!", "warning")
		return

	if focus_used_this_turn:
		get_node("LineEdit").clear()
		_add_combat_log("You already used Focus this turn!", "warning")
		return

	if focus_damage_ready:
		get_node("LineEdit").clear()
		_add_combat_log("Focus is already active!", "warning")
		return

	focus_used_this_turn = true
	focus_damage_ready = true

	var restored_posture = 0

	if not guard_exhausted:
		restored_posture = mini(2, successful_blocks)
		successful_blocks -= restored_posture

	_update_guard_display()

	_add_combat_log(
		"FOCUS! Restored %d posture. Next attack deals 50%% more damage!"
		% restored_posture,
		"success"
	)

	get_node("LineEdit").clear()

	if _get_total_stat("Willpower") >= 50:
		get_node("AttackLabel").text = "Focused! Attack now! (+50% damage)"
		get_node("LineEdit").editable = true
		get_node("LineEdit").grab_focus()
	else:
		get_node("AttackTimer").stop()
		_finish_player_turn(1.0)




func _try_use_consumable_command(command: String) -> bool:
	if combat_state != "player_turn":
		return false

	if chosen_attack != "":
		return false

	for item in inventory:
		if item.get("item_type", "") != "consumable":
			continue

		var commands = item.get("commands", [])

		if not commands.has(command):
			continue

		var heal_amount = int(item.get("heal_amount", 0)) + roundi(player_max_health * float(item.get("heal_fraction", 0.0)))
		var on_use_effects = item.get("on_use_effects", [])

		if heal_amount <= 0 and on_use_effects.is_empty():
			return false

		if player_health >= player_max_health and on_use_effects.is_empty():
			_add_combat_log(
				"Your health is already full!",
				"warning"
			)
			get_node("LineEdit").clear()
			return true

		var previous_health = player_health

		player_health = mini(
			player_health + heal_amount,
			player_max_health
		)

		var actual_healing = player_health - previous_health

		for effect in on_use_effects:
			var effect_id = str(effect.get("id", ""))
			var stacks = int(effect.get("stacks", 1))
			var turns = int(effect.get("turns", -1))

			_apply_player_status_effect(
				effect_id,
				stacks,
				turns
			)

		item["quantity"] = int(item.get("quantity", 1)) - 1

		if item["quantity"] <= 0:
			inventory.erase(item)

		get_node("PlayerHP").text = "HP: %d/%d" % [
			player_health,
			player_max_health
		]

		_add_combat_log(
			"You used %s and restored %d HP!"
			% [item["name"], actual_healing],
			"success"
		)

		get_node("LineEdit").clear()
		get_node("LineEdit").editable = true
		get_node("LineEdit").grab_focus()

		return true

	return false



func _enemy_attack(damage, health):
	if health == 0:
		return health
	damage = roundi(damage)
	if health > 0:
		var actual_damage = min(damage, health)
		if actual_damage > 0:
			wave_flawless = false
		health -= actual_damage
		health = max(0, health)
		get_node("PlayerHP").text = "HP: %d/%d" % [health, player_max_health]
		print(health)
		print("%s attacked you!" % enemy_name)
		if health == 0:
			print("You died to a %s!" % enemy_name)
			get_node("Label").text = "You died by %s!" % enemy_name
			_add_combat_log("You were defeated by %s." % enemy_name, "failure")
	return health


func _finish_player_turn(vulnerability):
	virtuous_active = false
	get_node("LineEdit").editable = false
	get_node("LineEdit").hide()
	if player_health <= 0:
		combat_state = "game_over"
		get_node("AttackLabel").text = "You were defeated!"
		restart_button.show()
		return

	if _living_enemy_count() == 0 and pending_reinforcements.is_empty():
		_enter_loot_collection()
	else:
		_begin_enemy_phase(vulnerability)


func _debug_clear_wave() -> void:
	if combat_state not in [
		"planning_phase",
		"attack_preparing",
		"player_turn",
		"enemy_preparing",
		"defense_preparing",
		"defense_turn"
	]:
		return

	for timer_name in [
		"AttackReadyTimer",
		"AttackTimer",
		"EnemyDelayTimer",
		"DefenseTimer"
	]:
		get_node(timer_name).stop()

	combat_state = "debug_clearing"

	_add_combat_log("DEBUG: Instantly defeated the enemy wave!", "success")

	while _living_enemy_count() > 0 or not pending_reinforcements.is_empty():
		for slot_index in range(MAX_ENEMY_SLOTS):
			var enemy = active_enemies[slot_index]

			if enemy == null:
				continue

			_defeat_enemy(slot_index, true)

		_deploy_reinforcements()

	enemy_turn_queue.clear()
	current_attacker_slot = -1

	_select_default_enemy()
	_enter_loot_collection()


func _award_flawless_bonus() -> void:
	if flawless_awarded or not wave_flawless:
		return

	flawless_awarded = true

	var bonus_xp = roundi(wave_xp_earned * 0.50)
	var bonus_gold = roundi(wave_gold_earned * 0.50)

	_add_combat_log(
		"✦ FLAWLESS VICTORY ✦ Wave %d cleared without taking damage!" % encounter_number,
		"flawless"
	)

	if bonus_xp > 0:
		_gain_xp(bonus_xp, false)

	if bonus_gold > 0:
		player_gold += bonus_gold

	_add_combat_log(
		"✦ Flawless Bonus: +%d XP | +%d Gold ✦" % [
			bonus_xp,
			bonus_gold
		],
		"flawless"
	)

func _clear_player_status_effects() -> void:
	player_active_effects.clear()
	_refresh_player_status_display()

func _enter_loot_collection() -> void:
	speed_demon_factor = 1.0
	combat_state = "loot_collection"
	_clear_player_status_effects()
	if player_health > 0 and _has_armor_enchantment("healthy"):
		var previous_hp = player_health
		_change_enchantment_hp(0.05)
		if player_health > previous_hp:
			_add_combat_log("Curse of the Healthy restored %d HP." % (player_health - previous_hp), "success")
	_award_flawless_bonus()

	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	_hide_attack_stage_bars()

	get_node("AttackLabel").text = "Collect your loot or continue!"

	for button_name in ["AttackButton", "BookButton", "RunButton"]:
		get_node(button_name).hide()

	get_node("BagButton").show()

	loot_continue_button.show()
	_clear_temporary_summons()
	if boss_chest_pending:
		boss_chest_pending = false
		_show_loot_chest(SlimeContent.BOSS_ID)
	elif wave_has_chest:
		wave_has_chest = false
		_show_loot_chest()

func _show_loot_chest(boss_id: String = "") -> void:
	if is_instance_valid(loot_chest):
		loot_chest.hide()
		loot_chest.queue_free()
	loot_chest = Button.new()
	loot_chest.name = "LootChest"
	loot_chest.size = Vector2(96, 96)
	loot_chest.flat = true
	loot_chest.focus_mode = Control.FOCUS_NONE
	loot_chest.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	loot_chest.expand_icon = true
	loot_chest.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	loot_chest.set_meta("boss_id", boss_id)
	var chest: Dictionary = CHEST_VARIANTS.get(boss_id, CHEST_VARIANTS[""])
	loot_chest.icon = _load_optional_texture(chest["closed_icon"])
	if loot_chest.icon == null:
		loot_chest.text = "Open Chest"

	loot_chest.z_index = 31
	add_child(loot_chest)
	loot_chest.position = to_local(get_viewport_rect().get_center()) - loot_chest.size / 2.0 + Vector2(0.0, -150.0)
	loot_chest.pivot_offset = loot_chest.size / 2.0
	loot_chest.scale = Vector2(2.5, 2.5)
	loot_chest.pressed.connect(_on_loot_chest_pressed)
	if combat_state == "loot_collection":
		var chest_name: String = chest["name"]
		get_node("AttackLabel").text = "A %s appeared! Click it to open." % chest_name


func _get_chest_loot_pools() -> Dictionary:
	var pools: Dictionary = {}
	var eligible_ids: Dictionary = {}
	var items = weapon_database.merged(armor_database).merged(consumable_database)

	for enemy in enemy_database.values():
		for drop in enemy.get("loot_table", []):
			var item_id = str(drop.get("item_id", ""))
			if item_id not in ["bat_wing", "batsickle", "slime_goop"] and items.has(item_id) and not items[item_id].get("boss_only", false):
				eligible_ids[item_id] = true

	for item_id in ["terra", "blitz", "gust", "hallow", "flarebreath", "hoarfrost", "umbra"]:
		if weapon_database.has(item_id):
			eligible_ids[item_id] = true

	for item_id in consumable_database:
		if consumable_database[item_id].get("item_type") in ["scroll", "enchant_material"] and not consumable_database[item_id].get("boss_only", false):
			eligible_ids[item_id] = true

	for item_id in armor_database:
		if armor_database[item_id].get("chest_loot", false):
			eligible_ids[item_id] = true

	for item_id in eligible_ids:
		var rarity = str(items[item_id].get("rarity", "Common"))
		if not pools.has(rarity):
			pools[rarity] = []
		pools[rarity].append(item_id)

	return pools

func _roll_chest_item(pools: Dictionary, allow_scrolls: bool = true) -> String:
	var eligible_pools := {}
	var eligible_weights := {}
	var total_weight := 0.0

	for rarity in pools:
		var original: Array = pools[rarity]
		var eligible := original
		if not allow_scrolls:
			eligible = original.filter(func(item_id):
				return consumable_database.get(item_id, {}).get("item_type") != "scroll"
			)

		var weight := float(rarity_weights.get(rarity, 0.0))
		if eligible.is_empty() or weight <= 0.0:
			continue

		weight *= float(eligible.size()) / float(original.size())
		eligible_pools[rarity] = eligible
		eligible_weights[rarity] = weight
		total_weight += weight

	if total_weight <= 0.0:
		return ""

	var roll := randf() * total_weight
	var last_rarity = null
	for rarity in eligible_pools:
		last_rarity = rarity
		roll -= float(eligible_weights[rarity])
		if roll < 0.0:
			return str(eligible_pools[rarity].pick_random())

	return str(eligible_pools[last_rarity].pick_random())


func _on_loot_chest_pressed() -> void:
	if combat_state not in ["planning_phase", "loot_collection"] or bag_open:
		return
	if not is_instance_valid(loot_chest) or loot_chest.disabled:
		return

	var boss_id := str(loot_chest.get_meta("boss_id", ""))
	var chest: Dictionary = CHEST_VARIANTS.get(boss_id, CHEST_VARIANTS[""])
	var pools: Dictionary = chest["loot_pool"] if chest.has("loot_pool") else _get_chest_loot_pools()
	if pools.is_empty():
		push_warning("The chest has no eligible items.")
		return

	loot_chest.disabled = true
	loot_chest.z_index = ground_loot_layer.z_index - 1
	loot_chest.mouse_filter = Control.MOUSE_FILTER_IGNORE
	loot_chest.icon = _load_optional_texture(chest["open_icon"])
	loot_chest.text = "Opened" if loot_chest.icon == null else ""
	loot_chest.add_theme_color_override("icon_disabled_color", Color.WHITE)
	if combat_state == "loot_collection":
		get_node("AttackLabel").text = "Collect your loot or continue!"

	var count_roll = randi_range(1, 110)
	var count = 2
	if count_roll > 95:
		count = 5
	elif count_roll > 75:
		count = 4
	elif count_roll > 50:
		count = 3
	if chest.has("min_drops"):
		count = randi_range(chest["min_drops"], chest["max_drops"])

	var origin = ground_loot_layer.to_local(loot_chest.get_global_rect().get_center())
	var scroll_dropped := false
	for i in range(count):
		var item_id = _roll_chest_item(pools, not scroll_dropped)
		if item_id.is_empty():
			break

		var item = _create_item_instance(item_id, true)
		if item.get("item_type") == "scroll":
			scroll_dropped = true
		pending_loot.append(item)
		var spread = (float(i) - (count - 1) * 0.5) * 72.0
		var landing = origin + Vector2(spread, 88.0)
		_spawn_ground_loot(item, -1, origin, landing)

func _on_loot_continue_pressed() -> void:
	if combat_state != "loot_collection":
		return

	_clear_ground_loot()
	loot_continue_button.hide()
	_open_between_fights()

func _is_last_enemy_attack_stage() -> bool:
	if active_attack_stages.is_empty():
		return false

	return current_attack_stage == active_attack_stages.size() - 1

func _defend(defense_type):
	var damage_taken = incoming_damage
	if current_enemy_attack.get("aoe", false):
		_resolve_enemy_hit_on_summons()
	if current_enemy_attack.get("unavoidable", false) and defense_type != "protect":
		defense_type = "unavoidable"
	var guardly_counter = false
	var result_message = ""
	var attack_name = current_enemy_attack["name"]
	var result_type = "failure"
	var is_final_stage = _is_last_enemy_attack_stage()

	var counter_allowed = (
		is_final_stage
		and (
			bool(current_enemy_attack.get("can_parry", false))
			or bool(current_enemy_attack.get("can_block", false))
		)
	)
	
	match defense_type:
		"unavoidable":
			result_message = "%s cannot be evaded." % attack_name
		"none":
			result_message = "You failed to react to %s." % attack_name
		"invalid":
			result_message = ""

		"counter":
			if counter_allowed:
				damage_taken = roundi(float(incoming_damage) * 0.75)
				result_message = "You countered %s!" % attack_name
				result_type = "success"
			else:
				result_message = "You cannot counter %s!" % attack_name

		"attack through":
			damage_taken = incoming_damage

			if is_final_stage:
				result_message = "You attacked through %s!" % attack_name
				result_type = "success"
			else:
				result_message = "Attack Through cannot be used before the final combo hit!"

		"protect":
			_apply_player_status_effect("protected", 1)
			result_message = "You used Protect against %s!" % attack_name
			result_type = "success"

		"dodge":
			if current_enemy_attack["can_dodge"]:
				damage_taken = 0
				result_message = "You successfully dodged %s." % attack_name
				result_type = "success"
			else:
				result_message = "You failed to dodge %s." % attack_name
	
		"parry":
			if current_enemy_attack["can_parry"]:
				damage_taken = roundi(incoming_damage * 0.10)
				result_message = "You parried %s." % attack_name
				result_type = "success"
			else:
				result_message = "You failed to parry %s." % attack_name
		"block":
			if guard_exhausted:
				result_message = "You failed to block %s! Guard shattered." % attack_name
			
			elif current_enemy_attack["can_block"]:
				if current_enemy_attack["guardbreak"]:
					damage_taken = roundi(incoming_damage * 0.75)
					successful_blocks = 0
					result_message = "%s broke through your guard!" % attack_name
					result_type = "guardbreak"
				
				else:
					successful_blocks += 1
					
					if successful_blocks >= _calculate_block_limit() and _has_armor_enchantment("guardly"):
						successful_blocks = 0
						damage_taken = 0
						guardly_counter = true
						result_message = "Guardly turned your block into a full counter!"
						result_type = "success"
					elif successful_blocks >= _calculate_block_limit():
						damage_taken = roundi(incoming_damage * 0.75)
						guard_exhausted = true
						guard_recovery_pending = true
						result_message = "Your guard has shattered from exhaustion!"
						result_type = "guardbreak"
					
					else:
						damage_taken = roundi(incoming_damage * 0.35)
						result_message = "You blocked %s. Guard: %d/%d" % [
							attack_name,
							successful_blocks,
							_calculate_block_limit()
						]
						result_type = "success"
			else:
				result_message = "You failed to block %s." % attack_name

	if damage_taken > 0:
		if _consume_protection():
			damage_taken = 0
		elif not current_enemy_attack.get("unavoidable", false) and _wears_full_slime_set() and randf() < SlimeContent.SLIME_SET_NEGATE_CHANCE:
			damage_taken = 0
			_add_combat_log("Your slime armor absorbed the hit!", "success")

	var actual_damage_taken = min(damage_taken, player_health)

	if defense_type == "invalid":
		if actual_damage_taken > 0:
			_add_combat_log(
				"You took %d damage." % actual_damage_taken,
				"failure"
			)
		else:
			_add_combat_log("You took no damage.", "failure")
	else:
		if actual_damage_taken > 0:
			result_message += " You took %d damage." % actual_damage_taken
		else:
			result_message += " You took no damage."

		_add_combat_log(result_message, result_type)
	
	get_node("AttackLabel").text = ""
	
	var previous_hp = player_health
	player_health = _enemy_attack(damage_taken, player_health)
	_on_player_damaged(previous_hp)

	if player_health > 0 and current_attacker_slot >= 0:
		if active_enemies[current_attacker_slot] != null:
			var counter_damage = 0.0

			if guardly_counter:
				counter_damage = _calculate_player_attack_damage()
			elif defense_type == "counter" and counter_allowed:
				counter_damage = _calculate_player_attack_damage(0.5)

			elif defense_type == "attack through" and is_final_stage:
				counter_damage = _calculate_player_attack_damage(1.0)

			if counter_damage > 0.0 and (guardly_counter or not _try_clumsy_attack(current_attacker_slot)):
				var attacking_slot = current_attacker_slot

				_damage_selected_enemy(
					counter_damage,
					false,
					"",
					attacking_slot,
					defense_type
				)

				_add_combat_log(
					"You retaliated with %s!" % defense_type.capitalize(),
					"success"
				)

				focus_damage_ready = false

	if actual_damage_taken > 0 and player_health > 0:
		for effect in current_enemy_attack.get("on_hit_effects", []):
			var effect_id = str(effect.get("id", ""))
			var stacks = int(effect.get("stacks", 1))
			var turns = int(effect.get("turns", -1))

			_apply_player_status_effect(effect_id, stacks, turns, false)
	
	get_node("LineEdit").editable = false
	get_node("LineEdit").hide()
	if (
		player_health > 0
		and current_attacker_slot >= 0
		and active_enemies[current_attacker_slot] != null
		and current_attack_stage + 1 < active_attack_stages.size()
	):
		current_attack_stage += 1
		_start_next_attack_stage()
		return
	if player_health > 0:
		_start_next_enemy_turn()
	else:
		combat_state = "game_over"
		restart_button.show()


func _choose_enemy_attack():
	var total_weight = 0
	
	for attack in enemy_attacks:
		total_weight += attack["weight"]
	
	var roll = randi_range(1, total_weight)
	
	for attack in enemy_attacks:
		roll -= attack["weight"]
		
		if roll <= 0:
			return attack
	
	return enemy_attacks.back()


func _add_combat_log(message, event_type = "normal"):
	var color = "#D0D0D0"
	
	match event_type:
		"success":
			color = "#86C7A0" # Muted green
		"failure":
			color = "#E58B86" # Soft red
		"warning":
			color = "#D8A66A" # Amber
		"damage":
			color = "#75BFFF" # Light blue
		"guardbreak":
			color = "#C59AFF" # Purple
		"gold":
			color = "#E5C35B" # Warm gold yellow
		"overkill":
			color = "#FF55D4" # Vibrant neon pink
		"critical":
			color = "#FFD166" #
		"flawless":
			color = "#59E6D3" # Bright shimmering turquoise
		"status_damage":
			color = "#C89BFF" # Lavender-purple
	
	var combat_log = get_node("CombatLog") as RichTextLabel
	combat_log.push_color(Color(color))
	combat_log.add_text(str(message))
	combat_log.pop()
	combat_log.newline()


func _on_enemy_delay_timer_timeout() -> void:
	_start_enemy_attack()

func _build_repeated_attack(repeat: Dictionary) -> Array[Dictionary]:
	var stages: Array[Dictionary] = []
	for index in range(randi_range(int(repeat["min_hits"]), int(repeat["max_hits"]))):
		var hit: Dictionary = repeat["hit"].duplicate(true)
		if index == 0:
			hit["reaction_time"] = repeat["first_reaction_time"]
		hit["fixed_combo_timing"] = true
		stages.append(hit)

	var finisher: Dictionary = repeat["finisher"].duplicate(true)
	finisher["fixed_combo_timing"] = true
	stages.append(finisher)
	return stages


func _start_enemy_attack() -> void:
	if combat_state != "enemy_preparing" and combat_state != "defense_preparing":
		return

	var selected_attack = _choose_enemy_attack()
	if _current_attacker_is_boss():
		selected_attack = _choose_potentate_move(selected_attack)
		if selected_attack.is_empty():
			$LineEdit.hide()
			_start_next_enemy_turn()
			return

	if selected_attack.has("repeated_attack"):
		selected_attack = {"stages": _build_repeated_attack(selected_attack["repeated_attack"])}

	if selected_attack.has("stages"):
		active_attack_stages = selected_attack["stages"]
	else:
		active_attack_stages = [selected_attack]

	current_attack_stage = 0
	_show_attack_stage_bars(active_attack_stages.size())
	_start_next_attack_stage()

func _get_enemy_shock_time_multiplier() -> float:
	if current_attacker_slot < 0 or current_attacker_slot >= active_enemies.size():
		return 1.0

	var attacker = active_enemies[current_attacker_slot]
	if attacker == null:
		return 1.0

	var stacks = _get_status_turns(attacker.get("active_effects", []), "shock")
	return 1.0 + minf(0.75, stacks * 0.15)

func _calculate_incoming_enemy_damage(base_damage: float) -> int:
	var damage = _enemy_stage_raw_damage(base_damage) * pending_vulnerability

	if current_attacker_slot >= 0:
		var attacker = active_enemies[current_attacker_slot]

		if attacker != null:
			var weakness_stacks = _get_status_turns(
				attacker.get("active_effects", []),
				"weakness"
			)

			var weakness_per_stack = float(
				status_effect_database["weakness"]["outgoing_damage_modifier"]
			)

			if weakness_stacks > 0:
				damage *= maxf(0.0, 1.0 + weakness_per_stack)

	var vulnerable_stacks = _get_status_turns(
		player_active_effects,
		"vulnerable"
	)

	var vulnerable_per_stack = float(
		status_effect_database["vulnerable"]["incoming_damage_modifier"]
	)

	if vulnerable_stacks > 0:
		damage *= 1.0 + vulnerable_per_stack


	var damage_type = str(current_enemy_attack.get("damage_type", "Physical"))
	var physical = damage_type in ["Physical", "Slash", "Blunt", "Pierce"]
	var resistance = _get_player_physical_resistance() if physical else _get_player_magic_resistance(damage_type)
	damage *= (1.0 - resistance) * _healthy_damage_multiplier()


	return maxi(0, roundi(damage))


func _start_next_attack_stage() -> void:
	var line_edit := $LineEdit as LineEdit
	line_edit.editable = false
	line_edit.hide()

	while current_attack_stage < active_attack_stages.size():
		current_enemy_attack = active_attack_stages[current_attack_stage]
		_choose_stage_summon_target()

		if stage_summon_target.is_empty():
			break

		_resolve_enemy_hit_on_summons()
		var completed_bar := _get_combo_stage_bar(current_attack_stage)
		if completed_bar != null:
			completed_bar.value = 0
		current_attack_stage += 1

	if current_attack_stage >= active_attack_stages.size():
		_hide_attack_stage_bars()
		_start_next_enemy_turn()
		return

	combat_state = "defense_turn"
	incoming_damage = _calculate_incoming_enemy_damage(float(current_enemy_attack["damage"]))
	chosen_defense = ""
	defense_timer_accelerated = false

	line_edit.clear()
	line_edit.show()
	line_edit.editable = true
	line_edit.grab_focus()

	var fixed_timing := bool(current_enemy_attack.get("fixed_combo_timing", false))
	var announcement := "%s is using %s!" if fixed_timing else "%s is preparing %s!"
	var message := announcement % [enemy_name, current_enemy_attack["name"]]
	if current_enemy_attack.get("unavoidable", false):
		message += " Use Protect!"

	$AttackLabel.text = message
	if current_attack_stage == 0 or fixed_timing:
		_add_combat_log(message, "warning")
	else:
		_add_combat_log("%s follows up with %s!" % [enemy_name, current_enemy_attack["name"]], "warning")

	var base_time := float(current_enemy_attack["reaction_time"])
	var final_time := base_time
	if not fixed_timing:
		if current_attack_stage > 0:
			final_time = _calculate_action_time(base_time, enemy_speed, false)
		elif active_attack_stages.size() == 1:
			final_time = _calculate_action_time(base_time)

	final_time *= _get_enemy_shock_time_multiplier() * slime_defense_time_multiplier
	defense_original_duration = final_time
	$DefenseTimer.start(final_time)

	var current_bar := _get_combo_stage_bar(current_attack_stage)
	if current_bar != null:
		current_bar.value = 100
		current_bar.show()


func _on_defense_timer_timeout() -> void:
	if combat_state != "defense_turn":
		return

	if chosen_defense == "":
		var attempted_input = get_node("LineEdit").text.strip_edges()

		if not attempted_input.is_empty():
			_add_combat_log(
				'You tried "%s" but it failed!' % attempted_input,
				"failure"
			)
			chosen_defense = "invalid"
		else:
			chosen_defense = "none"

	var completed_bar = _get_combo_stage_bar(current_attack_stage)

	if completed_bar != null:
		completed_bar.value = 0

	var was_exhausted = guard_exhausted
	var attempted_block = chosen_defense == "block"

	_defend(chosen_defense)

	if was_exhausted and attempted_block and guard_recovery_pending:
		_restore_shattered_guard()

	_update_guard_display()

	if combat_state != "defense_turn":
		_hide_attack_stage_bars()



func _calculate_agility_bonus(agility: float) -> float:
	agility = maxf(agility, 0.0)
	var bonus = agility * 0.0095

	for milestone in range(10, floori(agility) + 1, 10):
		if milestone <= 30:
			bonus += 0.05
		elif milestone <= 60:
			bonus += 0.10
		else:
			bonus += 0.15

	return bonus

func _accelerate_defense_timer():
	if combat_state != "defense_turn":
		return

	if chosen_defense == "":
		return

	if defense_timer_accelerated:
		return

	var timer = get_node("DefenseTimer")

	if timer.is_stopped():
		return

	defense_timer_accelerated = true
	timer.start(timer.time_left / 3.0)


func _get_target_speed():
	if selected_enemy_slot < 0 or selected_enemy_slot >= MAX_ENEMY_SLOTS:
		return 0
	
	var target = active_enemies[selected_enemy_slot]
	
	if target == null or target["health"] <= 0:
		return 0
	
	var frostbite_stacks = _get_status_turns(
		target.get("active_effects", []),
		"frostbite"
	)

	return _sluggish_speed_factor(target.get("active_effects", [])) * maxf(
		0.0,
		float(target["speed"]) +
		frostbite_stacks * float(status_effect_database["frostbite"]["speed_modifier"])
	)


func _get_fastest_enemy_speed():
	var fastest_speed = 0
	
	for enemy in active_enemies:
		if enemy == null or enemy["health"] <= 0:
			continue
	
		fastest_speed = maxf(fastest_speed, float(enemy["speed"]) * _sluggish_speed_factor(enemy.get("active_effects", [])))
	
	return fastest_speed


func _calculate_action_time(
	base_time,
	speed: float = float(enemy_speed),
	apply_agility: bool = true
):
	var speed_multiplier = 100.0 / (100.0 + maxf(speed, 0.0))
	var final_time = base_time * speed_multiplier

	if apply_agility:
		var agility_bonus = _calculate_agility_bonus(_get_total_stat("Agility"))
		final_time *= (1.0 + agility_bonus) * _sluggish_speed_factor(player_active_effects)

	if not apply_agility:
		var shock_stacks = _get_status_turns(
			player_active_effects,
			"shock"
		)

		var shock_modifier = float(
			status_effect_database["shock"]["reaction_time_modifier"]
		)

		final_time *= maxf(
			0.25,
			1.0 + shock_stacks * shock_modifier
		)

	return maxf(final_time, 0.001)


func _process(_delta) -> void:
	_update_ground_loot_hover()
	if dragged_loot_button != null:
		if not is_instance_valid(dragged_loot_button):
			_set_bag_drag_glow(false)
			dragged_loot_button = null
			dragged_loot_id = -1
		elif dragged_loot_button.is_queued_for_deletion():
			_set_bag_drag_glow(false)
			dragged_loot_button = null
			dragged_loot_id = -1
		else:
			dragged_loot_button.global_position = (
				get_global_mouse_position() - dragged_loot_button.size / 2.0
			)
	if combat_state == "enemy_preparing":
		var preparation_timer = get_node("EnemyDelayTimer")

		if preparation_timer.time_left <= 1.0 and preparation_timer.time_left > 0.0:
			_show_defense_warning()

	if combat_state == "defense_turn":
		var defense_timer = get_node("DefenseTimer")

		if defense_timer.time_left > 0.0:
			var percentage = (
				defense_timer.time_left / defense_timer.wait_time
			) * 100.0

			if defense_timer_accelerated:
				percentage = (
					defense_timer.time_left * 3.0 / defense_original_duration
				) * 100.0

			var current_bar = _get_combo_stage_bar(current_attack_stage)

			if current_bar != null:
				current_bar.value = clampf(percentage, 0.0, 100.0)

	elif combat_state == "player_turn":
		var attack_timer = get_node("AttackTimer")

		if attack_timer.time_left > 0.0:
			var percentage = (
				attack_timer.time_left / attack_original_duration
			) * 100.0

			get_node("ActionTimerBar").value = clampf(
				percentage,
				0.0,
				100.0
			)

	else:
		_hide_attack_stage_bars()

	if held_stat_name != "":
		if combat_state != "between_fights" or not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			held_stat_name = ""
		else:
			stat_hold_timer -= _delta

			if stat_hold_timer <= 0.0:
				if _allocate_stat(held_stat_name):
					_refresh_stat_display()
					stat_hold_timer = 0.06
				else:
					held_stat_name = ""



func _on_attack_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
		
	combat_state = "attack_preparing"
	
	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).hide()
	get_node("AttackLabel").text = "Prepare to attack!"
	
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = false
	
	get_node("AttackReadyTimer").start()


func _on_attack_ready_timer_timeout() -> void:
	if combat_state != "attack_preparing":
		return
		
	combat_state = "player_turn"
	
	get_node("LineEdit").editable = true
	get_node("LineEdit").grab_focus()
	
	get_node("AttackLabel").text = "Attack!"
	
	chosen_attack = ""
	focus_used_this_turn = false
	attack_elapsed_time = 0.0
	var base_time = 3.0
	var final_time = _calculate_action_time(base_time, _get_target_speed())
	if selected_enemy_slot >= 0 and active_enemies[selected_enemy_slot] != null:
		final_time /= _sluggish_speed_factor(active_enemies[selected_enemy_slot].get("active_effects", []))
	if _has_weapon_enchantment("hourglass"):
		final_time *= 0.8
	
	attack_original_duration = final_time
	get_node("AttackTimer").start(final_time)
	
	get_node("ActionTimerBar").value = 100
	get_node("ActionTimerBar").show()


func _show_defense_warning():
	if combat_state != "enemy_preparing":
		return
	
	combat_state = "defense_preparing"
	if not allied_summons.is_empty() and not taunt_active:
		return
	
	get_node("AttackLabel").text = "Get ready to defend!"
	
	get_node("LineEdit").text = ""
	get_node("LineEdit").show()
	get_node("LineEdit").editable = false


func _execute_attack_immediately():
	if combat_state != "player_turn":
		return
	
	attack_elapsed_time = attack_original_duration - get_node("AttackTimer").time_left
	
	get_node("AttackTimer").stop()
	_on_attack_timer_timeout()


func _start_barrage() -> void:
	var attack_timer = get_node("AttackTimer") as Timer
	if attack_timer.time_left <= 0.0:
		return

	var elapsed_time = attack_original_duration - attack_timer.time_left
	var agility_bonus = _calculate_agility_bonus(_get_total_stat("Agility"))
	var base_duration = attack_original_duration / (1.0 + agility_bonus)
	var barrage_duration = base_duration * (1.0 + agility_bonus * 0.5)
	var time_remaining = barrage_duration - elapsed_time

	chosen_attack = "barrage"
	barrage_hits = 0
	attack_original_duration = barrage_duration
	get_node("AttackLabel").text = "Barrage! Type ORA repeatedly."

	if time_remaining <= 0.0:
		_on_attack_timer_timeout()
		return

	attack_timer.start(time_remaining)

func _perform_barrage_hit() -> void:
	var attack_timer = get_node("AttackTimer") as Timer

	if attack_timer.time_left <= 0.0:
		return

	get_node("LineEdit").text = ""

	if _try_clumsy_attack(selected_enemy_slot):
		_execute_attack_immediately()
		return

	var barrage: Dictionary = set_bonus_database["barrage"]
	var multiplier = float(barrage["ora_damage_multiplier"])
	var damage = _calculate_player_attack_damage(multiplier)

	if not _damage_selected_enemy(damage):
		return

	barrage_hits += 1
	focus_damage_ready = false
	get_node("AttackLabel").text = "Barrage! ORA hits: %d" % barrage_hits

	if player_health <= 0 or _living_enemy_count() == 0:
		_execute_attack_immediately()

func _on_attack_timer_timeout() -> void:
	if combat_state != "player_turn":
		return

	get_node("ActionTimerBar").value = 0
	get_node("ActionTimerBar").hide()

	var special_attacks: Dictionary = equipped_weapon.get("special_attacks", {})
	var weapon_attack = (
		chosen_attack in ["attack", "heavy attack", "body slam", "wide slash"]
		or special_attacks.has(chosen_attack)
	)
	if weapon_attack and _try_clumsy_attack(selected_enemy_slot):
		_finish_player_turn(1.0)
		return

	match chosen_attack:
		"barrage":
			get_node("AttackTimer").stop()
			_add_combat_log(
				"Barrage landed %d ORA hits!" % barrage_hits,
				"success" if barrage_hits > 0 else "failure"
			)
			_finish_player_turn(1.0)

		"attack":
			var damage = _calculate_player_attack_damage()
			_damage_selected_enemy(damage)

			if focus_damage_ready:
				_add_combat_log("Focus empowered your attack!", "success")
				focus_damage_ready = false

			_finish_player_turn(1.0)

		"body slam":
			var damage = _calculate_player_attack_damage(2.0)
			var target_slot = selected_enemy_slot

			_damage_selected_enemy(damage)

			if target_slot >= 0 and active_enemies[target_slot] != null:
				if randf() < 0.25:
					var target = active_enemies[target_slot]
					_apply_status_effect(target, "freeze", 1, 1)

					_add_combat_log(
						"%s was stunned by Body Slam!" % target["name"],
						"success"
					)

			var self_damage = maxi(
				1,
				roundi(float(player_max_health) * 0.02 * _healthy_damage_multiplier())
			)
			var previous_hp = player_health
			player_health = maxi(0, player_health - self_damage)
			_on_player_damaged(previous_hp)

			if self_damage > 0:
				wave_flawless = false

			get_node("PlayerHP").text = "HP: %d/%d" % [
				player_health,
				player_max_health
			]

			_add_combat_log(
				"Body Slam cost you %d HP!" % self_damage,
				"failure"
			)

			focus_damage_ready = false

			if player_health <= 0:
				combat_state = "game_over"
				get_node("AttackLabel").text = "You were defeated!"
				get_node("LineEdit").hide()

				for button_name in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
					get_node(button_name).hide()

				restart_button.show()
				return

			_finish_player_turn(1.0)

		"protect":
			_apply_player_status_effect("protected", 1)
			_add_combat_log("You prepared Protect!", "success")

			focus_damage_ready = false
			_finish_player_turn(1.0)

		"heavy attack":
			var damage = _calculate_player_attack_damage(1.5, 1.0)
			_damage_selected_enemy(damage)

			if focus_damage_ready:
				_add_combat_log("Focus empowered your Heavy Attack!", "success")
				focus_damage_ready = false
			_apply_player_status_effect("vulnerable", 1, 1)
			_finish_player_turn(1.0)


		var move_name when special_attacks.has(move_name):
			var special_attack = special_attacks[move_name]
			var damage_multiplier = float(
				special_attack.get("damage_multiplier", 1.0)
			)
			var ignore_resistance = bool(
				special_attack.get("ignore_resistance", false)
			)
			var damage = _calculate_player_attack_damage(damage_multiplier)
			if special_attack.get("area_attack", false):
				_add_combat_log("You used %s!" % str(move_name).capitalize(), "success")
				_slime_area_attack(damage, move_name)
				focus_damage_ready = false
				_finish_player_turn(1.0)
				return

			var hit_resolved = _damage_selected_enemy(
				damage,
				true,
				"",
				-1,
				move_name,
				ignore_resistance
			)

			if hit_resolved:
				_add_combat_log(
					"You used %s!" % move_name.capitalize(),
					"success"
				)
				focus_damage_ready = false
			else:
				_add_combat_log("There was no target to attack!", "warning")

			_finish_player_turn(1.0)

		"exposing hug":
			if selected_enemy_slot >= 0:
				var target = active_enemies[selected_enemy_slot]

				if target != null:
					_apply_status_effect(target, "vulnerable", 3, 3)
					_apply_status_effect(target, "weakness", 3, 3)

					_add_combat_log(
						"You used Exposing Hug on %s!" % target["name"],
						"success"
					)

			focus_damage_ready = false
			_finish_player_turn(1.0)

		"wide slash":
			_perform_wide_slash()

			if focus_damage_ready:
				_add_combat_log("Focus empowered your Wide Slash!", "success")
				focus_damage_ready = false

			_finish_player_turn(1.0)

		_:
			var attempted_input = get_node("LineEdit").text.strip_edges()

			if attempted_input.is_empty():
				_add_combat_log("You failed to attack in time!", "failure")
			else:
				_add_combat_log(
					'You tried "%s" but it failed!' % attempted_input,
					"failure"
				)

			_finish_player_turn(1.0)


func _debug_add_stat_points() -> void:
	stat_points += 1000

	if combat_state == "between_fights":
		_refresh_stat_display()

	_add_combat_log("DEBUG: Added 1000 unspent stat points!", "success")


func _toggle_test_game_speed(requested_speed: float) -> void:
	if is_equal_approx(Engine.time_scale, requested_speed):
		Engine.time_scale = 1.0
	else:
		Engine.time_scale = requested_speed

	test_game_speed = Engine.time_scale

	print("TEST SPEED: ", Engine.time_scale, "x")


func _unhandled_input(event: InputEvent) -> void:
	if $NotebookLayer/EnemyNotebook.visible:
		return

	if not (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed):
		return

	if get_viewport().gui_get_hovered_control() != null:
		return

	if combat_state == "boss_intro" and is_instance_valid(boss_intro_box):
		_advance_boss_intro()
	elif combat_state == "between_fights" and is_instance_valid(campfire_intro_box):
		_advance_campfire_intro()
	else:
		return

	get_viewport().set_input_as_handled()

func _input(event):
	if $NotebookLayer/EnemyNotebook.visible:
		return
	if combat_state == "between_fights" and is_instance_valid(campfire_intro_box):
		if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE:
			_advance_campfire_intro()
			get_viewport().set_input_as_handled()
			return
	if combat_state == "boss_intro" and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_SPACE:
		_advance_boss_intro()
		get_viewport().set_input_as_handled()
		return

	if OS.is_debug_build() and event is InputEventKey and event.pressed and not event.echo:
		var handled = true

		match event.keycode:
			KEY_ALT:
				if event.location != KEY_LOCATION_RIGHT or bag_open or combat_state not in ["planning_phase", "loot_collection"]:
					handled = false
				elif (
					not is_instance_valid(loot_chest)
					or loot_chest.disabled
					or loot_chest.get_meta("debug_spawned", false)
				):
					var chest_ids := CHEST_VARIANTS.keys()
					_show_loot_chest(str(chest_ids[debug_chest_index]))
					loot_chest.set_meta("debug_spawned", true)
					debug_chest_index = (debug_chest_index + 1) % chest_ids.size()

			KEY_MENU:
				if bag_open:
					handled = false
				else:
					_debug_clear_wave()

			KEY_CTRL:
				if event.location == KEY_LOCATION_RIGHT:
					_debug_add_stat_points()
				else:
					handled = false

			KEY_BRACKETRIGHT:
				_toggle_test_game_speed(2.0)

			KEY_BACKSLASH:
				_toggle_test_game_speed(10.0)

			_:
				handled = false

		if handled:
			get_viewport().set_input_as_handled()
			return

	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if _is_mouse_over_closed_chest():
				_on_loot_chest_pressed()
				get_viewport().set_input_as_handled()
				return
			var loot = _get_ground_loot_under_mouse()
			if loot != null:
				var loot_id := int(loot.get_meta("loot_id"))
				if event.double_click:
					_on_ground_loot_hovered(loot_id)
				else:
					_on_ground_loot_pressed(loot_id, loot)
				get_viewport().set_input_as_handled()
				return
		elif is_instance_valid(dragged_loot_button):
			_finish_loot_drag()
			get_viewport().set_input_as_handled()
			return

	if event is InputEventKey and event.pressed:
		var line_edit = get_node("LineEdit") as LineEdit

		if line_edit.has_focus() and (combat_state == "player_turn" or combat_state == "defense_turn"):
			if event.ctrl_pressed or event.meta_pressed:
				if event.keycode in [KEY_A, KEY_C, KEY_V, KEY_X]:
					get_viewport().set_input_as_handled()
					return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F11 or (event.keycode == KEY_ENTER and event.alt_pressed):
			var current_mode = DisplayServer.window_get_mode()

			if current_mode == DisplayServer.WINDOW_MODE_FULLSCREEN:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			else:
				DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

			get_viewport().set_input_as_handled()


func _is_mouse_over_closed_chest() -> bool:
	return (
		combat_state in ["planning_phase", "loot_collection"]
		and not bag_open
		and is_instance_valid(loot_chest)
		and loot_chest.is_visible_in_tree()
		and not loot_chest.disabled
		and loot_chest.get_global_rect().has_point(get_global_mouse_position())
	)

func _get_ground_loot_under_mouse() -> Button:
	if bag_open or combat_state not in ["planning_phase", "loot_collection"]:
		return null
	if _is_mouse_over_closed_chest():
		return null
	if not is_instance_valid(ground_loot_layer) or not ground_loot_layer.is_visible_in_tree():
		return null

	var mouse = get_global_mouse_position()
	for i in range(ground_loot_layer.get_child_count() - 1, -1, -1):
		var loot = ground_loot_layer.get_child(i) as Button
		if loot == null or loot.disabled or loot.is_queued_for_deletion() or not loot.is_visible_in_tree():
			continue
		if loot.get_global_rect().has_point(mouse):
			return loot
	return null


func _update_ground_loot_hover() -> void:
	if not is_instance_valid(ground_loot_tooltip):
		return

	var description := ""
	if not is_instance_valid(dragged_loot_button):
		if bag_open:
			var slot = get_viewport().gui_get_hovered_control()
			if is_instance_valid(slot):
				description = str(slot.get_meta("equipped_tooltip", ""))
		else:
			var loot = _get_ground_loot_under_mouse()
			if loot != null:
				description = str(loot.get_meta("loot_tooltip", ""))

	if description.is_empty():
		_hide_ground_loot_tooltip()
		return

	var label = ground_loot_tooltip.get_node("StatsLabel") as Label
	if not ground_loot_tooltip.visible or label.text != description:
		_show_ground_loot_tooltip(description)

	ground_loot_tooltip.global_position = get_global_mouse_position() + Vector2(18, 18)


func _finish_loot_drag() -> void:
	var released_button = dragged_loot_button
	var instance_id = dragged_loot_id
	dragged_loot_button = null
	dragged_loot_id = -1
	_set_bag_drag_glow(false)
	_hide_ground_loot_tooltip()

	if not is_instance_valid(released_button) or released_button.is_queued_for_deletion():
		return

	var bag_button = get_node("BagButton") as Button
	if bag_button.is_visible_in_tree() and bag_button.get_global_rect().has_point(get_global_mouse_position()):
		_on_ground_loot_hovered(instance_id)



func _unhandled_key_input(event):
	if $NotebookLayer/EnemyNotebook.visible:
		return
	if bag_open:
		if event is InputEventKey and event.pressed and not event.echo:
			if event.keycode == KEY_SPACE:
				_close_bag()
				get_viewport().set_input_as_handled()
		return
	
	if not event.pressed or event.echo:
		return
	
	if event.shift_pressed:
		if combat_state != "planning_phase" and combat_state != "attack_preparing":
			return
		
		match event.keycode:
			KEY_1:
				_select_enemy_by_number(1)
			KEY_2:
				_select_enemy_by_number(2)
			KEY_3:
				_select_enemy_by_number(3)
			KEY_4:
				_select_enemy_by_number(4)
			KEY_5:
				_select_enemy_by_number(5)
			
		return
	
	if combat_state != "planning_phase":
		return
	
	if not event.pressed or event.echo:
		return
	
	
	match event.keycode:
		KEY_1:
			selected_planning_option = 0
		KEY_2:
			selected_planning_option = 1
		KEY_3:
			selected_planning_option = 2
		KEY_4:
			selected_planning_option = 3
		KEY_SPACE:
			_confirm_planning_option()
			return
		_:
			return
	
	_update_planning_selection()


func _confirm_planning_option():
	match selected_planning_option:
		0:
			_on_attack_button_pressed()
		1:
			_on_bag_button_pressed()
		2:
			_open_enemy_notebook()
		3:
			_attempt_escape()

func _open_enemy_notebook() -> void:
	var notebook = $NotebookLayer/EnemyNotebook
	if notebook.visible:
		return

	var selected_id := ""
	if combat_state == "planning_phase":
		if selected_enemy_slot >= 0 and selected_enemy_slot < active_enemies.size():
			var enemy = active_enemies[selected_enemy_slot]
			if enemy != null and float(enemy.get("health", 0)) > 0.0:
				selected_id = str(enemy.get("id", ""))

	var discoveries: Dictionary = notebook_discoveries.get(current_dungeon_floor, {})
	var order: Array = NOTEBOOK_ENEMY_ORDER.get(current_dungeon_floor, [])
	var entries: Array[Dictionary] = []

	for enemy_id in order:
		if discoveries.has(enemy_id):
			entries.append({
				"id": enemy_id,
				"texture": _load_optional_texture(str(discoveries[enemy_id])),
			})
		else:
			entries.append({})

	notebook.open_for_floor(entries, selected_id)

func _update_planning_selection():
	$RunButton.disabled = boss_encounter
	if boss_encounter and selected_planning_option == 3:
		selected_planning_option = 0
	
	if combat_state == "planning_phase":
		get_node("AttackLabel").text = "Planning Phase"
	
	var buttons = [
		get_node("AttackButton"),
		get_node("BagButton"),
		get_node("BookButton"),
		get_node("RunButton")
	]
	
	for i in range(buttons.size()):
		if i == selected_planning_option and not (i == 1 and dragged_loot_button != null):
			buttons[i].modulate = Color("#86C7A0")
		else:
			buttons[i].modulate = Color.WHITE


func _calculate_escape_chance():
	var base_chance = 0.25
	var agility_bonus = (minf(_get_total_stat("Agility"), 100) / 100.0) * 0.50
	
	return base_chance + agility_bonus

func _calculate_block_limit():
	var willpower = _get_total_stat("Willpower")
	var bonus_blocks = floori(willpower / 20.0)
	
	return 4 + bonus_blocks


func _calculate_guard_recovery():
	var willpower = _get_total_stat("Willpower")
	var recovery = 0
	
	if willpower >= 25:
		recovery += 1
	
	if willpower >= 75:
		recovery += 1
	
	if willpower >= 100:
		recovery += 2
	
	return recovery

func _restore_shattered_guard():
	guard_exhausted = false
	guard_recovery_pending = false
	successful_blocks = 0

	_add_combat_log("Your shattered guard has recovered!", "success")
	_update_guard_display()

func _recover_guard():
	if guard_exhausted:
		return
	
	var recovery = _calculate_guard_recovery()
	
	if recovery <= 0 or successful_blocks <= 0:
		return
	
	var actual_recovery = mini(recovery, successful_blocks)
	successful_blocks -= actual_recovery
	
	_add_combat_log(
		"You recovered %d guard!" % actual_recovery,
		"success"
	)
	
	_update_guard_display()


func _update_guard_display():
	var guard_label = get_node("GuardLabel")
	var block_limit = _calculate_block_limit()

	if guard_exhausted:
		guard_label.text = "Guard: SHATTERED"
	else:
		guard_label.text = "Guard: %d/%d" % [
			successful_blocks,
			block_limit
		]


func _calculate_regen():
	var willpower = _get_total_stat("Willpower")
	var regen = floori(willpower / 10.0)
	
	if willpower >= 50:
		regen += 5
	
	if willpower >= 100:
		regen += 5
	
	return regen + _get_gear_bonus("health_regen")


func _apply_regen():
	var regen = _calculate_regen()

	if regen <= 0:
		return

	var missing_health = player_max_health - player_health
	var actual_healing = mini(regen, missing_health)

	if actual_healing <= 0:
		return

	player_health += actual_healing
	pending_regen_message = actual_healing

	get_node("PlayerHP").text = "HP: %d/%d" % [
		player_health,
		player_max_health
	]

	_add_combat_log(
		"Regeneration restored %d HP!" % actual_healing,
		"success"
	)


func _calculate_xp_required():
	if player_level >= max_level:
		return 0
	
	return 50 + 25 * (player_level - 1)


func _gain_xp(amount, apply_wave_multiplier: bool = true):
	if player_level >= max_level:
		return 0

	var xp_multiplier = 1.0 + (completed_waves * xp_bonus_per_wave)
	var final_xp = roundi(amount * xp_multiplier) if apply_wave_multiplier else roundi(amount)

	if apply_wave_multiplier:
		wave_xp_earned += final_xp

	player_xp += final_xp

	print(
		"XP gained: %d | Wave bonus: +%.0f%% | Multiplier: %.2fx"
		% [
			final_xp,
			completed_waves * xp_bonus_per_wave * 100.0,
			xp_multiplier
		]
	)

	var levels_gained = 0
	
	while player_level < max_level:
		var required_xp = _calculate_xp_required()
	
		if player_xp < required_xp:
			break
	
		player_xp -= required_xp
		player_level += 1
		stat_points += 5
		levels_gained += 1
	
		_add_combat_log(
			"Level up! You reached level %d and gained 5 stat points!"
			% player_level,
			"success"
		)
	
	if player_level >= max_level:
		player_xp = 0
	
	return levels_gained


func _calculate_gold_multiplier() -> float:
	var charisma = _get_total_stat("Charisma")

	var point_bonus = charisma * 0.01
	var milestone_bonus = floori(charisma / 10.0) * 0.05

	return 1.0 + point_bonus + milestone_bonus


func _gain_gold(amount):
	if amount <= 0:
		return

	var multiplier = _calculate_gold_multiplier()
	var final_amount = roundi(amount * multiplier)

	player_gold += final_amount
	wave_gold_earned += final_amount

	_add_combat_log(
		"+%d Gold! Total Gold: %d" % [final_amount, player_gold],
		"gold"
	)

func _has_armor_enchantment(enchantment_id: String) -> bool:
	for armor in equipped_armor.values():
		if enchantment_id in armor.get("enchantments", []):
			return true
	return false


func _roll_speed_demon() -> void:
	speed_demon_factor = 1.0
	if not _has_armor_enchantment("speed_demon"):
		return

	speed_demon_factor = 0.5 if randf() < 0.25 else 1.5
	var result = "50% less Agility" if speed_demon_factor < 1.0 else "50% more Agility"
	_add_combat_log("Speed Demon: %s this turn." % result, "warning")


func _on_player_damaged(previous_hp: int) -> void:
	if player_health <= 0 or player_health >= previous_hp:
		return

	if previous_hp * 5 >= player_max_health and player_health * 5 < player_max_health:
		if _has_armor_enchantment("virtuous"):
			virtuous_charged = true
			_add_combat_log("Virtuous: your next damaging attack deals double damage!", "success")

	if _has_armor_enchantment("thwart") and randf() < 0.25:
		_apply_player_status_effect("thwart", 1, 2, false)


func _healthy_damage_multiplier() -> float:
	return 1.2 if _has_armor_enchantment("healthy") else 1.0


func _thwart_resistance() -> float:
	return 0.25 if _get_status_turns(player_active_effects, "thwart") > 0 else 0.0


func _attack_enchantment_multiplier() -> float:
	var multiplier = 1.0

	if virtuous_active:
		multiplier *= 2.0
	elif virtuous_charged and _has_armor_enchantment("virtuous"):
		virtuous_charged = false
		virtuous_active = combat_state == "player_turn"
		multiplier *= 2.0

	if combat_state != "player_turn" or attack_original_duration <= 0.0:
		return multiplier

	var elapsed = attack_elapsed_time
	if chosen_attack == "barrage":
		elapsed = attack_original_duration - get_node("AttackTimer").time_left
	var progress = elapsed / attack_original_duration

	if progress <= 1.0 / 3.0 and _has_weapon_enchantment("quickdraw"):
		if chosen_attack != "barrage" or barrage_hits == 0:
			multiplier *= 1.2
	if progress >= 2.0 / 3.0 and _has_weapon_enchantment("hourglass"):
		multiplier *= 1.35

	return multiplier


func _try_clumsy_attack(slot_index: int) -> bool:
	if not _has_weapon_enchantment("clumsy"):
		return false

	if slot_index < 0 or active_enemies[slot_index] == null:
		slot_index = _get_leftmost_enemy_slot()
	if slot_index < 0:
		return false
	var enemy = active_enemies[slot_index]
	if enemy_database.get(enemy["id"], {}).get("is_boss", false):
		return false

	if randf() >= 0.25:
		_generate_enemy_loot(enemy["id"], slot_index)
		return false

	var dropped_weapon = equipped_weapon
	equipped_weapon = {}
	pending_loot.append(dropped_weapon)
	_spawn_ground_loot(dropped_weapon, slot_index)
	focus_damage_ready = false
	_add_combat_log("Curse of Clumsy: you dropped your weapon and missed!", "failure")
	return true

func _has_weapon_enchantment(enchantment_id: String) -> bool:
	return enchantment_id in equipped_weapon.get("enchantments", [])


func _apply_weapon_damage_enchantments(damage: float, target_hp: float) -> float:
	if _has_weapon_enchantment("champion") and player_health * 2 >= player_max_health:
		damage *= 1.2

	if _has_weapon_enchantment("greed"):
		var gold = floori(minf(damage, target_hp) * 0.20)
		if gold > 0:
			player_gold += gold
			wave_gold_earned += gold
			_add_combat_log("Curse of Greed: +%d Gold!" % gold, "gold")
		damage *= 0.8

	return damage


func _change_enchantment_hp(fraction: float) -> void:
	var amount = maxi(1, roundi(player_max_health * absf(fraction)))
	var old_health = player_health
	var change = amount if fraction > 0.0 else -amount
	if change < 0:
		change = -maxi(1, roundi(player_max_health * absf(fraction) * _healthy_damage_multiplier()))
	player_health = clampi(player_health + change, 0, player_max_health)

	if player_health < old_health:
		wave_flawless = false

	get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]


func _trigger_attack_enchantments(target: Dictionary) -> void:
	if player_health <= 0:
		return

	if _has_weapon_enchantment("omnivamp"):
		_change_enchantment_hp(0.01)

	if _has_weapon_enchantment("speculation"):
		_roll_speculation(target)


func _roll_speculation(target: Dictionary) -> void:
	var outcomes = [
		"Heal 2% max HP", "Lose 1% max HP",
		"Gain 2 posture", "Lose 2 posture",
		"Gain 10 gold", "Lose 10 gold",
		"Enemy Vulnerable (2 turns)", "Self Vulnerable (1 turn)",
		"Enemy Weakness (2 turns)", "Self Weakness (1 turn)"
	]
	var outcome = randi_range(0, outcomes.size() - 1)
	_add_combat_log("Curse of Speculation: %s" % outcomes[outcome], "warning")

	match outcome:
		0: _change_enchantment_hp(0.02)
		1: _change_enchantment_hp(-0.01)
		2, 3:
			if not guard_exhausted:
				var limit = _calculate_block_limit()
				var change = 2 if outcome == 2 else -2
				successful_blocks = clampi(successful_blocks + change, 0, limit)
				if successful_blocks == limit:
					successful_blocks = 0
					guard_exhausted = true
					guard_recovery_pending = true
				_update_guard_display()
		4:
			player_gold += 10
			wave_gold_earned += 10
		5:
			player_gold = maxi(0, player_gold - 10)
		6:
			if target["health"] > 0.0 or _has_weapon_enchantment("unwilling"):
				_apply_status_effect(target, "vulnerable", 2, 2)
		7: _apply_player_status_effect("vulnerable", 1, 1)
		8:
			if target["health"] > 0.0 or _has_weapon_enchantment("unwilling"):
				_apply_status_effect(target, "weakness", 2, 2)
		9: _apply_player_status_effect("weakness", 1, 1)

func _gain_overkill_gold(amount):
	if amount <= 0:
		return

	var multiplier = _calculate_gold_multiplier()
	var final_amount = roundi(amount * multiplier)

	player_gold += final_amount
	wave_gold_earned += final_amount

	_add_combat_log(
		"You gained %d gold from excess damage!" % final_amount,
		"gold"
	)


func _get_xp_display():
	if player_level >= max_level:
		return "Level %d (MAX)" % player_level
	
	return "Level %d | XP: %d/%d" % [
		player_level,
		player_xp,
		_calculate_xp_required()
	]



func _calculate_max_health() -> int:
	var fortitude = _get_total_stat("Fortitude")
	var milestone_bonus = floori(fortitude / 10.0) * 5

	var armor_health_bonus: int = 0

	for slot_name in equipped_armor:
		var armor: Dictionary = equipped_armor[slot_name]

		if armor.is_empty():
			continue

		armor_health_bonus += int(
			armor.get("bonus_health", 0)
		)

	return int(
		base_player_health
		+ fortitude
		+ milestone_bonus
		+ armor_health_bonus
	)




func _update_max_health() -> void:
	var old_max_health: int = player_max_health

	player_max_health = int(_calculate_max_health())

	var health_difference: int = (
		player_max_health - old_max_health
	)

	player_health = clampi(
		int(player_health) + health_difference,
		0,
		player_max_health
	)

	get_node("PlayerHP").text = "HP: %d/%d" % [
		player_health,
		player_max_health
	]


func _attempt_escape():
	if combat_state != "planning_phase" or boss_encounter:
		return

	var escape_chance = _calculate_escape_chance()
	var roll = randf()

	print("Agility: ", _get_total_stat("Agility"))
	print("Escape chance: ", escape_chance * 100, "%")
	print("Random roll: ", roll * 100, "%")

	if roll < escape_chance:
		_add_combat_log("You successfully escaped!", "success")

		# NEW: Abandon any uncollected ground loot when escaping.
		_clear_ground_loot()
		loot_continue_button.hide()

		_open_between_fights(true)

	else:
		_add_combat_log("You failed to escape!", "failure")

		for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
			get_node(button).hide()

		_begin_enemy_phase(1.0)


func _on_run_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
	
	selected_planning_option = 3
	_update_planning_selection()
	_confirm_planning_option()


func _on_bag_button_pressed() -> void:
	if bag_open:
		_close_bag()
		return

	# NEW: Allow Bag access while collecting loot after victory.
	if combat_state != "planning_phase" and combat_state != "loot_collection":
		return

	if combat_state == "planning_phase":
		selected_planning_option = 1
		_update_planning_selection()

	_open_bag()


func _open_bag() -> void:
	if bag_open or combat_state not in ["planning_phase", "loot_collection", "shop"]:
		return

	bag_open = true
	if combat_state == "shop":
		shop_backdrop.hide()
	saved_combat_visibility.clear()

	for child in get_children():
		if child is CanvasItem and child.name != "BagPanel" and child != mana_bar:
			saved_combat_visibility[child.name] = child.visible
			child.hide()

	_refresh_bag_grid()
	_refresh_equipped_item_details()
	var bag_panel = get_node("BagPanel")
	var close_button = bag_panel.get_node("BagCloseButton") as Button
	bag_panel.move_child(close_button, -1)
	bag_panel.show()


func _close_bag() -> void:
	if not bag_open:
		return
	
	get_node("BagPanel").hide()
	_clear_bag_selection()
	
	for node_name in saved_combat_visibility:
		var node = get_node_or_null(NodePath(str(node_name)))
	
		if node is CanvasItem:
			node.visible = saved_combat_visibility[node_name]
	
	saved_combat_visibility.clear()
	bag_open = false
	_set_mana(player_mana)
	if combat_state == "shop":
		shop_backdrop.show()

func _on_bag_sort_selected(index: int) -> void:
	bag_sort_mode = index
	_refresh_bag_grid()
	get_node("BagPanel/BagScroll").scroll_vertical = 0


func _get_bag_item_subtype(item: Dictionary) -> int:
	match str(item.get("item_type", "")):
		"armor":
			var slots = ["head", "chest", "legs", "boots", "cape", "accessory"]
			var slot = str(item.get("armor_slot", ""))
			var slot_index = slots.find(slot)
			return slot_index if slot_index >= 0 else slots.size()

		"weapon":
			var magic_type = str(item.get("magic_school", ""))
			var magic_index = MAGIC_ELEMENTS.keys().find(magic_type)
			if magic_index >= 0:
				return 3 + magic_index

			var weight_classes = ["Light", "Medium", "Heavy"]
			var weight_index = weight_classes.find(item.get("weapon", ""))
			return weight_index if weight_index >= 0 else 3 + MAGIC_ELEMENTS.size()

	return 0


func _get_sorted_bag_items() -> Array[Dictionary]:
	var items = inventory.duplicate()
	var rarity_order = rarity_weights.keys()

	items.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var a_favorite = bool(a.get("favorite", false))
		var b_favorite = bool(b.get("favorite", false))
		if a_favorite != b_favorite:
			return a_favorite

		match bag_sort_mode:
			0:
				var a_pickup = int(a.get("pickup_order", 0))
				var b_pickup = int(b.get("pickup_order", 0))
				if a_pickup != b_pickup:
					return a_pickup > b_pickup

			2:
				var a_type = str(a.get("item_type", ""))
				var b_type = str(b.get("item_type", ""))
				if a_type != b_type:
					return a_type < b_type

				if a_type == "weapon":
					var family_order = str(a.get("weapon_type", "")).nocasecmp_to(
						str(b.get("weapon_type", ""))
					)
					if family_order != 0:
						return family_order < 0

				var a_subtype = _get_bag_item_subtype(a)
				var b_subtype = _get_bag_item_subtype(b)
				if a_subtype != b_subtype:
					return a_subtype < b_subtype

			3:
				var a_rarity = rarity_order.find(a.get("rarity", ""))
				var b_rarity = rarity_order.find(b.get("rarity", ""))
				if a_rarity != b_rarity:
					return a_rarity > b_rarity

		if bag_sort_mode != 0:
			var name_order = str(a.get("name", "")).nocasecmp_to(str(b.get("name", "")))
			if name_order != 0:
				return name_order < 0

		return int(a["instance_id"]) < int(b["instance_id"])
	)
	return items

func _refresh_bag_grid() -> void:
	var grid = get_node("BagPanel/BagScroll/BagGrid")

	for child in grid.get_children():
		grid.remove_child(child)
		child.queue_free()

	var sorted_items = _get_sorted_bag_items()
	var visible_slots = maxi(_get_inventory_capacity(), sorted_items.size())
	for i in range(visible_slots):
		var slot = Button.new()
		slot.custom_minimum_size = Vector2(72, 76)
		slot.focus_mode = Control.FOCUS_NONE
		slot.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

		var slot_style = StyleBoxFlat.new()
		slot_style.bg_color = Color("#080808")
		slot_style.border_color = Color("#343434")
		slot_style.set_border_width_all(1)
		slot_style.set_corner_radius_all(5)

		slot.add_theme_stylebox_override("normal", slot_style)
		slot.add_theme_stylebox_override("hover", slot_style)
		slot.add_theme_stylebox_override("pressed", slot_style)

		if i < sorted_items.size():
			var item = sorted_items[i]
			if not item.get("enchantments", []).is_empty():
				slot_style.bg_color = ENCHANTED_SLOT_COLOR

			if bool(item.get("favorite", false)):
				slot_style.border_color = Color("#E5C35B")
				slot_style.set_border_width_all(2)

			slot.pressed.connect(
				_on_bag_slot_pressed.bind(item["instance_id"])
			)

			if item.get("item_type") in ["weapon", "armor"]:
				slot.gui_input.connect(_on_bag_gear_right_clicked.bind(slot, int(item["instance_id"])))

			slot.tooltip_text = str(item.get("name", "Unknown Item"))

			var icon_path = item.get("icon", "")

			if icon_path != "" and ResourceLoader.exists(icon_path):
				var texture = load(icon_path)

				if texture is Texture2D:
					slot.icon = texture
					slot.expand_icon = true

			elif item.get("item_type") == "consumable":
				slot.text = "P"

			var quantity = int(item.get("quantity", 1))

			if quantity > 1:
				var count_label = Label.new()
				count_label.text = str(quantity)
				count_label.position = Vector2(49, 2)
				count_label.size = Vector2(20, 20)
				count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
				count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

				count_label.add_theme_color_override(
					"font_color",
					Color.WHITE
				)

				count_label.add_theme_color_override(
					"font_shadow_color",
					Color.BLACK
				)

				count_label.add_theme_constant_override(
					"shadow_offset_x",
					1
				)

				count_label.add_theme_constant_override(
					"shadow_offset_y",
					1
				)

				count_label.add_theme_font_size_override(
					"font_size",
					16
				)

				slot.add_child(count_label)

		grid.add_child(slot)


func _on_bag_close_button_pressed() -> void:
	_close_bag()


func _setup_bag_item_details() -> void:
	var bag_panel = get_node("BagPanel")
	var sort_menu = OptionButton.new()
	sort_menu.position = Vector2(380, 50)
	sort_menu.custom_minimum_size = Vector2(185, 32)
	sort_menu.add_item("Sort: Recent")
	sort_menu.add_item("Sort: Name")
	sort_menu.add_item("Sort: Item type")
	sort_menu.add_item("Sort: Rarity")
	sort_menu.select(bag_sort_mode)
	sort_menu.item_selected.connect(_on_bag_sort_selected)
	bag_panel.add_child(sort_menu)
	_setup_spellbook(bag_panel)
	_setup_passive_inventory(bag_panel)
	var details = PanelContainer.new()
	details.name = "ItemDetails"
	var bag_scroll = bag_panel.get_node("BagScroll") as ScrollContainer
	var close_button = bag_panel.get_node("BagCloseButton") as Button
	var panel_top = bag_scroll.position.y
	var panel_height = close_button.position.y - panel_top - 24.0
	details.position = Vector2(850, panel_top)
	details.size = Vector2(360, panel_height)
	details.hide()
	bag_panel.add_child(details)
	
	var layout = VBoxContainer.new()
	layout.name = "VBoxContainer"
	layout.add_theme_constant_override("separation", 10)
	details.add_child(layout)
	
	var info_scroll = ScrollContainer.new()
	info_scroll.name = "InfoScroll"
	info_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	info_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	info_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	layout.add_child(info_scroll)

	var info = Label.new()
	info.name = "ItemInfo"
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info_scroll.add_child(info)

	var equip_button = Button.new()
	equip_button.name = "EquipButton"
	equip_button.text = "Equip"
	equip_button.pressed.connect(_on_bag_equip_pressed)
	layout.add_child(equip_button)
	
	var favorite_button = Button.new()
	favorite_button.name = "FavoriteButton"
	favorite_button.pressed.connect(_on_bag_favorite_pressed)
	layout.add_child(favorite_button)

	var discard_button = Button.new()
	discard_button.name = "DiscardButton"
	discard_button.text = "Discard"
	discard_button.pressed.connect(_on_bag_discard_pressed)
	layout.add_child(discard_button)

func _on_bag_gear_right_clicked(event: InputEvent, slot: Button, instance_id: int) -> void:
	if not bag_open or active_enchant_material_id != -1:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		slot.accept_event()
		selected_bag_item_id = instance_id
		_on_bag_equip_pressed()

func _setup_equipped_item_details() -> void:
	var bag_panel = get_node("BagPanel")

	var details = PanelContainer.new()
	details.name = "EquippedDetails"
	details.position = Vector2(30, 90)
	details.custom_minimum_size = Vector2(310, 570)
	details.size = Vector2(310, 570)
	bag_panel.add_child(details)

	var layout = Control.new()
	layout.name = "EquipmentLayout"
	layout.custom_minimum_size = Vector2(310, 570)
	details.add_child(layout)

	var title = Label.new()
	title.text = "EQUIPPED ARMOR"
	title.position = Vector2(70, 5)
	title.size = Vector2(170, 25)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 17)
	layout.add_child(title)

	var slot_positions = {
		"head": Vector2(123, 42),
		"chest": Vector2(123, 118),
		"legs": Vector2(123, 194),
		"boots": Vector2(123, 270),
		"cape": Vector2(210, 118),
		"accessory_1": Vector2(8, 360),
		"accessory_2": Vector2(82, 360),
		"accessory_3": Vector2(156, 360),
		"accessory_4": Vector2(230, 360)
	}

	for slot_name in slot_positions:
		var button = Button.new()
		button.name = "Slot_" + slot_name
		button.position = slot_positions[slot_name]
		button.size = Vector2(64, 64)
		button.custom_minimum_size = Vector2(64, 64)
		button.focus_mode = Control.FOCUS_NONE
		button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		button.expand_icon = true

		var style = StyleBoxFlat.new()
		style.bg_color = Color("#080808")
		style.border_color = Color("#343434")
		style.set_border_width_all(1)
		style.set_corner_radius_all(5)

		var hover_style = style.duplicate()
		hover_style.border_color = Color("#C0A86B")

		button.add_theme_stylebox_override("normal", style)
		button.add_theme_stylebox_override("hover", hover_style)
		button.add_theme_stylebox_override("pressed", hover_style)

		button.button_mask = MOUSE_BUTTON_MASK_LEFT | MOUSE_BUTTON_MASK_RIGHT

		button.pressed.connect(
			_on_equipment_slot_pressed.bind(slot_name)
		)

		layout.add_child(button)


	var weapon_button = Button.new()
	weapon_button.name = "EquippedWeaponSlot"
	weapon_button.position = Vector2(36, 118)
	weapon_button.size = Vector2(64, 64)
	weapon_button.custom_minimum_size = Vector2(64, 64)
	weapon_button.focus_mode = Control.FOCUS_NONE
	weapon_button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	weapon_button.expand_icon = true

	var weapon_style = StyleBoxFlat.new()
	weapon_style.bg_color = Color("#080808")
	weapon_style.border_color = Color("#343434")
	weapon_style.set_border_width_all(1)
	weapon_style.set_corner_radius_all(5)

	var weapon_hover_style = weapon_style.duplicate()
	weapon_hover_style.border_color = Color("#C0A86B")

	weapon_button.add_theme_stylebox_override("normal", weapon_style)
	weapon_button.add_theme_stylebox_override("hover", weapon_hover_style)
	weapon_button.add_theme_stylebox_override("pressed", weapon_hover_style)

	weapon_button.button_mask = MOUSE_BUTTON_MASK_RIGHT
	weapon_button.pressed.connect(_on_equipment_slot_pressed.bind("weapon"))

	layout.add_child(weapon_button)


	_refresh_equipped_item_details()




func _refresh_equipped_item_details() -> void:
	var details = get_node_or_null("BagPanel/EquippedDetails")

	if details == null:
		return

	var layout = details.get_node("EquipmentLayout")

	var slot_labels = {
		"head": "HEAD",
		"chest": "CHEST",
		"legs": "LEGS",
		"boots": "BOOTS",
		"cape": "CAPE",
		"accessory_1": "ACC 1",
		"accessory_2": "ACC 2",
		"accessory_3": "ACC 3",
		"accessory_4": "ACC 4"
	}

	for slot_name in equipped_armor:
		var button = layout.get_node_or_null(
			"Slot_" + slot_name
		) as Button

		if button == null:
			continue

		var item = equipped_armor[slot_name]

		button.icon = null
		button.text = ""
		button.disabled = false
		button.tooltip_text = ""
		button.set_meta("equipped_tooltip", "")
		var enchanted_armor = not item.get("enchantments", []).is_empty()
		for style_name in ["normal", "hover", "pressed"]:
			var style = button.get_theme_stylebox(style_name) as StyleBoxFlat
			style.bg_color = ENCHANTED_SLOT_COLOR if enchanted_armor else Color("#080808")

		if item.is_empty():
			button.text = slot_labels.get(
				slot_name,
				slot_name.to_upper()
			)

			button.tooltip_text = (
				"%s: Empty" % slot_labels.get(slot_name, slot_name)
			)

			button.add_theme_font_size_override("font_size", 10)
			button.add_theme_color_override(
				"font_color",
				Color("#888888")
			)

			continue

		button.set_meta(
			"equipped_tooltip",
			_format_item_tooltip(item) + "\n\nClick to unequip"
		)

		var icon_path = str(item.get("icon", ""))

		if icon_path != "" and ResourceLoader.exists(icon_path):
			var texture = load(icon_path)

			if texture is Texture2D:
				button.icon = texture
				button.expand_icon = true

		if button.icon == null:
			button.text = str(item.get("name", "?")).substr(0, 3).to_upper()


	var weapon_button = layout.get_node(
		"EquippedWeaponSlot"
	) as Button

	weapon_button.icon = null
	weapon_button.text = ""
	weapon_button.tooltip_text = ""
	weapon_button.set_meta("equipped_tooltip", "")

	var enchanted = not equipped_weapon.get("enchantments", []).is_empty()
	for style_name in ["normal", "hover", "pressed"]:
		var style = weapon_button.get_theme_stylebox(style_name) as StyleBoxFlat
		style.bg_color = ENCHANTED_SLOT_COLOR if enchanted else Color("#080808")

	if equipped_weapon.is_empty():
		weapon_button.text = "WEAPON"
		weapon_button.tooltip_text = "Weapon: Empty"
		weapon_button.add_theme_font_size_override("font_size", 10)
	else:
		weapon_button.set_meta("equipped_tooltip", _format_item_tooltip(equipped_weapon, true))

		var icon_path = str(
			equipped_weapon.get("icon", "")
		)

		if icon_path != "" and ResourceLoader.exists(icon_path):
			var texture = load(icon_path)

			if texture is Texture2D:
				weapon_button.icon = texture
				weapon_button.expand_icon = true

		if weapon_button.icon == null:
			weapon_button.text = str(
				equipped_weapon.get("name", "Weapon")
			).substr(0, 3).to_upper()




func _on_bag_slot_pressed(instance_id: int) -> void:
	selected_bag_item_id = instance_id

	for item in inventory:
		if item["instance_id"] != instance_id:
			continue

		var details = get_node("BagPanel/ItemDetails")
		var info_scroll = details.get_node("VBoxContainer/InfoScroll") as ScrollContainer
		var info = info_scroll.get_node("ItemInfo") as Label
		var equip_button = details.get_node("VBoxContainer/EquipButton") as Button

		var favorite_button = details.get_node("VBoxContainer/FavoriteButton") as Button
		var discard_button = details.get_node("VBoxContainer/DiscardButton") as Button
		var can_dispose = _can_dispose_item(item)
		favorite_button.text = "Favorite" if can_dispose else "Unfavorite"
		discard_button.disabled = not can_dispose
		discard_button.text = "Discard"
		if combat_state == "shop" and active_enchant_material_id == -1:
			discard_button.text = "Sell for %d gold" % _get_shop_sell_price(item)

		info.text = _format_item_tooltip(item)

		equip_button.text = "Equip"
		equip_button.disabled = false

		favorite_button.show()
		discard_button.show()

		if active_enchant_material_id != -1:
			var enchant_item = _find_bag_item(active_enchant_material_id)
			var target_type = str(enchant_item.get("enchant_target", ""))
			info.text += "\n\nUsing: %s\nChoose unenchanted %s from your Bag." % [
				enchant_item.get("name", "Enchant Material"),
				"armor" if target_type == "armor" else "weapon gear"
			]
			equip_button.text = "Apply"
			equip_button.disabled = not _can_apply_enchant_material(enchant_item, item)
			equip_button.show()
			favorite_button.text = "Cancel"
			discard_button.hide()
		elif item.get("item_type") == "enchant_material":
			equip_button.text = "Use"
			equip_button.show()
		elif item.get("item_type") == "slime_dna":
			equip_button.text = "Fuse"
			equip_button.disabled = slime_dna_fused
			equip_button.show()
		elif item.get("item_type") == "scroll":
			var spell_id = str(item["spell_id"])
			var already_learned = learned_spell_codes.has(spell_id)
			equip_button.text = "Already learned" if already_learned else "Use Scroll"
			equip_button.disabled = already_learned or not _meets_scroll_requirement(spell_id)
			equip_button.show()
		elif item.get("item_type") == "consumable":
			var commands = item.get("commands", [])

			if not item.get("description", "").is_empty():
				info.text += "\n\n" + item.get("description", "")

			if not commands.is_empty():
				info.text += "\n\nType to use:"

				for command in commands:
					info.text += "\n- %s" % command

			equip_button.hide()
		else:
			equip_button.show()

		details.show()
		info_scroll.scroll_vertical = 0
		return



func _on_bag_equip_pressed() -> void:
	if selected_bag_item_id == -1:
		return

	var selected_item: Dictionary = {}

	for item in inventory:
		if int(item.get("instance_id", -1)) == selected_bag_item_id:
			selected_item = item
			break

	if selected_item.is_empty():
		return

	if active_enchant_material_id != -1:
		_apply_enchant_material(selected_item)
		return

	if selected_item.get("item_type") == "enchant_material":
		active_enchant_material_id = selected_bag_item_id
		_on_bag_slot_pressed(selected_bag_item_id)
		return

	if selected_item.get("item_type") == "slime_dna":
		_fuse_slime_dna(selected_item)
		return

	if selected_item.get("item_type") == "scroll":
		_use_spell_scroll(selected_item)
		return

	var equipped_successfully = false

	match str(selected_item.get("item_type", "")):
		"weapon":
			equipped_successfully = _equip_weapon_from_inventory(
				selected_bag_item_id
			)

		"armor":
			equipped_successfully = _equip_armor_from_inventory(
				selected_bag_item_id
			)

	if equipped_successfully:
		_refresh_bag_grid()
		_refresh_equipped_item_details()
		_clear_bag_selection()

func _meets_scroll_requirement(spell_id: String) -> bool:
	var spell: Dictionary = spells[spell_id]
	return int(player_stats.get(spell["magic_type"], 0)) >= int(spell["required_investment"])


func _use_spell_scroll(item: Dictionary) -> void:
	var spell_id = str(item["spell_id"])
	if learned_spell_codes.has(spell_id) or not _meets_scroll_requirement(spell_id):
		return

	_learn_spell(spell_id)
	if not learned_spell_codes.has(spell_id):
		return

	inventory.erase(item)
	_refresh_bag_grid()
	_clear_bag_selection()
	_open_spellbook()

func _get_material_enchantment_pool(enchant_item: Dictionary) -> Dictionary:
	match enchant_item.get("enchant_target", ""):
		"weapon":
			return ItemData.WEAPON_ENCHANTMENTS
		"armor":
			return ItemData.ARMOR_ENCHANTMENTS
	return {}


func _find_bag_item(instance_id: int) -> Dictionary:
	for item in inventory:
		if item["instance_id"] == instance_id:
			return item
	return {}

func _get_material_enchantments(item: Dictionary) -> Array:
	if item.has("material_enchantments"):
		return item["material_enchantments"]

	var legacy_id := str(item.get("enchantment_id", ""))
	return [] if legacy_id.is_empty() else [legacy_id]

func _can_apply_enchant_material(enchant_item: Dictionary, target: Dictionary) -> bool:
	if enchant_item.is_empty() or target.is_empty():
		return false
	if target.get("item_type") != enchant_item.get("enchant_target"):
		return false
	if not target.get("enchantments", []).is_empty():
		return false

	var is_accessory = str(target.get("armor_slot", "")).begins_with("accessory")
	if is_accessory and not target.get("allow_enchantments", false):
		return false

	var pool := _get_material_enchantment_pool(enchant_item)
	var enchantment_ids := _get_material_enchantments(enchant_item)
	if enchantment_ids.is_empty():
		return false
	for enchantment_id in enchantment_ids:
		if not pool.has(enchantment_id):
			return false
	return true


func _apply_enchant_material(target: Dictionary) -> void:
	var enchant_item = _find_bag_item(active_enchant_material_id)
	if not _can_apply_enchant_material(enchant_item, target):
		return

	target["enchantments"] = _get_material_enchantments(enchant_item).duplicate()
	inventory.erase(enchant_item)
	active_enchant_material_id = -1
	_refresh_bag_grid()
	_on_bag_slot_pressed(int(target["instance_id"]))

func _on_bag_favorite_pressed() -> void:
	if active_enchant_material_id != -1:
		var material_id = active_enchant_material_id
		active_enchant_material_id = -1
		_on_bag_slot_pressed(material_id)
		return
	for item in inventory:
		if item["instance_id"] != selected_bag_item_id:
			continue

		item["favorite"] = not bool(item.get("favorite", false))
		_refresh_bag_grid()
		get_node("BagPanel/BagScroll").scroll_vertical = 0
		_on_bag_slot_pressed(selected_bag_item_id)
		return

func _on_bag_discard_pressed() -> void:
	if active_enchant_material_id != -1 or selected_bag_item_id == -1:
		return

	if combat_state == "shop":
		_sell_selected_bag_item()
		return

	if _discard_inventory_item(selected_bag_item_id):
		_refresh_bag_grid()
		_clear_bag_selection()


func _sell_selected_bag_item() -> void:
	var item := _find_bag_item(selected_bag_item_id)
	if item.is_empty() or not _can_dispose_item(item):
		return

	var price := _get_shop_sell_price(item)
	var quantity := int(item.get("quantity", 1))

	if quantity > 1:
		item["quantity"] = quantity - 1
	else:
		_remove_item_from_inventory(selected_bag_item_id)

	player_gold += price
	shop_gold_label.text = "Gold: %d" % player_gold
	_refresh_bag_grid()

	if quantity > 1:
		_on_bag_slot_pressed(selected_bag_item_id)
	else:
		_clear_bag_selection()


func _clear_bag_selection() -> void:
	active_enchant_material_id = -1
	selected_bag_item_id = -1
	get_node("BagPanel/ItemDetails").hide()


func _on_book_button_pressed() -> void:
	if combat_state != "planning_phase":
		return
	
	selected_planning_option = 2
	_update_planning_selection()
	_confirm_planning_option()


func _on_attack_button_mouse_entered() -> void:
	selected_planning_option = 0
	_update_planning_selection()


func _on_bag_button_mouse_entered() -> void:
	selected_planning_option = 1
	_update_planning_selection()


func _on_book_button_mouse_entered() -> void:
	selected_planning_option = 2
	_update_planning_selection()


func _on_run_button_mouse_entered() -> void:
	selected_planning_option = 3
	_update_planning_selection()



func _get_total_stat(stat_name):
	var total = int(player_stats.get(stat_name, 0))
	total += int(racial_stats.get(stat_name, 0))

	for slot_name in equipped_armor:
		var armor = equipped_armor[slot_name]

		if armor.is_empty():
			continue

		var bonuses = armor.get("stat_bonuses", {})
		total += int(bonuses.get(stat_name, 0))

	total = clampi(total, 0, max_stat_value)

	if stat_name == "Agility":
		var speed_bonus = float(equipped_weapon.get("attack_speed", 0.0))

		for item in equipped_armor.values():
			speed_bonus += float(item.get("attack_speed", 0.0))

		var curse_active = combat_state not in ["loot_collection", "between_fights", "shop", "game_over"] and _has_armor_enchantment("speed_demon")
		var curse_factor = speed_demon_factor if curse_active else 1.0
		return float(total) * maxf(0.0, 1.0 + speed_bonus) * curse_factor

	return total

func _get_gear_bonus(bonus_name: String) -> int:
	var total = 0
	for gear in equipped_armor.values():
		total += int(gear.get(bonus_name, 0))
	return total


func _get_player_magic_resistance(damage_type: String) -> float:
	var invested_intelligence := int(player_stats.get("Intelligence", 0))
	var total := _thwart_resistance() + floori(invested_intelligence / 10.0) * 0.01
	for gear in equipped_armor.values():
		var resistances: Dictionary = gear.get("resistances", {})
		total += float(resistances.get("Elemental", 0.0))
		if damage_type != "Elemental":
			total += float(resistances.get(damage_type, 0.0))
	return clampf(total, 0.0, 0.75)

func _get_player_physical_resistance() -> float:
	var fortitude = _get_total_stat("Fortitude")
	var total_resistance = floori(fortitude / 10.0) * 0.01 + _thwart_resistance()

	for slot_name in equipped_armor:
		var armor = equipped_armor[slot_name]

		if armor.is_empty():
			continue

		var resistances = armor.get("resistances", {})
		total_resistance += float(
			resistances.get("Physical", 0.0)
		)

	return clampf(total_resistance, 0.0, 0.75)

func _get_strength_penetration() -> float:
	var strength = _get_total_stat("Strength")
	return floori(strength / 5.0) * 0.0125


func _apply_resistance(
	damage: float,
	resistance: float,
	penetration: float
) -> float:
	var effective_penetration = clampf(penetration, 0.0, 1.0)
	var effective_resistance = resistance * (1.0 - effective_penetration)
	
	return damage * (1.0 - effective_resistance)


func _create_armor_instance(armor_id: String) -> Dictionary:
	if not armor_database.has(armor_id):
		push_error("Unknown armor: " + armor_id)
		return {}

	var armor = armor_database[armor_id].duplicate(true)

	armor["template_id"] = armor_id
	armor["instance_id"] = next_item_instance_id
	next_item_instance_id += 1

	# Roll a whole-number HP bonus.
	var min_health = maxi(1, int(armor.get("health_min", 1)))
	var max_health = maxi(
		min_health,
		int(armor.get("health_max", min_health))
	)

	armor["bonus_health"] = randi_range(
		min_health,
		max_health
	)

	# Roll randomized stat bonuses once when armor is created.
	var rolled_stat_bonuses = armor.get(
		"stat_bonuses", {}
	).duplicate(true)

	for stat_name in armor.get("stat_bonus_ranges", {}):
		var stat_range = armor["stat_bonus_ranges"][stat_name]

		var min_bonus = int(stat_range.get("min", 0))
		var max_bonus = int(stat_range.get("max", min_bonus))

		rolled_stat_bonuses[stat_name] = randi_range(
			min_bonus,
			maxi(min_bonus, max_bonus)
		)

	armor["stat_bonuses"] = rolled_stat_bonuses

	# Roll each resistance independently.
	var rolled_resistances = armor.get(
		"resistances", {}
	).duplicate(true)

	for resistance_name in armor.get("resistance_ranges", {}):
		var resistance_range = armor["resistance_ranges"][resistance_name]

		var min_percent = int(resistance_range.get("min", 0))
		var max_percent = int(resistance_range.get("max", min_percent))

		var rolled_percent = randi_range(
			min_percent,
			maxi(min_percent, max_percent)
		)

		rolled_resistances[resistance_name] = (
			float(rolled_percent) / 100.0
		)

	armor["resistances"] = rolled_resistances

	for bonus_name in armor.get("gear_bonus_ranges", {}):
		var bounds: Array = armor["gear_bonus_ranges"][bonus_name]
		armor[bonus_name] = randi_range(int(bounds[0]), int(bounds[1]))

	if armor.has("speed_percent"):
		armor["attack_speed"] = float(armor["speed_percent"]) / 100.0
		armor.erase("speed_percent")

	armor.erase("gear_bonus_ranges")

	# Remove template-only values from the final item.
	armor.erase("health_min")
	armor.erase("health_max")
	armor.erase("resistance_ranges")
	armor.erase("stat_bonus_ranges")

	return armor


func _create_weapon_instance(weapon_id: String) -> Dictionary:
	if not weapon_database.has(weapon_id):
		push_error("Unknown weapon: " + weapon_id)
		return {}
	
	var weapon = weapon_database[weapon_id].duplicate(true)
	
	weapon["template_id"] = weapon_id
	weapon["instance_id"] = next_item_instance_id
	next_item_instance_id += 1
	
	weapon["base_damage"] = (
		randi_range(
			roundi(weapon["base_damage_min"] * 10),
			roundi(weapon["base_damage_max"] * 10)
		) / 10.0
	)
	
	weapon["penetration"] = randf_range(
		weapon["penetration_min"],
		weapon["penetration_max"]
	)
	
	weapon.erase("base_damage_min")
	weapon.erase("base_damage_max")
	weapon.erase("penetration_min")
	weapon.erase("penetration_max")
	
	return weapon



func _roll_enchantments(pool: Dictionary, limit: int = 5, guaranteed_first: bool = false) -> Array:
	var available = pool.keys()
	var rolled: Array = []

	while rolled.size() < limit and not available.is_empty():
		if not (guaranteed_first and rolled.is_empty()) and randf() >= 0.10:
			break
		var index = randi_range(0, available.size() - 1)
		rolled.append(available.pop_at(index))

	return rolled


func _create_item_instance(item_id: String, roll_enchantment: bool = false) -> Dictionary:
	if weapon_database.has(item_id):
		var weapon = _create_weapon_instance(item_id)
		if roll_enchantment:
			weapon["enchantments"] = _roll_enchantments(ItemData.WEAPON_ENCHANTMENTS)
		return weapon

	if consumable_database.has(item_id):
		var item = consumable_database[item_id].duplicate(true)
		if item_id in ["slime_dna", "slime_brain"]:
			print(item_id, " icon: ", item.get("icon", ""))

		item["template_id"] = item_id
		item["instance_id"] = next_item_instance_id
		item["quantity"] = 1
		if item.get("item_type") == "enchant_material":
			var pool = _get_material_enchantment_pool(item)
			item["material_enchantments"] = _roll_enchantments(pool, 5, true)

		next_item_instance_id += 1

		return item


	if armor_database.has(item_id):
		var armor = _create_armor_instance(item_id)
		var is_accessory = str(armor.get("armor_slot", "")).begins_with("accessory")
		if roll_enchantment and (not is_accessory or armor.get("allow_enchantments", false)):
			armor["enchantments"] = _roll_enchantments(ItemData.ARMOR_ENCHANTMENTS)
		return armor


	push_error("Unknown item: " + item_id)
	return {}


func _get_equipped_weapon() -> Dictionary:
	if equipped_weapon.is_empty():
		return {
			"base_damage": 5.0,
			"scalings": {"Strength": 1.0},
			"damage_types": ["Blunt"],
			"magic_damage": {}
		}
	return equipped_weapon


func _get_inventory_capacity() -> int:
	var strength = _get_total_stat("Strength")
	return base_inventory_capacity + floori(strength / 2.0)


func _add_item_to_inventory(item: Dictionary) -> bool:
	if item.is_empty():
		return false

	var max_stack = int(item.get("max_stack", 1))

	if max_stack > 1:
		for existing_item in inventory:
			if existing_item.get("template_id") != item.get("template_id"):
				continue

			var current_quantity = int(existing_item.get("quantity", 1))

			if current_quantity < max_stack:
				existing_item["quantity"] = current_quantity + 1
				existing_item["pickup_order"] = next_pickup_order
				next_pickup_order += 1

				print(
					"Stacked %s: %d/%d"
					% [
						item["name"],
						existing_item["quantity"],
						max_stack
					]
				)

				return true

	if inventory.size() >= _get_inventory_capacity():
		print("Your bag is full!")
		return false

	item["pickup_order"] = next_pickup_order
	next_pickup_order += 1
	inventory.append(item)
	print("Added to bag: ", item["name"])
	return true


func _remove_item_from_inventory(instance_id: int) -> Dictionary:
	for i in range(inventory.size()):
		if inventory[i]["instance_id"] == instance_id:
			return inventory.pop_at(i)
	
	return {}


func _can_dispose_item(item: Dictionary) -> bool:
	return not bool(item.get("favorite", false))


func _discard_inventory_item(instance_id: int) -> bool:
	for item in inventory:
		if item["instance_id"] != instance_id:
			continue

		if not _can_dispose_item(item):
			return false

		_remove_item_from_inventory(instance_id)
		print("Discarded: ", item["name"])
		return true

	return false


func _equip_armor_from_inventory(instance_id: int) -> bool:
	var item_index = -1

	for i in range(inventory.size()):
		if int(inventory[i].get("instance_id", -1)) == instance_id:
			item_index = i
			break

	if item_index == -1:
		return false

	var new_armor = inventory[item_index]

	if new_armor.get("item_type", "") != "armor":
		return false

	var target_slot = str(new_armor.get("armor_slot", ""))

	if target_slot == "accessory":
		target_slot = ""

		for slot_number in range(1, 5):
			var accessory_slot = "accessory_%d" % slot_number

			if equipped_armor[accessory_slot].is_empty():
				target_slot = accessory_slot
				break

		if target_slot == "":
			_add_combat_log(
				"All accessory slots are full. Unequip one first.",
				"warning"
			)
			return false

	if not equipped_armor.has(target_slot):
		push_warning("Unknown armor slot: " + target_slot)
		return false

	var old_armor = equipped_armor[target_slot]

	inventory.remove_at(item_index)

	if not old_armor.is_empty():
		inventory.append(old_armor)

	equipped_armor[target_slot] = new_armor


	_update_max_health()
	_refresh_stat_display()

	_add_combat_log(
		"Equipped %s!" % new_armor["name"],
		"success"
	)

	return true


func _on_equipment_slot_pressed(slot_name: String) -> void:
	if not bag_open or active_enchant_material_id != -1:
		return

	var item: Dictionary = equipped_weapon if slot_name == "weapon" else equipped_armor.get(slot_name, {})
	if item.is_empty():
		return

	if inventory.size() >= _get_inventory_capacity():
		_add_combat_log("Your bag is full. Cannot unequip %s!" % item["name"], "warning")
		return

	inventory.append(item)
	if slot_name == "weapon":
		equipped_weapon = {}
	else:
		equipped_armor[slot_name] = {}

	_update_max_health()
	_refresh_stat_display()
	_refresh_bag_grid()
	_refresh_equipped_item_details()
	_clear_bag_selection()
	_add_combat_log("Unequipped %s!" % item["name"], "success")


func _equip_weapon_from_inventory(instance_id: int) -> bool:
	var item_index = -1

	for i in range(inventory.size()):
		if inventory[i]["instance_id"] == instance_id:
			item_index = i
			break

	if item_index == -1:
		return false

	var new_weapon = inventory[item_index]

	if new_weapon.get("item_type", "weapon") != "weapon":
		return false

	var requirements: Dictionary = new_weapon.get("requirements", {})
	for stat_name in requirements:
		if _get_total_stat(stat_name) < int(requirements[stat_name]):
			_add_combat_log("Requires %d %s to equip." % [requirements[stat_name], stat_name], "warning")
			return false

	var old_weapon = equipped_weapon

	inventory.remove_at(item_index)

	if not old_weapon.is_empty():
		inventory.append(old_weapon)

	equipped_weapon = new_weapon

	print("Equipped: ", equipped_weapon["name"])
	print("Base damage: ", equipped_weapon["base_damage"])

	return true



func _get_weapon_penetration() -> float:
	var weapon = _get_equipped_weapon()
	var weapon_penetration = weapon.get("penetration", 0.0)
	var strength_penetration = _get_strength_penetration()

	return clampf(
		weapon_penetration + strength_penetration,
		0.0,
		1.0
	)


func _calculate_damage_against_enemy(
	enemy: Dictionary,
	physical_damage: float,
	damage_type_override: String = "",
	ignore_resistance: bool = false
) -> float:
	var weapon = _get_equipped_weapon()
	var resistances = enemy.get("resistances", {})
	var penetration = _get_weapon_penetration()
	if ignore_resistance:
		penetration = 1.0
	var total_damage = 0.0
	
	var damage_types: Array = weapon.get("damage_types", [])
	var damage_type = "" if damage_types.is_empty() else str(damage_types[0])
	
	if damage_type_override != "":
		damage_type = damage_type_override
	
	var physical_resistance = (
		resistances.get("Physical", 0.0)
		+ resistances.get(damage_type, 0.0)
	)
	
	for effect_id in ["corrosion", "decay"]:
		var stacks = _get_status_turns(
			enemy.get("active_effects", []),
			effect_id
		)

		var resistance_penalty = float(
			status_effect_database[effect_id]["physical_resistance_modifier"]
		)

		physical_resistance += stacks * resistance_penalty
	
	var element_key = str(MAGIC_ELEMENTS.get(weapon.get("magic_school", ""), ""))
	var elemental_share = 0.0

	if not element_key.is_empty():
		elemental_share = clampf(float(weapon.get("magic_share", 1.0)), 0.0, 1.0)
		var resistance = resistances.get("Elemental", 0.0) + resistances.get(element_key, 0.0)

		total_damage += _apply_resistance(
			physical_damage * elemental_share,
			clampf(resistance, 0.0, 1.0),
			penetration
		)

	var physical_multiplier = 1.0 + _get_gear_bonus("physical_damage_percent") / 100.0
	total_damage += _apply_resistance(
		physical_damage * (1.0 - elemental_share) * physical_multiplier,
		clampf(physical_resistance, 0.0, 1.0),
		penetration
	)
	
	for element in weapon["magic_damage"]:
		var elemental_damage = weapon["magic_damage"][element]
	
		var elemental_resistance = (
			resistances.get("Elemental", 0.0)
			+ resistances.get(element, 0.0)
		)
	
		total_damage += _apply_resistance(
			elemental_damage,
			clampf(elemental_resistance, 0.0, 1.0),
			penetration
		)
	var vulnerable_stacks = _get_status_turns(
		enemy.get("active_effects", []),
		"vulnerable"
	)

	var vulnerable_per_stack = float(
		status_effect_database["vulnerable"]["incoming_damage_modifier"]
	)

	if vulnerable_stacks > 0:
		total_damage *= 1.0 + vulnerable_per_stack
	return floorf(total_damage * 1000.0) / 1000.0


func _get_weapon_damage() -> float:
	var weapon = _get_equipped_weapon()
	var base_damage = weapon["base_damage"]
	var scaling_bonus = 0.0

	for stat_name in weapon["scalings"]:
		var scaling = weapon["scalings"][stat_name]
		var stat_value = _get_total_stat(stat_name)

		scaling_bonus += (stat_value / 5.0) * (scaling / 2.0)

	var total_damage = base_damage + scaling_bonus

	return floorf(total_damage * 1000.0) / 1000.0



func _calculate_player_attack_damage(multiplier: float = 1.0, strength_scaling: float = 0.0) -> float:
	var weapon_damage = _get_weapon_damage()
	var attack_damage = weapon_damage * multiplier

	var strength = _get_total_stat("Strength")
	var strength_bonus = (strength / 5.0) * (strength_scaling / 2.0)

	attack_damage += strength_bonus

	if focus_damage_ready:
		attack_damage *= 1.5
	var weakness_stacks = _get_status_turns(
		player_active_effects,
		"weakness"
	)

	var weakness_per_stack = float(
		status_effect_database["weakness"]["outgoing_damage_modifier"]
	)

	if weakness_stacks > 0:
		attack_damage *= maxf(0.0, 1.0 + weakness_per_stack)

	return floorf(attack_damage * 1000.0) / 1000.0



func _format_damage(value: float) -> String:
	var thousandths = maxi(0, roundi(value * 1000.0))
	var hundredths = floori(thousandths / 10.0)

	var whole_part = floori(hundredths / 100.0)
	var decimal_part = hundredths % 100

	if decimal_part == 0:
		return str(whole_part)

	return "%d.%02d" % [whole_part, decimal_part]


const STAT_NAME_COLORS = {
	"Strength": Color("#CF807C"),
	"Fortitude": Color("#C6B66D"),
	"Agility": Color("#87BE93"),
	"Intelligence": Color("#84ADD5"),
	"Willpower": Color("#819BD2"),
	"Charisma": Color("#B995CD"),
	"Flarebreath": Color("#E39180"),
	"Terraton": Color("#C49C78"),
	"Gustemp": Color("#B8D1DD"),
	"Blitzten": Color("#DECA7E"),
	"Hoarfrost": Color("#9CCDE4"),
	"Umbra": Color("#A591C1"),
	"Hallow": Color("#DCD2B3")
}


func _refresh_stat_display() -> void:
	var panel = get_node("BetweenFightsPanel") as Control
	var scroll = panel.get_node_or_null("StatsScroll") as ScrollContainer

	if scroll == null:
		var stat_list = panel.get_node("StatsContainer") as Control
		var list_position = stat_list.position

		scroll = ScrollContainer.new()
		scroll.name = "StatsScroll"
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		panel.add_child(scroll)
		panel.move_child(scroll, stat_list.get_index())
		scroll.position = Vector2(list_position.x, maxf(0.0, list_position.y - 12.0))

		stat_list.reparent(scroll, false)
		stat_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var xp_label := panel.get_node("XPLabel") as Label
	scroll.position.y = xp_label.position.y

	var scroll_bottom := get_viewport_rect().end - Vector2(0.0, 100.0)
	var local_bottom := scroll.get_global_transform_with_canvas().affine_inverse() * scroll_bottom
	scroll.size = Vector2(360.0, maxf(0.0, local_bottom.y))

	var container = scroll.get_node("StatsContainer")
	for child in container.get_children():
		container.remove_child(child)
		child.queue_free()

	for stat_name in player_stats:
		var row = stat_row_scene.instantiate()
		var invested = player_stats[stat_name]
		var racial = racial_stats[stat_name]
		var total = floori(float(_get_total_stat(stat_name)))
		var can_allocate = stat_points > 0 and invested < max_stat_value

		container.add_child(row)
		row.setup(stat_name, invested, racial, total, can_allocate)

		for label in row.find_children("*", "Label", true, false):
			if label.text.strip_edges().trim_suffix(":") == stat_name:
				label.add_theme_color_override(
					"font_color",
					STAT_NAME_COLORS.get(stat_name, Color("#D8D6D2"))
				)
				break

		var stat_buttons = row.find_children("*", "Button", true, false)
		if not stat_buttons.is_empty():
			stat_buttons[0].button_down.connect(_on_stat_hold_started.bind(stat_name))

	panel.get_node("StatPointsLabel").text = "Available stat points: %d" % stat_points


func _allocate_stat(stat_name: String) -> bool:
	if not player_stats.has(stat_name):
		return false

	if stat_points <= 0:
		return false

	if player_stats[stat_name] >= max_stat_value:
		return false

	player_stats[stat_name] += 1
	stat_points -= 1

	for spell_id in spells:
		var spell: Dictionary = spells[spell_id]
		if (
			not spell.get("scroll_only", false)
			and spell["magic_type"] == stat_name
			and player_stats[stat_name] == spell["required_investment"]
		):
			_learn_spell(spell_id)

	if stat_name == "Fortitude":
		_update_max_health()

	return true


func _on_stat_hold_started(stat_name: String) -> void:
	if combat_state != "between_fights":
		return

	held_stat_name = stat_name
	stat_hold_timer = 0.35

	if _allocate_stat(stat_name):
		_refresh_stat_display()


func _on_stat_requested(stat_name):
	if combat_state != "between_fights":
		return

	if _allocate_stat(stat_name):
		_refresh_stat_display()


func _open_between_fights(escaped = false):
	_clear_temporary_summons()
	speed_demon_factor = 1.0
	combat_state = "between_fights"
	player_status_container.hide()
	loot_continue_button.hide()

	if escaped:
		_clear_player_status_effects()

	if not escaped:
		_apply_regen()

		# A fully defeated wave permanently increases future XP rewards.
		completed_waves += 1

		var bonus_percent = completed_waves * xp_bonus_per_wave * 100.0

		_add_combat_log(
			"Wave %d cleared! XP bonus is now +%.0f%%!"
			% [encounter_number, bonus_percent],
			"success"
		)

		print(
			"Completed waves: %d | Permanent XP bonus: +%.0f%%"
			% [completed_waves, bonus_percent]
		)

	get_node("EnemySlotsContainer").hide()
	get_node("LineEdit").hide()
	get_node("LineEdit").editable = false
	get_node("AttackLabel").text = ""

	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).hide()

	for node_name in ["Label", "CombatLog", "ActionTimerBar", "ComboTimerBar", "GuardLabel"]:
		get_node(node_name).hide()

	if escaped:
		get_node("BetweenFightsPanel/VictoryLabel").text = "Escaped!"
	else:
		get_node("BetweenFightsPanel/VictoryLabel").text = "Victory!"

	get_node("BetweenFightsPanel/XPLabel").text = _get_xp_display()
	get_node("BetweenFightsPanel/GoldLabel").text = "Gold: %d" % player_gold
	var gold_label = get_node("BetweenFightsPanel/GoldLabel")
	gold_label.position.x = 320 - gold_label.size.x / 2.0

	_refresh_stat_display()
	get_node("BetweenFightsPanel").show()
	var hp_background := get_node("HPBackground") as Control
	var hp_center_x := hp_background.get_global_rect().get_center().x

	for label_name in ["VictoryLabel", "XPLabel"]:
		var heading := get_node("BetweenFightsPanel/" + label_name) as Label
		heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		heading.size.x = 480.0
		heading.global_position.x += hp_center_x - heading.get_global_rect().get_center().x

	get_node("HPBackground").show()
	get_node("PlayerHP").show()
	_show_campfire_intro()




func _on_continue_button_pressed():
	if combat_state != "between_fights":
		return

	_dismiss_campfire_intro()

	if _get_wave_type() == "shop" and last_counted_shop_wave != encounter_number:
		_open_shop()
		return
	
	get_node("BetweenFightsPanel").hide()
	player_status_container.show()
	get_node("EnemySlotsContainer").show()
	
	for node_name in ["PlayerHP", "Label", "CombatLog", "GuardLabel"]:
		get_node(node_name).show()
	
	encounter_number += 1
	successful_blocks = 0
	guard_exhausted = false
	guard_recovery_pending = false
	_update_guard_display()
	_generate_encounter()
	
	combat_state = "planning_phase"
	selected_planning_option = 0
	
	for button in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(button).show()
	
	_update_planning_selection()
	if boss_encounter and not boss_intro_seen:
		_show_boss_intro()


func _refresh_combat_header_layout() -> void:
	var target_label = get_node("Label") as Label
	var attack_label = get_node("AttackLabel") as Label
	var input = get_node("LineEdit") as LineEdit
	var bag_button = get_node("BagButton") as Button
	var book_button = get_node("BookButton") as Button
	
	var center_x: float
	var heading_y: float
	
	if input.visible:
		center_x = input.get_global_rect().get_center().x
		heading_y = input.get_global_rect().position.y - 58.0
	else:
		center_x = (bag_button.get_global_rect().get_center().x + book_button.get_global_rect().get_center().x) / 2.0
		heading_y = bag_button.get_global_rect().position.y - 58.0
	
	# Match both headings to the actual center of the active controls.
	for label in [target_label, attack_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	
	target_label.size = Vector2(540, 30)
	attack_label.size = Vector2(540, 34)
	
	attack_label.global_position = Vector2(
		center_x - attack_label.size.x / 2.0,
		heading_y
	)
	
	target_label.global_position = Vector2(
		center_x - target_label.size.x / 2.0,
		heading_y - 40.0
	)

func _learn_spell(spell_id: String) -> void:
	if learned_spell_codes.has(spell_id) or not spells.has(spell_id):
		return

	var start = randi_range(0, 8999)
	for offset in range(9000):
		var code = str(1000 + (start + offset) % 9000)
		var conflicts = false

		for existing_code in learned_spell_codes.values():
			if code.begins_with(existing_code) or existing_code.begins_with(code):
				conflicts = true
				break

		if not conflicts:
			learned_spell_codes[spell_id] = code
			return

	push_error("No free four-digit spell code for " + spell_id)


func _try_cast_spell(command: String) -> bool:
	var spell_id = learned_spell_codes.find_key(command)

	if spell_id == null:
		for learned_id in learned_spell_codes:
			if command.trim_suffix(".") == str(spells[learned_id]["name"]).to_lower().trim_suffix("."):
				spell_id = learned_id
				break

	if spell_id == null:
		return false

	var spell: Dictionary = spells[spell_id]
	var line_edit = get_node("LineEdit") as LineEdit
	var timer = get_node("AttackTimer") as Timer
	if timer.time_left <= 0.0:
		return false

	var mana_cost := _effective_mana_cost(int(spell["mana_cost"]))
	if player_mana < mana_cost:
		_add_combat_log("You need %d mana to cast %s." % [mana_cost, spell["name"]], "warning")
		line_edit.clear()
		return true

	if spell_id == "slime_absorb" and _lowest_allied_slime() == -1:
		_add_combat_log("You need an allied Slime to absorb.", "warning")
		line_edit.clear()
		return true
	if spell_id == "slime_summon" and player_health <= _slime_hp_cost():
		_add_combat_log("You need more HP to summon a Slime.", "warning")
		line_edit.clear()
		return true

	timer.stop()
	get_node("ActionTimerBar").hide()
	line_edit.clear()
	_set_mana(player_mana - mana_cost)

	_add_combat_log("You cast %s!" % spell["name"], "success")
	_resolve_spell(spell_id)
	_finish_player_turn(1.0)
	return true

func _get_scaled_spell_damage(base_damage: float, magic_type: String, scaling: float) -> float:
	return base_damage + float(_get_total_stat(magic_type)) * scaling / 10.0


func _holy_damage_multiplier() -> float:
	var multiplier := 1.25 if holy_sacrifice_turns > 0 else 1.0
	return multiplier * (float(spells["slime_absorb"]["damage_multiplier"]) if player_absorb_turns > 0 else 1.0)


func _apply_spell_resistance(target: Dictionary, damage: float, magic_type: String) -> float:
	var resistances: Dictionary = target.get("resistances", {})
	var resistance = float(resistances.get("Elemental", 0.0))
	resistance += float(resistances.get(MAGIC_ELEMENTS[magic_type], 0.0))
	return _apply_resistance(damage, clampf(resistance, 0.0, 1.0), 0.0)


func _hit_with_spell(slot_index: int, damage: float, spell_name: String, allied_follow_up: bool = true) -> float:
	var target: Dictionary = active_enemies[slot_index]
	var health_units = maxi(0, roundi(float(target["health"]) * 1000.0))
	var dealt_units = clampi(floori(damage * 1000.0), 0, health_units)
	target["health"] = (health_units - dealt_units) / 1000.0
	var dealt = dealt_units / 1000.0

	_add_combat_log("%s hit %s for %s damage." % [
		spell_name, target["name"], _format_damage(dealt)
	], "damage")

	if target["health"] <= 0.0:
		_defeat_enemy(slot_index)

	if dealt > 0.0 and allied_follow_up:
		_allied_slimes_follow_up(slot_index, target)
	return dealt


func _resolve_spell(spell_id: String) -> void:
	var spell: Dictionary = spells[spell_id]
	var spell_name := str(spell["name"])
	var living_slots: Array[int] = []

	for i in range(active_enemies.size()):
		if active_enemies[i] != null and active_enemies[i]["health"] > 0.0:
			living_slots.append(i)

	if living_slots.is_empty():
		return

	var target_slot = selected_enemy_slot
	if target_slot not in living_slots:
		target_slot = living_slots[0]

	match spell_id:
		"slime_ball":
			var target: Dictionary = active_enemies[target_slot]
			_hit_with_spell(target_slot, float(spell["damage"]), spell_name)
			_apply_status_effect(target, "flammable_slime", 1, int(spell["flammable_turns"]))

		"slime_summon":
			var previous_hp: int = player_health
			player_health -= _slime_hp_cost()
			wave_flawless = false
			_on_player_damaged(previous_hp)
			_refresh_boss_update_hp()
			_summon_allied_slime()

		"slime_crush":
			_slime_area_attack(_calculate_player_attack_damage(float(spell["damage_multiplier"])), "", int(spell["sluggish_turns"]))
			focus_damage_ready = false

		"slime_absorb":
			var slime_index := _lowest_allied_slime()
			if slime_index >= 0:
				allied_summons.remove_at(slime_index)
				_refresh_summons()
				player_health = mini(player_max_health, player_health + maxi(1, roundi(player_max_health * float(spell["heal_fraction"]))))
				_refresh_boss_update_hp()
				player_absorb_turns = int(spell["buff_turns"]) + 1

		"flame_roar":
			if _has_weapon_enchantment("unwilling"):
				_apply_status_effect(active_enemies[target_slot], "burn", 1, 2)
			else:
				for i in living_slots:
					_apply_status_to_target(active_enemies[i], "burn", 1, 2)

		"earth_pillars":
			# The casting round ends before the five attack turns begin.
			earth_pillars_turns = 6

		"wind_cuts":
			var target: Dictionary = active_enemies[target_slot]
			var raw_damage = _get_scaled_spell_damage(10.0, "Gustemp", 2.0)
			var damage = _apply_spell_resistance(target, raw_damage, "Gustemp")
			_hit_with_spell(target_slot, damage * _holy_damage_multiplier(), spell_name)
			_apply_status_effect(target, "bleed", 1, 2)

		"lightning_orbs":
			var raw_damage = _get_scaled_spell_damage(4.0, "Blitzten", 1.5)
			for orb in range(5):
				if living_slots.is_empty():
					break
				var slot_index: int = living_slots.pick_random()
				var damage = _apply_spell_resistance(active_enemies[slot_index], raw_damage, "Blitzten")
				_hit_with_spell(slot_index, damage * _holy_damage_multiplier(), spell_name)
				if active_enemies[slot_index] == null:
					living_slots.erase(slot_index)

		"frost_tag":
			if randf() < 0.85:
				_apply_status_effect(active_enemies[target_slot], "freeze", 1, 2)
			else:
				_add_combat_log("Frost Tag missed!", "failure")

		"siphon":
			var raw_damage = _get_scaled_spell_damage(7.0, "Umbra", 1.0)
			var damage = _apply_spell_resistance(active_enemies[target_slot], raw_damage, "Umbra")
			var dealt = _hit_with_spell(target_slot, damage * _holy_damage_multiplier(), spell_name)
			var healing = mini(roundi(dealt * 0.10), player_max_health - player_health)
			player_health += healing
			get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]
			if healing > 0:
				_add_combat_log("Siphon restored %d HP." % healing, "success")

		"holy_sacrifice":
			var previous_hp = player_health
			var sacrifice = mini(player_health, maxi(1, roundi(player_max_health * 0.05)))
			player_health -= sacrifice
			wave_flawless = false
			_on_player_damaged(previous_hp)
			get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]

			for i in living_slots:
				_hit_with_spell(i, float(sacrifice), spell_name)

			var duration = mini(4, living_slots.size())
			holy_sacrifice_turns = maxi(holy_sacrifice_turns, duration + 1)
			_add_combat_log("Sacrificed %d HP. +25%% damage for %d turn(s)." % [
				sacrifice, duration
			], "success")

		"conjure_blades":
			for blade in range(randi_range(2, 8)):
				_hit_with_spell(target_slot, 4.0 * _holy_damage_multiplier(), spell_name)
				if active_enemies[target_slot] == null:
					break

		"call_forth_zeus":
			var target: Dictionary = active_enemies[target_slot]
			var raw_damage = _get_scaled_spell_damage(30.0, "Blitzten", 1.0)
			var damage = _apply_spell_resistance(target, raw_damage, "Blitzten")
			_hit_with_spell(target_slot, damage * _holy_damage_multiplier(), spell_name)
			_apply_status_effect(target, "shock", 1, 5)

		"flare_volley":
			var raw_damage = _get_scaled_spell_damage(5.0, "Flarebreath", 0.5)
			for hit in range(randi_range(1, 6)):
				if living_slots.is_empty():
					break
				var slot_index: int = living_slots.pick_random()
				var target: Dictionary = active_enemies[slot_index]
				var damage = _apply_spell_resistance(target, raw_damage, "Flarebreath")
				_hit_with_spell(slot_index, damage * _holy_damage_multiplier(), spell_name)
				if active_enemies[slot_index] == null:
					living_slots.erase(slot_index)
				_apply_status_effect(target, "burn", 1, 1)

	_deploy_reinforcements()

func _setup_spellbook(bag_panel: Control) -> void:
	var button = Button.new()
	button.text = "Spellbook"
	button.position = Vector2(575, 50)
	button.size = Vector2(130, 32)
	button.pressed.connect(_open_spellbook)
	bag_panel.add_child(button)

	spellbook_dialog = AcceptDialog.new()
	spellbook_dialog.title = "Spellbook"
	bag_panel.add_child(spellbook_dialog)

	spellbook_text = RichTextLabel.new()
	spellbook_text.custom_minimum_size = Vector2(460, 280)
	spellbook_text.scroll_active = true
	spellbook_dialog.add_child(spellbook_text)


func _open_spellbook() -> void:
	var entries = PackedStringArray()

	for spell_id in learned_spell_codes:
		var spell: Dictionary = spells[spell_id]
		entries.append("%s  |  %s  |  %d mana\n%s" % [
			spell["name"], learned_spell_codes[spell_id],
			_effective_mana_cost(int(spell["mana_cost"])), spell["description"]
		])

	spellbook_text.text = "\n\n".join(entries)
	if entries.is_empty():
		spellbook_text.text = "Invest 15 points in a magic type to learn its starter spell."

	spellbook_dialog.popup_centered(Vector2i(500, 340))
	spellbook_text.scroll_to_line(0)

func _setup_mana_bar() -> void:
	var combat_log = get_node("CombatLog") as Control
	combat_log.clip_contents = true

	mana_bar = HBoxContainer.new()
	mana_bar.name = "ManaBar"
	mana_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mana_bar.add_theme_constant_override("separation", 3)
	combat_log.get_parent().add_child(mana_bar)

	combat_log.item_rect_changed.connect(_position_mana_bar)
	combat_log.visibility_changed.connect(_position_mana_bar)
	_position_mana_bar()


func _position_mana_bar() -> void:
	var combat_log = get_node("CombatLog") as Control
	mana_bar.position = combat_log.position + Vector2(0.0, -18.0)
	mana_bar.size = Vector2(combat_log.size.x, 12.0)
	mana_bar.visible = combat_log.visible


func _get_max_mana() -> int:
	return (
		5 + floori(float(_get_total_stat("Intelligence")) / 10.0)
		+ _get_gear_bonus("max_mana_bonus")
	)

func _set_mana(amount: int) -> void:
	var max_mana = _get_max_mana()
	player_mana = clampi(amount, 0, max_mana)

	for child in mana_bar.get_children():
		mana_bar.remove_child(child)
		child.queue_free()

	for i in range(max_mana):
		var segment = Panel.new()
		segment.mouse_filter = Control.MOUSE_FILTER_IGNORE
		segment.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		var style = StyleBoxFlat.new()
		style.bg_color = Color("#7EA9D8") if i < player_mana else Color("#303946")
		style.border_color = Color.BLACK
		style.set_border_width_all(1)
		segment.add_theme_stylebox_override("panel", style)

		mana_bar.add_child(segment)

func _layout_ui() -> void:
	# Control geometry
	var layout = {
		"PlayerHP": [Vector2(530, -10), Vector2(220, 36)],
		"GuardLabel": [Vector2(530, 26), Vector2(220, 26)],

		"Label": [Vector2(0, 473), Vector2(1280, 30)],
		"AttackLabel": [Vector2(365, 506), Vector2(550, 34)],

		"LineEdit": [Vector2(490, 565), Vector2(300, 40)],
		"ActionTimerBar": [Vector2(490, 608), Vector2(300, 8)],
		"ComboTimerBar": [Vector2(490, 619), Vector2(300, 8)],

		"CombatLog": [Vector2(8, 490), Vector2(320, 170)],

		"AttackButton": [Vector2(365, 545), Vector2(125, 58)],
		"BagButton": [Vector2(507, 545), Vector2(125, 58)],
		"BookButton": [Vector2(649, 545), Vector2(125, 58)],
		"RunButton": [Vector2(791, 545), Vector2(125, 58)]
	}

	for node_name in layout:
		var control = get_node_or_null(node_name) as Control
		if control == null:
			push_warning("Missing UI node: " + node_name)
			continue

		control.custom_minimum_size = Vector2.ZERO
		control.grow_horizontal = Control.GROW_DIRECTION_END
		control.grow_vertical = Control.GROW_DIRECTION_END
		control.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
		control.scale = Vector2.ONE
		control.rotation = 0.0
		control.position = layout[node_name][0]
		control.size = layout[node_name][1]

	# Player HP and Guard
	var hp_background = get_node_or_null("HPBackground") as ColorRect
	if hp_background == null:
		hp_background = ColorRect.new()
		hp_background.name = "HPBackground"
		add_child(hp_background)

	hp_background.custom_minimum_size = Vector2.ZERO
	hp_background.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	hp_background.position = Vector2(530, 0)
	hp_background.size = Vector2(220, 36)
	hp_background.color = Color("#292929")
	hp_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hp_background.z_index = 20

	var hp_label = get_node("PlayerHP") as Label
	var guard_label = get_node("GuardLabel") as Label

	for label in [hp_label, guard_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label.z_index = 21

	hp_label.add_theme_font_size_override("font_size", 24)
	guard_label.add_theme_font_size_override("font_size", 18)
	hp_label.add_theme_color_override("font_color", Color.WHITE)
	guard_label.add_theme_color_override("font_color", Color("#D8D8D8"))

	# Centered target and combat announcements
	var target_label = get_node("Label") as Label
	var attack_label = get_node("AttackLabel") as Label

	for label in [target_label, attack_label]:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.layout_direction = Control.LAYOUT_DIRECTION_LTR
		label.autowrap_mode = TextServer.AUTOWRAP_OFF
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		target_label.z_index = 5
		attack_label.z_index = 5

	target_label.add_theme_font_size_override("font_size", 21)
	attack_label.add_theme_font_size_override("font_size", 24)
	target_label.add_theme_color_override("font_color", Color("#E0E0E0"))
	attack_label.add_theme_color_override("font_color", Color.WHITE)

	# Typing box
	var input = get_node("LineEdit") as LineEdit
	input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	input.placeholder_text = "Type your command"
	input.add_theme_font_size_override("font_size", 20)
	input.add_theme_color_override("font_color", Color.WHITE)
	input.add_theme_color_override("font_placeholder_color", Color("#999999"))
	input.add_theme_color_override("caret_color", Color.WHITE)

	var input_style = StyleBoxFlat.new()
	input_style.bg_color = Color("#292929")
	input_style.border_color = Color("#999999")
	input_style.set_border_width_all(1)
	input_style.set_corner_radius_all(4)
	input_style.content_margin_left = 12
	input_style.content_margin_right = 12
	input_style.content_margin_top = 7
	input_style.content_margin_bottom = 7

	input.add_theme_stylebox_override("normal", input_style)
	input.add_theme_stylebox_override("read_only", input_style)

	var focus_style = input_style.duplicate() as StyleBoxFlat
	focus_style.border_color = Color("#D0D0D0")
	input.add_theme_stylebox_override("focus", focus_style)

	# Timer bars below input
	for bar_name in ["ActionTimerBar", "ComboTimerBar"]:
		var bar = get_node(bar_name) as ProgressBar
		bar.show_percentage = false

		var background_style = StyleBoxFlat.new()
		background_style.bg_color = Color("#303030")
		background_style.set_corner_radius_all(4)

		var fill_style = StyleBoxFlat.new()
		fill_style.bg_color = Color("#A0A0A0")
		fill_style.set_corner_radius_all(4)

		bar.add_theme_stylebox_override("background", background_style)
		bar.add_theme_stylebox_override("fill", fill_style)

	# Combat log
	var combat_log = get_node("CombatLog") as RichTextLabel
	combat_log.add_theme_font_size_override("normal_font_size", 17)

	var log_style = StyleBoxFlat.new()
	log_style.bg_color = Color("#292929")
	log_style.set_corner_radius_all(5)
	log_style.content_margin_left = 10
	log_style.content_margin_right = 10
	log_style.content_margin_top = 10
	log_style.content_margin_bottom = 10

	combat_log.add_theme_stylebox_override("normal", log_style)

	# Planning buttons
	for button_name in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		var button = get_node(button_name) as Button
		button.add_theme_font_size_override("font_size", 22)
		button.add_theme_color_override("font_color", Color("#E8E8E8"))

		var button_style = StyleBoxFlat.new()
		button_style.bg_color = Color("#292929")
		button_style.border_color = Color("#777777")
		button_style.set_border_width_all(1)
		button_style.set_corner_radius_all(4)
		button.add_theme_stylebox_override("normal", button_style)

		var hover_style = button_style.duplicate() as StyleBoxFlat
		hover_style.bg_color = Color("#3D3D3D")
		button.add_theme_stylebox_override("hover", hover_style)

		var pressed_style = button_style.duplicate() as StyleBoxFlat
		pressed_style.bg_color = Color("#202020")
		button.add_theme_stylebox_override("pressed", pressed_style)

	# Enemy display
	var enemy_container = get_node("EnemySlotsContainer") as Control
	enemy_container.set_anchors_preset(Control.PRESET_TOP_LEFT)
	enemy_container.position = Vector2(280, 100)
	enemy_container.size = Vector2(1020, 250)
	enemy_container.scale = Vector2(0.70, 0.70)

	if enemy_container is BoxContainer:
		enemy_container.alignment = BoxContainer.ALIGNMENT_CENTER
		enemy_container.add_theme_constant_override("separation", 12)

	# Automatically reposition announcements when typing begins/ends
	if not input.visibility_changed.is_connected(_refresh_combat_header_layout):
		input.visibility_changed.connect(_refresh_combat_header_layout)
	_refresh_combat_header_layout()



func _setup_extra_combo_bars(stage_count: int = 7) -> void:
	var template = get_node("ComboTimerBar") as ProgressBar

	while extra_combo_bars.size() + 2 < stage_count:
		var bar = template.duplicate() as ProgressBar
		bar.name = "ExtraComboTimerBar%d" % (extra_combo_bars.size() + 3)
		bar.show_percentage = false
		bar.hide()

		template.get_parent().add_child(bar)
		extra_combo_bars.append(bar)

	_update_combo_bar_positions()


func _get_combo_stage_bar(stage_index: int) -> ProgressBar:
	if stage_index == 0:
		return get_node("ActionTimerBar") as ProgressBar

	if stage_index == 1:
		return get_node("ComboTimerBar") as ProgressBar

	var extra_index = stage_index - 2

	if extra_index >= 0 and extra_index < extra_combo_bars.size():
		return extra_combo_bars[extra_index]

	return null


func _update_combo_bar_positions() -> void:
	for i in range(extra_combo_bars.size() + 2):
		var bar = _get_combo_stage_bar(i)

		if bar == null:
			continue

		bar.position = Vector2(490, 608 + i * 11)
		bar.size = Vector2(300, 8)
		bar.show_percentage = false


func _show_attack_stage_bars(stage_count: int) -> void:
	if stage_count > extra_combo_bars.size() + 2:
		_setup_extra_combo_bars(stage_count)
	for i in range(extra_combo_bars.size() + 2):
		var bar = _get_combo_stage_bar(i)

		if bar == null:
			continue

		if i < stage_count:
			bar.value = 100
			bar.show()
		else:
			bar.hide()


func _hide_attack_stage_bars() -> void:
	for i in range(extra_combo_bars.size() + 2):
		var bar = _get_combo_stage_bar(i)

		if bar != null:
			bar.hide()


# Optional scene override. The default sprite lives in enemy_data.gd.
@export_file("*.png") var slime_potentate_sprite := ""
var boss_encounter := false
var boss_intro_seen := false
var boss_intro_box: Button
var boss_intro_page := 0
var boss_chest_pending := false
var boss_summoned := false
var boss_absorbed := false
var boss_exploded := false
var boss_attacks_since_summon := 0
var boss_absorb_turns := 0
var boss_absorb_damage := 0.0
var player_absorb_turns := 0
var taunt_active := false
var slime_defense_time_multiplier := 1.0
var stage_summon_target: Dictionary = {}
var allied_summons: Array[Dictionary] = []
var summon_row: HBoxContainer
var passive_inventory: Dictionary = {}
var passive_dialog: AcceptDialog
var passive_list: ItemList
var passive_detail: RichTextLabel
var passive_sort: OptionButton
var passive_entries: Array[String] = []


func _install_slime_content() -> void:
	SlimeContent.install_items(weapon_database, armor_database, consumable_database)
	set_bonus_database["slime_armor"] = {
		"required_items": ["slime_helm", "slime_chest", "slime_legs", "slime_boots"],
		"reward_text": "%.0f%% chance to fully absorb an enemy hit.\nUnavoidable attacks and damage over time bypass this bonus." % (SlimeContent.SLIME_SET_NEGATE_CHANCE * 100.0),
	}
	if not slime_potentate_sprite.is_empty():
		enemy_database[SlimeContent.BOSS_ID]["sprite"] = slime_potentate_sprite
	status_effect_database.merge(SlimeContent.STATUS_EFFECTS.duplicate(true), true)


func _load_optional_texture(path: String) -> Texture2D:
	return load(path) as Texture2D if not path.is_empty() and ResourceLoader.exists(path) else null

var campfire_intro_seen := false
var campfire_intro_page := 0
var campfire_intro_box: Button

const CAMPFIRE_INTRO_PAGES := [
	"The light from the fire keeps you safe from what may lurk in the dark...",
	"for now.",
]


func _show_campfire_intro() -> void:
	if campfire_intro_seen:
		return

	campfire_intro_seen = true
	campfire_intro_page = 0
	campfire_intro_box = Button.new()
	campfire_intro_box.focus_mode = Control.FOCUS_NONE
	campfire_intro_box.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	campfire_intro_box.add_theme_font_size_override("font_size", 18)
	campfire_intro_box.z_index = 40
	campfire_intro_box.text = CAMPFIRE_INTRO_PAGES[0] 
	get_node("BetweenFightsPanel").add_child(campfire_intro_box)
	campfire_intro_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_position_campfire_intro()


func _position_campfire_intro() -> void:
	if not is_instance_valid(campfire_intro_box):
		return

	var viewport := get_viewport_rect()
	var width := minf(720.0, maxf(1.0, viewport.size.x - 32.0))
	campfire_intro_box.size = Vector2(width, 72.0)
	campfire_intro_box.global_position = Vector2(
		viewport.get_center().x - campfire_intro_box.size.x * 0.5,
		viewport.end.y - campfire_intro_box.size.y - 16.0
	)


func _advance_campfire_intro() -> void:
	if not is_instance_valid(campfire_intro_box):
		return

	campfire_intro_page += 1
	if campfire_intro_page < CAMPFIRE_INTRO_PAGES.size():
		campfire_intro_box.text = CAMPFIRE_INTRO_PAGES[campfire_intro_page]
		return

	_dismiss_campfire_intro()

func _dismiss_campfire_intro() -> void:
	if not is_instance_valid(campfire_intro_box):
		return

	campfire_intro_box.hide()
	campfire_intro_box.queue_free()
	campfire_intro_box = null

func _show_boss_intro() -> void:
	combat_state = "boss_intro"
	boss_intro_page = 0
	for node_name in ["AttackButton", "BagButton", "BookButton", "RunButton", "LineEdit"]:
		get_node(node_name).hide()
	get_node("AttackLabel").text = ""
	boss_intro_box = Button.new()
	boss_intro_box.focus_mode = Control.FOCUS_NONE
	boss_intro_box.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	boss_intro_box.add_theme_font_size_override("font_size", 18)
	boss_intro_box.z_index = 40
	add_child(boss_intro_box)
	boss_intro_box.size = Vector2(520, 56)
	boss_intro_box.pressed.connect(_advance_boss_intro)
	_refresh_boss_intro()
	_position_boss_intro()
	_position_boss_intro.call_deferred()


func _position_boss_intro() -> void:
	if combat_state != "boss_intro" or not is_instance_valid(boss_intro_box):
		return
	var center_x := get_viewport_rect().get_center().x
	var slots := get_node("EnemySlotsContainer")
	if slots.get_child_count() > SlimeContent.CENTER_SLOT:
		var middle := slots.get_child(SlimeContent.CENTER_SLOT) as Control
		if middle != null and middle.size.x > 0:
			center_x = middle.get_global_rect().get_center().x
	boss_intro_box.global_position = Vector2(center_x - boss_intro_box.size.x * 0.5, 62.0)


func _refresh_boss_intro() -> void:
	var pages := [
		"Oh, it’s you. I’ve heard about you.",
		"You’re the Slayer, the slime murderer. The evil in this dungeon.",
		"I’ll show you why slimes are superior!",
	]
	boss_intro_box.text = pages[boss_intro_page]


func _advance_boss_intro() -> void:
	if combat_state != "boss_intro":
		return
	boss_intro_page += 1
	if boss_intro_page < 3:
		_refresh_boss_intro()
		return
	boss_intro_seen = true
	boss_intro_box.hide()
	boss_intro_box.queue_free()
	combat_state = "planning_phase"
	for node_name in ["AttackButton", "BagButton", "BookButton", "RunButton"]:
		get_node(node_name).show()
	_update_planning_selection()


func _current_attacker_is_boss() -> bool:
	return current_attacker_slot >= 0 and active_enemies[current_attacker_slot] != null and active_enemies[current_attacker_slot]["id"] == SlimeContent.BOSS_ID


func _choose_potentate_move(regular_attack: Dictionary) -> Dictionary:
	var boss: Dictionary = active_enemies[current_attacker_slot]
	var phases: Dictionary = enemy_database[SlimeContent.BOSS_ID]["phases"]
	if not boss_summoned and boss["health"] <= boss["max_health"] * float(phases["summon_health_fraction"]):
		boss_summoned = true
		for slot_index in range(MAX_ENEMY_SLOTS):
			if slot_index != SlimeContent.CENTER_SLOT and _spawn_enemy("slime", slot_index):
				active_enemies[slot_index]["boss_spawn"] = true
		_refresh_enemy_slots()
		_add_combat_log("Slime Potentate used Slime Summon!", "warning")
		return {}

	if boss_summoned and not boss_absorbed and boss_attacks_since_summon >= int(phases["attacks_before_absorb"]):
		boss_absorbed = true
		var count := 0
		for slot_index in _get_living_enemy_slots():
			if active_enemies[slot_index].get("id") == "slime":
				active_enemies[slot_index] = null
				enemy_turn_queue.erase(slot_index)
				count += 1
		for index in range(allied_summons.size() - 1, -1, -1):
			if allied_summons[index].get("id") == "slime":
				allied_summons.remove_at(index)
				count += 1
		boss_absorb_damage = float(phases["absorb_damage_per_slime"]) * count
		var duration := int(phases["absorb_turns"])
		boss_absorb_turns = duration + 1
		_refresh_enemy_slots()
		_refresh_summons()
		_add_combat_log("Slime Potentate absorbed %d Slimes. +%d%% damage for %d turns." % [count, roundi(boss_absorb_damage * 100), duration], "warning")
		return {}

	if boss_summoned and not boss_absorbed:
		boss_attacks_since_summon += 1
	if boss["health"] < boss["max_health"] * float(phases["explosion_health_fraction"]) and not boss_exploded:
		boss_exploded = true
		var attack: Dictionary = phases["explosion_attack"].duplicate(true)
		attack["damage"] = float(attack["damage"]) * _get_enemy_wave_multiplier()
		return attack
	return regular_attack


func _enemy_stage_raw_damage(base_damage: float) -> float:
	if _current_attacker_is_boss() and boss_absorb_turns > 0:
		return base_damage * (1.0 + boss_absorb_damage)
	return base_damage


func _sluggish_speed_factor(effects: Array) -> float:
	return SlimeContent.SLUGGISH_SPEED_MULTIPLIER if _get_status_turns(effects, "sluggish") > 0 else 1.0


func _effective_mana_cost(base_cost: int) -> int:
	return maxi(0, base_cost - SlimeContent.BRAIN_MANA_DISCOUNT * int(passive_inventory.get("slime_brain", {}).get("quantity", 0)))


func _slime_hp_cost() -> int:
	return maxi(1, roundi(player_max_health * float(spells["slime_summon"]["health_cost_fraction"])))


const SLIME_DNA_SUMMON_MULTIPLIER := 1.75
var slime_dna_fused := false

func _fuse_slime_dna(item: Dictionary) -> void:
	if slime_dna_fused:
		return

	for spell_id in ["slime_summon", "slime_crush", "slime_absorb"]:
		_learn_spell(spell_id)

	slime_dna_fused = true
	for ally in allied_summons:
		if ally.get("id") == "slime":
			ally["max_health"] = float(ally["max_health"]) * SLIME_DNA_SUMMON_MULTIPLIER
			ally["health"] = float(ally["health"]) * SLIME_DNA_SUMMON_MULTIPLIER

	inventory.erase(item)
	_refresh_summons()
	_refresh_bag_grid()
	_clear_bag_selection()
	_open_spellbook()


func _slime_area_attack(damage: float, weapon_move: String, sluggish_turns: int = 0) -> void:
	var first_hit: Dictionary = {}
	var struck_targets: Dictionary = {}
	for index in _get_living_enemy_slots():
		var target = active_enemies[index]
		if target == null:
			continue
		var previous_health := float(target["health"])
		_damage_selected_enemy(damage, false, "", index, weapon_move, false, false, false)
		if sluggish_turns > 0:
			_apply_status_effect(target, "sluggish", 1, sluggish_turns)
		if float(target["health"]) < previous_health:
			struck_targets[index] = target
			if first_hit.is_empty():
				first_hit = target
	if not first_hit.is_empty():
		_trigger_attack_enchantments(first_hit)
	for index in struck_targets:
		_allied_slimes_follow_up(index, struck_targets[index])
	_deploy_reinforcements()


func _wears_full_slime_set() -> bool:
	for slot_name in ["head", "chest", "legs", "boots"]:
		if not equipped_armor[slot_name].get("slime_set", false):
			return false
	return true


func _add_passive_item(item: Dictionary) -> bool:
	var item_id := str(item["template_id"])
	if not passive_inventory.has(item_id):
		item["quantity"] = 0
		passive_inventory[item_id] = item
	var entry: Dictionary = passive_inventory[item_id]
	if int(entry["quantity"]) >= int(entry["max_stack"]):
		_add_combat_log("%s is already at its passive stack limit." % entry["name"], "warning")
		return false
	entry["quantity"] += 1
	entry["pickup_order"] = next_pickup_order
	next_pickup_order += 1
	if is_instance_valid(passive_list) and passive_dialog.visible:
		_refresh_passive_list()
	_add_combat_log("Passive acquired: %s (%d/%d)" % [entry["name"], entry["quantity"], entry["max_stack"]], "gold")
	return true


func _setup_passive_inventory(bag_panel: Control) -> void:
	var button := Button.new()
	button.text = "Passives"
	button.position = Vector2(715, 50)
	button.size = Vector2(125, 32)
	button.pressed.connect(_open_passive_inventory)
	bag_panel.add_child(button)

	passive_dialog = AcceptDialog.new()
	passive_dialog.title = "Passive Items"
	bag_panel.add_child(passive_dialog)
	var layout := VBoxContainer.new()
	layout.custom_minimum_size = Vector2(450, 290)
	passive_dialog.add_child(layout)
	passive_sort = OptionButton.new()
	passive_sort.add_item("Sort: Recent")
	passive_sort.add_item("Sort: Rarity")
	passive_sort.item_selected.connect(func(_index): _refresh_passive_list())
	layout.add_child(passive_sort)
	passive_list = ItemList.new()
	passive_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	passive_list.max_columns = 4
	passive_list.icon_mode = ItemList.ICON_MODE_TOP
	passive_list.fixed_icon_size = Vector2i(48, 48)
	passive_list.item_selected.connect(_show_passive_details)
	layout.add_child(passive_list)
	passive_detail = RichTextLabel.new()
	passive_detail.custom_minimum_size.y = 64.0
	passive_detail.fit_content = false
	passive_detail.scroll_active = true
	passive_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layout.add_child(passive_detail)


func _open_passive_inventory() -> void:
	_refresh_passive_list()
	passive_dialog.popup_centered(Vector2i(500, 360))


func _refresh_passive_list() -> void:
	passive_list.clear()
	passive_entries.clear()
	for item_id in passive_inventory:
		passive_entries.append(item_id)
	var rarity_order := rarity_weights.keys()
	passive_entries.sort_custom(func(a, b):
		if passive_sort.selected == 1:
			var a_rank := rarity_order.find(passive_inventory[a]["rarity"])
			var b_rank := rarity_order.find(passive_inventory[b]["rarity"])
			if a_rank != b_rank:
				return a_rank > b_rank
		return int(passive_inventory[a]["pickup_order"]) > int(passive_inventory[b]["pickup_order"])
	)
	for item_id in passive_entries:
		var item: Dictionary = passive_inventory[item_id]
		passive_list.add_item("%s ×%d" % [item["name"], item["quantity"]], _load_optional_texture(str(item["icon"])))
	passive_detail.text = "No passive items yet." if passive_entries.is_empty() else ""
	if not passive_entries.is_empty():
		passive_list.select(0)
		_show_passive_details(0)


func _show_passive_details(index: int) -> void:
	var item: Dictionary = passive_inventory[passive_entries[index]]
	passive_detail.text = "%s  ·  %s  ·  %d/%d\n%s" % [item["name"], item["rarity"], item["quantity"], item["max_stack"], item["description"]]
	passive_detail.scroll_to_line(0)

func _refresh_boss_update_hp() -> void:
	get_node("PlayerHP").text = "HP: %d/%d" % [player_health, player_max_health]


func _lowest_allied_slime() -> int:
	var lowest := -1
	for index in range(allied_summons.size()):
		if allied_summons[index].get("id") != "slime":
			continue
		if lowest < 0 or float(allied_summons[index]["health"]) < float(allied_summons[lowest]["health"]):
			lowest = index
	return lowest


func _summon_allied_slime() -> void:
	var base: Dictionary = enemy_database.get("slime", {})
	if base.is_empty():
		return
	var hp := maxf(1.0, float(base["max_health"]) * SlimeContent.SUMMON_HEALTH_MULTIPLIER)
	if slime_dna_fused:
		hp *= SLIME_DNA_SUMMON_MULTIPLIER
	var ally := {
		"id": "slime", "name": "Allied Slime", "health": hp, "max_health": hp,
		"sprite": base.get("sprite", ""), "attacks": base["attacks"],
		"resistances": base.get("resistances", {}), "temporary": true,
		"dodge_chance": SlimeContent.SUMMON_DODGE_CHANCE,
	}
	if allied_summons.size() < SlimeContent.SUMMON_LIMIT:
		allied_summons.append(ally)
	else:
		var lowest := 0
		for index in range(1, allied_summons.size()):
			if float(allied_summons[index]["health"]) < float(allied_summons[lowest]["health"]):
				lowest = index
		allied_summons[lowest] = ally
	_refresh_summons()


func _clear_temporary_summons() -> void:
	for index in range(allied_summons.size() - 1, -1, -1):
		if allied_summons[index].get("temporary", false):
			allied_summons.remove_at(index)
	_refresh_summons()


func _refresh_summons() -> void:
	if not is_instance_valid(summon_row):
		summon_row = HBoxContainer.new()
		summon_row.name = "SummonRow"
		summon_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		summon_row.add_theme_constant_override("separation", 24)
		summon_row.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		add_child(summon_row)
	for child in summon_row.get_children():
		summon_row.remove_child(child)
		child.queue_free()
	for ally in allied_summons:
		var card := VBoxContainer.new()
		card.mouse_filter = Control.MOUSE_FILTER_IGNORE
		summon_row.add_child(card)
		var image := TextureRect.new()
		image.texture = _load_optional_texture(str(ally["sprite"]))
		image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		image.custom_minimum_size = Vector2(72, 58)
		image.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(image)
		_add_combat_shadow(image, str(ally["id"]), true)
		var bar := ProgressBar.new()
		bar.show_percentage = false
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.custom_minimum_size = Vector2(72, 7)
		bar.max_value = float(ally["max_health"])
		bar.value = float(ally["health"])
		var background := StyleBoxFlat.new()
		background.bg_color = Color.BLACK
		background.set_corner_radius_all(4)
		bar.add_theme_stylebox_override("background", background)

		var fill := StyleBoxFlat.new()
		fill.bg_color = Color("#B94648")
		fill.set_corner_radius_all(4)
		bar.add_theme_stylebox_override("fill", fill)
		card.add_child(bar)
	_position_summon_row()
	summon_row.visible = not allied_summons.is_empty()


func _position_summon_row() -> void:
	var center_x: float = (get_node("BagButton").get_global_rect().get_center().x + get_node("BookButton").get_global_rect().get_center().x) * 0.5
	var target_label := get_node("Label") as Control
	var row_y := minf(370.0, target_label.get_global_rect().position.y - 76.0)
	summon_row.global_position = Vector2(center_x - summon_row.get_combined_minimum_size().x * 0.5, row_y)


func _allied_slimes_follow_up(slot_index: int, target: Dictionary) -> void:
	if combat_state != "player_turn" or allied_summons.is_empty() or not is_same(active_enemies[slot_index], target):
		return
	for ally in allied_summons:
		if not is_same(active_enemies[slot_index], target):
			break
		var attack: Dictionary = ally["attacks"].pick_random()
		var raw_damage := float(attack["damage"])
		if slime_dna_fused and ally.get("id") == "slime":
			raw_damage *= SLIME_DNA_SUMMON_MULTIPLIER
		var victim_slots := [slot_index]
		if attack.get("aoe", false):
			victim_slots = _get_living_enemy_slots()
		for victim_slot in victim_slots:
			var enemy = active_enemies[victim_slot]
			if enemy == null:
				continue
			var resistance: Dictionary = enemy.get("resistances", {})
			var amount := _apply_resistance(
				raw_damage,
				clampf(
					float(resistance.get("Physical", 0.0)) + float(resistance.get("Blunt", 0.0)),
					0.0,
					1.0
				),
				0.0
			)
			_hit_with_spell(victim_slot, amount, "Allied " + str(attack["name"]), false)


func _choose_stage_summon_target() -> void:
	stage_summon_target = {}
	if not allied_summons.is_empty() and not taunt_active and not current_enemy_attack.get("aoe", false) and randf() < SlimeContent.SUMMON_TARGET_CHANCE:
		stage_summon_target = allied_summons.pick_random()


func _resolve_enemy_hit_on_summons() -> void:
	var aoe := bool(current_enemy_attack.get("aoe", false))
	if allied_summons.is_empty() or (not aoe and stage_summon_target.is_empty()):
		return

	var targets: Array = allied_summons.duplicate() if aoe else [stage_summon_target]
	var attack_name := str(current_enemy_attack["name"])
	var attack_type := str(current_enemy_attack.get("damage_type", "Physical"))
	var raw_damage := _enemy_stage_raw_damage(float(current_enemy_attack["damage"]))

	for ally in targets:
		var ally_name := str(ally["name"])
		if randf() < float(ally.get("dodge_chance", 0.0)):
			_add_combat_log("%s dodged %s." % [ally_name, attack_name], "success")
			continue

		var resistance: Dictionary = ally["resistances"]
		var total := float(resistance.get(attack_type, 0.0))
		if attack_type in ["Slash", "Blunt", "Pierce"]:
			total += float(resistance.get("Physical", 0.0))
		elif attack_type not in ["Physical", "Elemental"]:
			total += float(resistance.get("Elemental", 0.0))

		var damage := _apply_resistance(raw_damage, clampf(total, 0.0, 1.0), 0.0)
		var actual_damage := minf(damage, float(ally["health"]))
		ally["health"] = float(ally["health"]) - actual_damage
		_add_combat_log(
			"%s got hit by %s and took %s damage." % [ally_name, attack_name, _format_damage(actual_damage)],
			"warning"
		)

		if ally["health"] <= 0:
			var index := allied_summons.find_custom(func(entry): return is_same(entry, ally))
			if index >= 0:
				allied_summons.remove_at(index)

	_refresh_summons()

func _build_floor_one_room() -> void:
	var viewport_size := get_viewport_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return

	var dungeon_path := "res://Assets/Dungeon/Floor1/DungeonFloor1.png"
	var stats_path := "res://Assets/general sprites/TempStatsMenu.png"
	var stats_panel := get_node("BetweenFightsPanel") as Control
	var path := stats_path if stats_panel.visible else dungeon_path
	var texture := _load_optional_texture(path)
	if texture == null:
		push_warning("Missing background: " + path)
		texture = _load_optional_texture(dungeon_path) if stats_panel.visible else null
		if texture == null:
			return

	var background := get_node_or_null("FloorOneRoom") as Sprite2D
	if background == null:
		background = Sprite2D.new()
		background.name = "FloorOneRoom"
		background.centered = false
		background.position = Vector2.ZERO
		background.z_index = -10
		background.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		add_child(background)

	background.texture = texture
	background.scale = viewport_size / texture.get_size()


var shadow_footprints: Dictionary = {}

func _add_combat_shadow(visual: CanvasItem, enemy_id: String, allied: bool = false) -> void:
	var art: Texture2D
	if visual is TextureRect or visual is Sprite2D:
		art = visual.texture
	if art == null:
		return

	var shadow_path := "res://Assets/general sprites/shadowenemy.png"
	var shadow_texture := _load_optional_texture(shadow_path)
	if shadow_texture == null:
		push_warning("Could not load combat shadow: " + shadow_path)
		return

	var art_size := art.get_size()
	if not shadow_footprints.has(art):
		var footprint := Rect2(Vector2.ZERO, art_size)
		var pixels := art.get_image()
		if pixels != null and not pixels.is_empty():
			var used := pixels.get_used_rect()
			if used.has_area():
				var foot_rows := maxi(1, ceili(used.size.y * 0.20))
				var feet_area := Rect2i(used.position.x, used.end.y - foot_rows, used.size.x, foot_rows)
				var feet := pixels.get_region(feet_area).get_used_rect()
				footprint = Rect2(feet_area.position + feet.position, feet.size)
		shadow_footprints[art] = footprint

	var shadow := Sprite2D.new()
	shadow.texture = shadow_texture
	shadow.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# Draw above the room background and below the enemy sprite.
	shadow.show_behind_parent = false
	shadow.z_as_relative = false
	shadow.z_index = 1

	visual.z_as_relative = false
	visual.z_index = 2

	# Let the shadow extend below a TextureRect, especially for bats.
	if visual is TextureRect:
		visual.clip_contents = false
	var flying := enemy_id == "bat"
	shadow.name = "CombatShadow"
	shadow.modulate.a = 1.0
	visual.add_child(shadow)

	# TextureRects can resize after their container lays them out.
	var position_shadow := func():
		var drawn := Rect2(Vector2.ZERO, art_size)
		if visual is Sprite2D:
			drawn = visual.get_rect()
		elif visual is TextureRect:
			drawn.size = visual.size
			if visual.stretch_mode in [TextureRect.STRETCH_KEEP, TextureRect.STRETCH_KEEP_CENTERED]:
				drawn.size = art_size
			elif visual.stretch_mode in [TextureRect.STRETCH_KEEP_ASPECT, TextureRect.STRETCH_KEEP_ASPECT_CENTERED]:
				var fit := minf(visual.size.x / art_size.x, visual.size.y / art_size.y)
				drawn.size = art_size * fit
			if visual.stretch_mode in [TextureRect.STRETCH_KEEP_CENTERED, TextureRect.STRETCH_KEEP_ASPECT_CENTERED]:
				drawn.position = (visual.size - drawn.size) * 0.5

		var footprint: Rect2 = shadow_footprints[art]
		var feet_x := footprint.get_center().x / art_size.x
		if visual.flip_h:
			feet_x = 1.0 - feet_x
		var feet_y := footprint.end.y / art_size.y
		var width := footprint.size.x / art_size.x * drawn.size.x
		var height := clampf(width * 0.15, 4.0, 16.0)
		shadow.scale = Vector2(width, height) / shadow_texture.get_size()
		var drop := 38.0 if flying else (0.0 if allied else 2.0)
		shadow.position = drawn.position + Vector2(feet_x, feet_y) * drawn.size + Vector2(0, drop)

	if visual is TextureRect:
		visual.resized.connect(position_shadow)
	position_shadow.call()
